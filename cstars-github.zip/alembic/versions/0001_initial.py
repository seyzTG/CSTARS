"""Начальная схема: все таблицы проекта.

Таблицы создаются из декларативных моделей (единый источник истины),
индексы и уникальные ограничения следуют из моделей app/models/*.

Revision ID: 0001_initial
Revises:
Create Date: 2026-10-21

"""
from __future__ import annotations

from alembic import op

from app.database.base import Base
import app.models  # noqa: F401  — регистрация всех моделей

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    Base.metadata.create_all(bind=bind)


def downgrade() -> None:
    bind = op.get_bind()
    Base.metadata.drop_all(bind=bind)

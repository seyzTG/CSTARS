"""Telegram Stars — официальные платежи Bot API (валюта XTR).

Инвойс создаётся через ``sendInvoice``; деньги подтверждаются только через
``pre_checkout_query`` и ``successful_payment`` с серверной проверкой суммы,
payload и уникальности ``telegram_payment_charge_id``.
"""

from __future__ import annotations

from app.config.settings import settings
from app.payments.base import (
    BaseProvider,
    PaymentConfirmation,
    PaymentInvoice,
    PaymentRequest,
)


class StarsProvider(BaseProvider):
    code = "stars"

    def __init__(self) -> None:
        super().__init__(api_key="", api_url="")

    @property
    def configured(self) -> bool:
        return settings.stars_enabled

    def stars_amount(self, amount_minor: int) -> int:
        """Внутренние единицы → настоящие Telegram Stars (явный курс)."""
        if settings.units_per_star <= 0:
            return 0
        return max(1, round(amount_minor / 100 / settings.units_per_star))

    async def create_invoice(self, request: PaymentRequest) -> PaymentInvoice:
        if not self.configured:
            return PaymentInvoice(
                ok=False, provider=self.code, not_configured=True,
                error="stars_disabled",
            )
        stars = self.stars_amount(request.amount_minor)
        title = "Пополнение баланса"
        description = f"{stars} Telegram Stars → внутренние единицы"
        return PaymentInvoice(
            ok=True,
            provider=self.code,
            provider_amount=float(stars),
            provider_currency="XTR",
            telegram_invoice={
                "title": title,
                "description": description,
                "payload": request.payload,
                "currency": "XTR",
                "prices": [{"label": "Пополнение", "amount": stars}],
            },
        )

    async def verify(self, payload: str, external_id: str) -> PaymentConfirmation:
        """Проверка успешного платежа Telegram.

        Вызывается из обработчика successful_payment: сумма, валюта и payload
        сверяются с записью платежа, а ``telegram_payment_charge_id``
        гарантирует идемпотентность повторных уведомлений.
        """
        if not self.configured:
            return PaymentConfirmation(ok=False, error="not_configured")
        if not external_id:
            return PaymentConfirmation(ok=False, error="missing_charge_id")
        return PaymentConfirmation(ok=True, external_id=external_id)


def stars_invoice_payload(payment_id: int, user_id: int, amount_minor: int) -> str:
    """Payload: проверяется на сервере при успешном платеже."""
    return f"stars:{payment_id}:{user_id}:{amount_minor}"

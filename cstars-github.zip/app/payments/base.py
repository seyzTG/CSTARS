"""Платёжные адаптеры.

Правила:
  * каждый способ — отдельный адаптер с единым интерфейсом;
  * без API-ключа адаптер в состоянии ``not_configured`` и вежливо
    сообщает об этом пользователю;
  * успешный платёж подтверждается ТОЛЬКО после подтверждения провайдером
    (серверная проверка суммы, payload и уникальности);
  * внутренние единицы НИКОГДА не приравниваются к реальным Stars/крипте —
    конвертация только через явный курс settings.units_per_star.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class PaymentRequest:
    user_id: int
    amount_minor: int          # внутренние единицы ×100
    payload: str               # уникальный payload для проверки на сервере


@dataclass
class PaymentInvoice:
    ok: bool
    provider: str
    invoice_url: str | None = None
    external_id: str | None = None
    provider_amount: float | None = None
    provider_currency: str | None = None
    error: str | None = None
    not_configured: bool = False
    # данные для send_invoice (Telegram Stars)
    telegram_invoice: dict | None = None


@dataclass
class PaymentConfirmation:
    ok: bool
    external_id: str | None = None
    amount_minor: int = 0
    error: str | None = None
    duplicate: bool = False


class BaseProvider(ABC):
    """Единый контракт всех платёжных адаптеров."""

    code: str = "base"

    def __init__(self, api_key: str, api_url: str) -> None:
        self.api_key = (api_key or "").strip()
        self.api_url = (api_url or "").strip()

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    @abstractmethod
    async def create_invoice(self, request: PaymentRequest) -> PaymentInvoice:
        """Создать платёж. Не подтверждает его."""

    @abstractmethod
    async def verify(self, payload: str, external_id: str) -> PaymentConfirmation:
        """Проверить платёж на сервере провайдера (сумма/существование/уникальность)."""

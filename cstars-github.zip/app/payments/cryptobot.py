"""Адаптер Crypto Bot (https://api.cryptobot.pay).

Реализован по официальной документации CryptoBot API. Требует API-ключ в
переменной окружения CRYPTOBOT_API_KEY. Без ключа адаптер остаётся в
состоянии ``not_configured`` и НЕ имитирует успешную оплату.

Примечание: параметры запросов проверьте по актуальной официальной
документации провайдера перед боевым запуском (см. docs/PAYMENTS.md).
"""

from __future__ import annotations

import asyncio
from typing import Any

from aiohttp import ClientSession, ClientTimeout

from app.config.settings import settings
from app.payments.base import (
    BaseProvider,
    PaymentConfirmation,
    PaymentInvoice,
    PaymentRequest,
)
from app.utils.logging import get_logger

log = get_logger(__name__)


class CryptoBotProvider(BaseProvider):
    code = "cryptobot"

    def __init__(self) -> None:
        super().__init__(settings.cryptobot_api_key, settings.cryptobot_api_url)

    def _headers(self) -> dict[str, str]:
        return {"Crypto-Pay-API-Key": self.api_key}

    async def _post(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.api_url.rstrip('/')}/{method}"
        async with ClientSession(timeout=ClientTimeout(total=20)) as session:
            async with session.post(url, json=payload, headers=self._headers()) as response:
                data = await response.json(content_type=None)
                if not isinstance(data, dict):
                    raise ValueError("unexpected response from cryptobot")
                return data

    async def create_invoice(self, request: PaymentRequest) -> PaymentInvoice:
        if not self.configured:
            return PaymentInvoice(
                ok=False, provider=self.code, not_configured=True,
                error="cryptobot_not_configured",
            )
        amount_major = request.amount_minor / 100
        try:
            data = await asyncio.wait_for(
                self._post(
                    "createInvoice",
                    {
                        "currency_type": "crypto",
                        "asset": "USDT",
                        "amount": round(amount_major, 2),
                        "payload": request.payload,
                    },
                ),
                timeout=25,
            )
        except Exception as exc:  # noqa: BLE001 — внешний сервис
            log.warning("cryptobot create_invoice failed: %s", type(exc).__name__)
            return PaymentInvoice(ok=False, provider=self.code, error=str(type(exc).__name__))

        result = data.get("result") or {}
        invoice_url = result.get("payUrl") or result.get("url")
        if not invoice_url:
            return PaymentInvoice(
                ok=False, provider=self.code,
                error=str(data.get("error", "no_invoice_url")),
            )
        return PaymentInvoice(
            ok=True,
            provider=self.code,
            invoice_url=invoice_url,
            external_id=str(result.get("invoiceId") or result.get("id") or ""),
            provider_amount=float(result.get("amount") or amount_major),
            provider_currency=str(result.get("asset") or "USDT"),
        )

    async def verify(self, payload: str, external_id: str) -> PaymentConfirmation:
        """Проверка статуса invoices у провайдера (идемпотентность)."""
        if not self.configured:
            return PaymentConfirmation(ok=False, error="not_configured")
        try:
            data = await asyncio.wait_for(
                self._post("getInvoices", {"payload": payload}), timeout=20
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("cryptobot verify failed: %s", type(exc).__name__)
            return PaymentConfirmation(ok=False, error=str(type(exc).__name__))
        items = (data.get("result") or {}).get("items") or []
        for item in items:
            if str(item.get("invoiceId") or item.get("id")) != external_id:
                continue
            if str(item.get("status", "")).lower() in {"paid", "completed"}:
                return PaymentConfirmation(ok=True, external_id=external_id)
        return PaymentConfirmation(ok=False, error="not_paid")

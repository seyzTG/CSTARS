"""Прочие способы: произвольные криптовалюты и Telegram Gifts.

Согласно ТЗ эти методы НЕ объявляются реализованными, пока не написан и не
протестирован адаптер с реальным провайдером. Здесь — честное состояние
``not_configured`` с понятным сообщением пользователю и точкой расширения.
"""

from __future__ import annotations

from app.config.settings import settings
from app.payments.base import (
    BaseProvider,
    PaymentConfirmation,
    PaymentInvoice,
    PaymentRequest,
)


class GenericCryptoProvider(BaseProvider):
    """Произвольные криптовалюты (внешний процессор)."""

    code = "crypto"

    def __init__(self) -> None:
        super().__init__(api_key="", api_url="")

    @property
    def configured(self) -> bool:
        return settings.crypto_external_enabled

    async def create_invoice(self, request: PaymentRequest) -> PaymentInvoice:
        # внешний процессор не подключён — платёж не создаётся и не имитируется
        return PaymentInvoice(
            ok=False, provider=self.code, not_configured=not self.configured,
            error="crypto_not_configured",
        )

    async def verify(self, payload: str, external_id: str) -> PaymentConfirmation:
        return PaymentConfirmation(ok=False, error="not_configured")


class GiftsProvider(BaseProvider):
    """Telegram Gifts: приём подарков в качестве пополнения."""

    code = "gifts"

    def __init__(self) -> None:
        super().__init__(api_key="", api_url="")

    @property
    def configured(self) -> bool:
        return settings.gifts_enabled

    async def create_invoice(self, request: PaymentRequest) -> PaymentInvoice:
        return PaymentInvoice(
            ok=False, provider=self.code, not_configured=not self.configured,
            error="gifts_not_configured",
        )

    async def verify(self, payload: str, external_id: str) -> PaymentConfirmation:
        return PaymentConfirmation(ok=False, error="not_configured")

"""Адаптер xRocket (https://api.xrocket.me).

Требует API-ключ XROCKET_API_KEY. Без ключа — состояние ``not_configured``;
успешная оплата никогда не имитируется. Проверьте параметры по актуальной
официальной документации провайдера перед боевым запуском (docs/PAYMENTS.md).
"""

from __future__ import annotations

import asyncio
from typing import Any

from aiohttp import ClientSession, ClientTimeout

from app.config.settings import settings
from app.payments.base import (
    BaseProvider,
    PaymentConfirmation,
    PaymentInvoice,
    PaymentRequest,
)
from app.utils.logging import get_logger

log = get_logger(__name__)


class XRocketProvider(BaseProvider):
    code = "xrocket"

    def __init__(self) -> None:
        super().__init__(settings.xrocket_api_key, settings.xrocket_api_url)

    async def _post(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.api_url.rstrip('/')}/{method}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        async with ClientSession(timeout=ClientTimeout(total=20)) as session:
            async with session.post(url, json=payload, headers=headers) as response:
                data = await response.json(content_type=None)
                if not isinstance(data, dict):
                    raise ValueError("unexpected response from xrocket")
                return data

    async def create_invoice(self, request: PaymentRequest) -> PaymentInvoice:
        if not self.configured:
            return PaymentInvoice(
                ok=False, provider=self.code, not_configured=True,
                error="xrocket_not_configured",
            )
        amount_major = request.amount_minor / 100
        try:
            data = await asyncio.wait_for(
                self._post(
                    "createInvoice",
                    {
                        "currency": "usdt",
                        "amount": round(amount_major, 2),
                        "comment": request.payload,
                    },
                ),
                timeout=25,
            )
        except Exception as exc:  # noqa: BLE001 — внешний сервис
            log.warning("xrocket create_invoice failed: %s", type(exc).__name__)
            return PaymentInvoice(ok=False, provider=self.code, error=str(type(exc).__name__))

        result = data.get("result") or data
        invoice_url = result.get("url") or result.get("payUrl")
        if not invoice_url:
            return PaymentInvoice(
                ok=False, provider=self.code,
                error=str(data.get("message", "no_invoice_url")),
            )
        return PaymentInvoice(
            ok=True,
            provider=self.code,
            invoice_url=invoice_url,
            external_id=str(result.get("id") or result.get("invoiceId") or ""),
            provider_amount=float(result.get("amount") or amount_major),
            provider_currency=str(result.get("currency") or "usdt").upper(),
        )

    async def verify(self, payload: str, external_id: str) -> PaymentConfirmation:
        if not self.configured:
            return PaymentConfirmation(ok=False, error="not_configured")
        try:
            data = await asyncio.wait_for(
                self._post("getInvoice", {"id": external_id}), timeout=20
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("xrocket verify failed: %s", type(exc).__name__)
            return PaymentConfirmation(ok=False, error=str(type(exc).__name__))
        result = data.get("result") or data
        status = str(result.get("status", "")).lower()
        if status in {"paid", "completed", "success"}:
            return PaymentConfirmation(ok=True, external_id=external_id)
        return PaymentConfirmation(ok=False, error="not_paid")

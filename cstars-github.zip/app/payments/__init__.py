"""Платёжные адаптеры и реестр провайдеров."""

from __future__ import annotations

from app.payments.base import (
    BaseProvider,
    PaymentConfirmation,
    PaymentInvoice,
    PaymentRequest,
)
from app.payments.cryptobot import CryptoBotProvider
from app.payments.other import GiftsProvider, GenericCryptoProvider
from app.payments.stars import StarsProvider, stars_invoice_payload
from app.payments.xrocket import XRocketProvider

_providers: dict[str, BaseProvider] | None = None


def registry() -> dict[str, BaseProvider]:
    """Ленивая инициализация адаптеров (ключи читаются из окружения)."""
    global _providers
    if _providers is None:
        _providers = {
            "stars": StarsProvider(),
            "cryptobot": CryptoBotProvider(),
            "xrocket": XRocketProvider(),
            "crypto": GenericCryptoProvider(),
            "gifts": GiftsProvider(),
        }
    return _providers


def get_provider(code: str) -> BaseProvider | None:
    return registry().get(code)


def reset_registry() -> None:
    """Сброс кэша (используется в тестах)."""
    global _providers
    _providers = None


__all__ = [
    "BaseProvider",
    "PaymentConfirmation",
    "PaymentInvoice",
    "PaymentRequest",
    "StarsProvider",
    "CryptoBotProvider",
    "XRocketProvider",
    "GenericCryptoProvider",
    "GiftsProvider",
    "registry",
    "get_provider",
    "reset_registry",
    "stars_invoice_payload",
]

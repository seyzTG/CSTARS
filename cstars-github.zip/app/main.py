"""Точка входа: сборка бота, middleware, миграции, polling."""

from __future__ import annotations

import asyncio
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from app.config.settings import Settings, get_settings
from app.database.session import dispose_engine, get_session_factory
from app.handlers import build_root_router
from app.middlewares import (
    DbSessionMiddleware,
    ThrottleMiddleware,
    UserMiddleware,
)
from app.utils.logging import get_logger, setup_logging

log = get_logger(__name__)


def build_dispatcher(settings: Settings) -> Dispatcher:
    """Создать диспетчер с состояниями, middleware и роутерами."""
    if settings.use_redis:
        from aiogram.fsm.storage.redis import RedisStorage

        import redis.asyncio as aioredis

        storage = RedisStorage.from_url(settings.redis_url)
        log.info("FSM storage: Redis")
    else:
        storage = MemoryStorage()
        log.info("FSM storage: memory")

    dp = Dispatcher(storage=storage)

    # порядок важен: сессия БД → пользователь → антифлуд
    dp.update.middleware(DbSessionMiddleware(get_session_factory()))
    dp.update.middleware(UserMiddleware())
    dp.update.middleware(ThrottleMiddleware())

    dp.include_router(build_root_router())
    return dp


async def _ensure_schema(settings: Settings) -> None:
    """Создать таблицы при первом запуске (dev) либо доверить Alembic."""
    if not settings.auto_create_tables:
        return
    from sqlalchemy import text

    from app.database.base import Base
    from app.database.session import get_engine
    import app.models  # noqa: F401  — регистрация всех моделей

    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    async with engine.connect() as conn:
        await conn.execute(text("SELECT 1"))
    log.info("Database schema ready")


async def on_startup(bot: Bot, settings: Settings) -> None:
    me = await bot.get_me()
    log.info("Bot started: @%s (%s)", me.username, me.first_name)
    if not settings.admin_ids:
        log.warning("ADMIN_IDS пуст — админ-команды недоступны.")
    await bot.set_my_commands(
        [
            {"command": "start", "description": "Запустить бота"},
            {"command": "ref", "description": "Партнёрская программа"},
            {"command": "admin", "description": "Админ-панель"},
        ]
    )


async def main() -> None:
    settings = get_settings()
    setup_logging()

    if not settings.bot_token or ":" not in settings.bot_token:
        log.error("BOT_TOKEN не задан — заполните файл .env")
        sys.exit(1)

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = build_dispatcher(settings)

    try:
        await _ensure_schema(settings)
    except Exception as exc:  # noqa: BLE001
        log.error("Не удалось подготовить схему БД: %s", type(exc).__name__)
        log.error("Проверьте DATABASE_URL/DB_* в .env и доступность PostgreSQL.")
        sys.exit(1)

    # фоновые полёты Crash не переживают перезапуск — возвращаем ставки
    try:
        from app.handlers.crash import recover_pending_rounds

        await recover_pending_rounds()
    except Exception as exc:  # noqa: BLE001
        log.error("Не удалось восстановить полёты Crash: %s", type(exc).__name__)

    await on_startup(bot, settings)

    try:
        # handle_signals=False: сигналы обрабатываем сами (дружно к Windows)
        await dp.start_polling(bot, handle_signals=False)
    finally:
        await dispose_engine()
        try:
            await bot.session.close()
        except Exception:  # noqa: BLE001
            pass
        log.info("Bot stopped gracefully")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        log.info("Interrupted")

"""Сервис расчёта ставок и завершения раундов.

Отделён от обработчиков Telegram и от доступа к БД:
  * проверяет ставку (минимум/максимум/допустимость исхода/баланс);
  * атомарно списывает ставку (бонусные → собственные средства);
  * защищает от двойного списания и повторной обработки одного действия;
  * считает выигрыш по коэффициенту и начисляет его через журнал;
  * обновляет статистику и начисляет реферальное вознаграждение.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import referral as ref_cfg
from app.config.games import GameSpec, outcome_by_code
from app.config.settings import settings
from app.finance import InsufficientFunds, credit, debit_split
from app.games.engine import RollResult, evaluate
from app.models import User, Wallet
from app.models.enums import TransactionType, WalletKind
from app.repositories import game_repo, social_repo
from app.utils.money import apply_multiplier
from app.utils.logging import get_logger

log = get_logger(__name__)


@dataclass
class BetValidation:
    ok: bool
    error: str | None = None      # ключ текста ошибки
    context: dict | None = None


@dataclass
class SettlementResult:
    """Итог раунда — всё, что нужно обработчику для отрисовки."""

    won: bool | None                 # None → ничья (возврат ставки)
    stake_minor: int
    payout_minor: int
    bonus_spent: int
    real_spent: int
    outcome_code: str | None
    outcome_label: str | None
    coefficient: float | None
    values: list[int]
    balance_minor: int
    duplicate: bool = False          # повтор действия → брошок не выполнялся


def validate_bet(
    *,
    stake_minor: int,
    outcome_code: str | None,
    game_code: str,
    dice_count: int = 1,
) -> BetValidation:
    """Проверки ставки ДО списания."""
    from app.utils.money import to_minor

    min_minor = to_minor(settings.bet_min)
    max_minor = to_minor(settings.bet_max)

    if stake_minor < min_minor:
        return BetValidation(
            False, "BET_MIN_ERROR", {"min": f"{settings.bet_min:g}"}
        )
    if stake_minor > max_minor:
        return BetValidation(
            False, "BET_MAX_ERROR", {"max": f"{settings.bet_max:g}"}
        )
    if not outcome_code:
        return BetValidation(False, "BET_OUTCOME_UNAVAILABLE")
    if outcome_by_code(game_code, outcome_code, dice_count) is None:
        return BetValidation(False, "BET_OUTCOME_UNAVAILABLE")
    return BetValidation(True)


async def start_round(
    session: AsyncSession,
    *,
    user_id: int,
    game_code: str,
    outcome_code: str,
    outcome_label: str,
    coefficient: float | None,
    stake_minor: int,
    action_id: str,
    is_custom: bool = False,
) -> tuple[int, int, int, SettlementResult | None]:
    """Создать раунд и атомарно списать ставку.

    Возвращает (round_id, bonus_spent, real_spent, дубликат|None).
    Дубликат → раунд уже обработан, повторный бросок не нужен.
    """
    round_ = await game_repo.create_round(
        session,
        user_id=user_id,
        game_code=game_code,
        stake=stake_minor,
        action_id=action_id,
    )
    if round_ is None:
        # повторное действие — ставка НЕ списывается повторно
        existing = await game_repo.user_rounds(session, user_id, limit=1)
        duplicate_result = SettlementResult(
            won=None,
            stake_minor=stake_minor,
            payout_minor=0,
            bonus_spent=0,
            real_spent=0,
            outcome_code=outcome_code,
            outcome_label=outcome_label,
            coefficient=coefficient,
            values=[],
            balance_minor=0,
            duplicate=True,
        )
        return 0, 0, 0, duplicate_result

    await game_repo.create_bet(
        session,
        round_id=round_.id,
        user_id=user_id,
        game_code=game_code,
        outcome_code=outcome_code,
        outcome_label=outcome_label,
        amount=stake_minor,
        multiplier=coefficient or 0.0,
        potential_payout=(
            apply_multiplier(stake_minor, coefficient) if coefficient else 0
        ),
        is_custom=is_custom,
    )

    result = await debit_split(
        session,
        user_id=user_id,
        amount_minor=stake_minor,
        kind=TransactionType.BET,
        key=f"round:{action_id}",
        prefer=WalletKind.BONUS,
        description=f"Ставка: {outcome_label}",
        game_round_id=round_.id,
    )
    return round_.id, result.bonus_spent, result.real_spent, None


async def finish_round(
    session: AsyncSession,
    *,
    user_id: int,
    round_id: int,
    game_code: str,
    outcome_code: str,
    outcome_label: str,
    coefficient: float | None,
    stake_minor: int,
    bonus_spent: int,
    roll: RollResult,
    action_id: str,
) -> SettlementResult:
    """Рассчитать результат броска, начислить выигрыш, обновить статистику."""
    won = evaluate(game_code, outcome_code, roll)

    payout_minor = 0
    if won and coefficient:
        payout_minor = apply_multiplier(stake_minor, coefficient)
        await credit(
            session,
            user_id=user_id,
            amount_minor=payout_minor,
            kind=TransactionType.PAYOUT,
            key=f"round:{action_id}#payout",
            description=f"Выигрыш: {roll.outcome_label or outcome_label}",
            game_round_id=round_id,
        )
    elif won is None:
        # ничья: возврат ставки (значение Dice не сопоставлено с исходом)
        refund_minor = stake_minor - bonus_spent
        if refund_minor > 0:
            await credit(
                session,
                user_id=user_id,
                amount_minor=refund_minor,
                kind=TransactionType.REFUND,
                key=f"round:{action_id}#refund",
                description="Возврат ставки (ничья)",
                game_round_id=round_id,
            )
        if bonus_spent:
            await credit(
                session,
                user_id=user_id,
                amount_minor=bonus_spent,
                kind=TransactionType.REFUND,
                wallet_kind=WalletKind.BONUS,
                key=f"round:{action_id}#refund_bonus",
                description="Возврат бонусной ставки (ничья)",
                game_round_id=round_id,
            )

    from app.models import GameRound
    from app.models.enums import RoundStatus

    round_obj = await session.get(GameRound, round_id)
    status = (
        RoundStatus.WON if won else RoundStatus.LOST if won is False else RoundStatus.VOID
    )
    if round_obj is not None:
        await game_repo.finish_round(
            session,
            round_obj,
            outcome_code=roll.outcome_code or outcome_code,
            outcome_label=roll.outcome_label or outcome_label,
            multiplier=coefficient,
            payout=payout_minor,
            bonus_spent=bonus_spent,
            status=status,
            dice_values=roll.values,
        )

    await _update_stats(session, user_id=user_id, stake_minor=stake_minor)

    # вознаграждение партнёра — от прибыли проекта, а не от ставки
    await referral_service_accrue(session, user_id=user_id, round_id=round_id,
                                  stake_minor=stake_minor,
                                  payout_minor=payout_minor,
                                  bonus_spent=bonus_spent)

    wallet = await session.get(Wallet, user_id)
    balance_minor = wallet.total if wallet else 0

    return SettlementResult(
        won=won,
        stake_minor=stake_minor,
        payout_minor=payout_minor,
        bonus_spent=bonus_spent,
        real_spent=stake_minor - bonus_spent,
        outcome_code=roll.outcome_code or outcome_code,
        outcome_label=roll.outcome_label or outcome_label,
        coefficient=coefficient,
        values=roll.values,
        balance_minor=balance_minor,
    )


async def void_round(
    session: AsyncSession,
    *,
    user_id: int,
    round_id: int,
    stake_minor: int,
    bonus_spent: int,
    action_id: str,
) -> None:
    """Вернуть ставку, если бросок не удался (сбой Telegram API)."""
    refund_minor = stake_minor - bonus_spent
    if refund_minor > 0:
        await credit(
            session,
            user_id=user_id,
            amount_minor=refund_minor,
            kind=TransactionType.REFUND,
            key=f"round:{action_id}#refund",
            description="Возврат ставки (сбой броска)",
            game_round_id=round_id,
        )
    if bonus_spent:
        await credit(
            session,
            user_id=user_id,
            amount_minor=bonus_spent,
            kind=TransactionType.REFUND,
            wallet_kind=WalletKind.BONUS,
            key=f"round:{action_id}#refund_bonus",
            description="Возврат бонусной ставки (сбой броска)",
            game_round_id=round_id,
        )

    from app.models import GameRound
    from app.models.enums import RoundStatus

    round_obj = await session.get(GameRound, round_id)
    if round_obj is not None:
        await game_repo.finish_round(
            session,
            round_obj,
            outcome_code=None,
            outcome_label=None,
            multiplier=None,
            payout=0,
            bonus_spent=bonus_spent,
            status=RoundStatus.VOID,
        )


async def _update_stats(
    session: AsyncSession, *, user_id: int, stake_minor: int
) -> None:
    wallet = await session.get(Wallet, user_id)
    if wallet is None:
        return
    wallet.turnover += stake_minor
    wallet.games_played += 1
    await session.flush()


async def referral_service_accrue(
    session: AsyncSession,
    *,
    user_id: int,
    round_id: int,
    stake_minor: int,
    payout_minor: int,
    bonus_spent: int,
) -> None:
    """Начислить партнёру долю от прибыли проекта по раунду приглашённого."""
    from app.config.referral import RoundProfit, reward_for

    referral = await social_repo.get_referral_of(session, user_id)
    if referral is None:
        return
    profit = RoundProfit(
        stake=stake_minor, payout=payout_minor, bonus_spent=bonus_spent
    )
    reward = reward_for(profit, settings.referral_percent)
    if reward == 0:
        return
    await social_repo.add_reward(
        session,
        inviter_id=referral.inviter_id,
        invitee_id=user_id,
        amount_minor=reward,
        round_id=round_id,
    )


__all__ = [
    "BetValidation",
    "SettlementResult",
    "validate_bet",
    "start_round",
    "finish_round",
    "void_round",
    "InsufficientFunds",
]

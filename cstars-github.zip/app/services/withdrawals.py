"""Сервис вывода средств.

Вывод возможен только из СОБСТВЕННЫХ средств (бонусные не выводятся).
Заявка проходит проверки (минимум/максимум/остаток), создаётся с уникальным
ID, резервирует сумму и попадает в очередь на подтверждение. Статус
«Выполнено» ставится только после фактической выплаты.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import settings
from app.finance import InsufficientFunds, credit, debit
from app.models import Wallet, Withdrawal
from app.models.enums import TransactionType, WalletKind, WithdrawalStatus
from app.repositories import finance_repo
from app.utils.ids import uuid_hex
from app.utils.money import format_amount, to_minor


@dataclass
class WithdrawResult:
    ok: bool
    error_key: str | None = None
    context: dict | None = None
    withdrawal: Withdrawal | None = None


SUPPORTED_METHODS: tuple[tuple[str, str], ...] = (
    ("stars", "Telegram Stars"),
    ("cryptobot", "Crypto Bot"),
    ("xrocket", "xRocket"),
    ("crypto", "Криптовалюта"),
)


def commission_for(amount_minor: int) -> int:
    percent = settings.withdraw_commission_percent
    if percent <= 0:
        return 0
    return int(amount_minor * percent / 100)


async def request_withdrawal(
    session: AsyncSession,
    *,
    user_id: int,
    amount_minor: int,
    method: str,
    destination: str | None = None,
) -> WithdrawResult:
    min_minor = to_minor(settings.withdraw_min)
    max_minor = to_minor(settings.withdraw_max)

    if amount_minor < min_minor or amount_minor > max_minor:
        return WithdrawResult(
            False,
            "WD_INVALID_AMOUNT",
            {"min": str(settings.withdraw_min), "max": f"{settings.withdraw_max:,}".replace(",", " ")},
        )
    if method not in {code for code, _ in SUPPORTED_METHODS}:
        return WithdrawResult(False, "WD_INVALID_AMOUNT")

    wallet = await session.get(Wallet, user_id)
    real_balance = wallet.real_balance if wallet else 0
    if amount_minor > real_balance:
        return WithdrawResult(
            False,
            "WD_NO_FUNDS",
            {"available": format_amount(real_balance)},
        )

    wid = uuid_hex()
    commission = commission_for(amount_minor)
    payout = amount_minor - commission

    try:
        await debit(
            session,
            user_id=user_id,
            amount_minor=amount_minor,
            kind=TransactionType.WITHDRAW,
            wallet_kind=WalletKind.REAL,
            key=f"wd:{wid}",
            description=f"Заявка на вывод {format_amount(amount_minor)} ★ ({method})",
            withdrawal_id=wid,
        )
    except InsufficientFunds:
        return WithdrawResult(
            False,
            "WD_NO_FUNDS",
            {"available": format_amount(real_balance)},
        )

    item = await finance_repo.create_withdrawal(
        session,
        wid=wid,
        user_id=user_id,
        amount_minor=amount_minor,
        commission_minor=commission,
        payout_minor=payout,
        method=method,
        destination=destination,
    )
    return WithdrawResult(True, withdrawal=item)


async def reject(
    session: AsyncSession, *, wid: str, admin_id: int, comment: str | None = None
) -> WithdrawResult:
    """Отклонить заявку — средства возвращаются на баланс."""
    item = await finance_repo.get_withdrawal(session, wid)
    if item is None:
        return WithdrawResult(False, "CHECK_NOT_FOUND")
    if item.status != WithdrawalStatus.PENDING.value:
        return WithdrawResult(False, "CHECK_ALREADY")

    item.status = WithdrawalStatus.REJECTED.value
    item.decided_by = admin_id
    item.admin_comment = comment
    item.user_notified = False
    await session.flush()

    await credit(
        session,
        user_id=item.user_id,
        amount_minor=item.amount_minor,
        kind=TransactionType.WITHDRAW_REJECT,
        key=f"wd_reject:{wid}",
        description=f"Возврат средств: заявка отклонена ({comment or 'без причины'})",
        withdrawal_id=wid,
    )
    return WithdrawResult(True, withdrawal=item)


async def approve(
    session: AsyncSession, *, wid: str, admin_id: int
) -> WithdrawResult:
    """Подтвердить выплату. Статус «Выполнено» = средства реально отправлены."""
    item = await finance_repo.get_withdrawal(session, wid)
    if item is None:
        return WithdrawResult(False, "CHECK_NOT_FOUND")
    if item.status != WithdrawalStatus.PENDING.value:
        return WithdrawResult(False, "CHECK_ALREADY")

    item.status = WithdrawalStatus.PAID.value
    item.decided_by = admin_id
    item.user_notified = False
    await session.flush()

    wallet = await session.get(Wallet, item.user_id)
    if wallet is not None:
        wallet.withdrawn_total += item.payout_minor
        await session.flush()
    return WithdrawResult(True, withdrawal=item)

"""Сервис партнёрской программы: статистика и выплата вознаграждений.

Вознаграждение — доля от ПРИБЫЛИ ПРОЕКТА со ставок приглашённых игроков
(процент и формула — в config/referral.py). Отрицательный результат раунда
уменьшает накопитель и компенсируется будущей прибылью.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.finance import credit
from app.models.enums import TransactionType, WalletKind
from app.repositories import social_repo
from app.utils.money import format_amount


@dataclass
class ReferralStats:
    invited: int
    earned_minor: int
    pending_minor: int


async def stats(session: AsyncSession, inviter_id: int) -> ReferralStats:
    invited = len(await social_repo.invitees(session, inviter_id))
    earned = await social_repo.earned_total(session, inviter_id)
    pending = await social_repo.pending_balance(session, inviter_id)
    return ReferralStats(
        invited=invited, earned_minor=earned, pending_minor=pending
    )


@dataclass
class ClaimOutcome:
    ok: bool
    amount_minor: int = 0
    error: str | None = None


async def claim(session: AsyncSession, inviter_id: int) -> ClaimOutcome:
    """Списать накопленные начисления на баланс. Повторно — невозможно."""
    rewards = await social_repo.pending_rewards(session, inviter_id)
    total = sum(r.amount_minor for r in rewards if r.amount_minor > 0)
    if total <= 0:
        return ClaimOutcome(False, error="nothing")

    applied = await credit(
        session,
        user_id=inviter_id,
        amount_minor=total,
        kind=TransactionType.REFERRAL,
        key=f"refclaim:{inviter_id}:{total}",
        description=f"Выплата партнёрских начислений ({len(rewards)} шт.)",
    )
    if not applied.applied:
        return ClaimOutcome(False, error="duplicate")

    for reward in rewards:
        if reward.amount_minor > 0:
            await social_repo.pay_reward(session, reward)
    return ClaimOutcome(True, amount_minor=total)


def invite_link(bot_username: str, token: str) -> str:
    from app.utils.ids import referral_link

    return referral_link(bot_username, token)


def formula_text() -> str:
    from app.config import referral as ref_cfg

    return ref_cfg.formula_text()


def scale_example(major: int, percent: float) -> tuple[str, str]:
    """(за день, за месяц) для блока «доход в масштабе».

    Оценка по той же модели: дневной оборот × доля прибыли проекта × процент
    партнёрской программы. Значение в минорных единицах.
    """
    from app.config.referral import HOUSE_EDGE

    daily_minor = int(major * 100 * HOUSE_EDGE * percent / 100)
    return format_amount(daily_minor), format_amount(daily_minor * 30)

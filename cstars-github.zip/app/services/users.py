"""Сервис регистрации, профиля и приватности."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import settings
from app.models import User, Wallet
from app.models.enums import PrivacyMode
from app.repositories import finance_repo, social_repo, user_repo


@dataclass
class ProfileData:
    name: str
    user_id: int
    balance_minor: int
    bonus_minor: int
    deposited_minor: int
    withdrawn_minor: int
    turnover_minor: int
    games_played: int
    registered_at: datetime
    privacy_mode: PrivacyMode
    nickname: str | None

    @property
    def public_name(self) -> str:
        if self.privacy_mode == PrivacyMode.ANONYMOUS:
            return "Аноним"
        if self.privacy_mode == PrivacyMode.NICKNAME and self.nickname:
            return self.nickname
        return self.name


async def register(
    session: AsyncSession,
    *,
    user_id: int,
    username: str | None,
    first_name: str | None,
    last_name: str | None = None,
    start_payload: str | None = None,
) -> tuple[User, bool, int | None]:
    """Зарегистрировать пользователя. Возвращает (user, created, inviter_id).

    Разбирает payload deep-link: реферальный токен или чек.
    """
    inviter_id = await _resolve_inviter(session, user_id, start_payload)
    user, created = await user_repo.get_or_create_user(
        session,
        user_id=user_id,
        username=username,
        first_name=first_name,
        last_name=last_name,
        referrer_id=inviter_id,
    )
    if created and inviter_id is not None and inviter_id != user_id:
        await social_repo.create_referral(
            session, inviter_id=inviter_id, invitee_id=user_id
        )
    return user, created, inviter_id


async def _resolve_inviter(
    session: AsyncSession, user_id: int, payload: str | None
) -> int | None:
    """Deep-link → ID пригласившего. Защита от самоприглашения."""
    if not payload or payload.startswith("check_"):
        return None
    from sqlalchemy import select

    from app.models import User as UserModel

    inviter_id = await session.scalar(
        select(UserModel.id).where(UserModel.referral_token == payload)
    )
    if inviter_id is None or int(inviter_id) == user_id:
        return None
    return int(inviter_id)


async def load_profile(session: AsyncSession, user: User) -> ProfileData:
    wallet = await session.get(Wallet, user.id)
    if wallet is None:
        wallet = Wallet(user_id=user.id)
        session.add(wallet)
        await session.flush()
    return ProfileData(
        name=user.display_label(),
        user_id=user.id,
        balance_minor=wallet.total,
        bonus_minor=wallet.bonus_balance,
        deposited_minor=wallet.deposited_total,
        withdrawn_minor=wallet.withdrawn_total,
        turnover_minor=wallet.turnover,
        games_played=wallet.games_played,
        registered_at=user.registered_at,
        privacy_mode=PrivacyMode(user.privacy_mode),
        nickname=user.nickname,
    )


async def set_privacy(
    session: AsyncSession, user_id: int, mode: PrivacyMode
) -> None:
    await user_repo.set_privacy(session, user_id, mode)


async def set_nickname(session: AsyncSession, user_id: int, nickname: str) -> None:
    await user_repo.set_nickname(session, user_id, nickname)


def nickname_valid(value: str) -> bool:
    return 2 <= len(value.strip()) <= 32


async def apply_registration_bonus(
    session: AsyncSession, user_id: int, amount_minor: int
) -> int | None:
    """Регистрационный бонус — на бонусный кошелёк, только один раз."""
    from app.models.enums import BonusType

    result = await social_repo.grant_bonus(
        session,
        user_id=user_id,
        kind=BonusType.REGISTRATION,
        amount_minor=amount_minor,
        period_date=None,
        reason="Регистрация",
    )
    if result is None:
        return None
    from app.finance import credit
    from app.models.enums import TransactionType, WalletKind

    applied = await credit(
        session,
        user_id=user_id,
        amount_minor=amount_minor,
        kind=TransactionType.BONUS,
        wallet_kind=WalletKind.BONUS,
        key=f"regbonus:{user_id}",
        description="Регистрационный бонус",
    )
    return amount_minor if applied.applied or applied.transaction else None

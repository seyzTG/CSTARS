"""Сервис ежедневного бонуса и кешбэка.

Обе системы независимы: у каждой своя конфигурация (config/bonuses.py,
config/cashback.py), свои периоды и защита от повторного получения.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import bonuses as bonus_cfg
from app.config import cashback as cashback_cfg
from app.finance import credit
from app.models import Cashback, Wallet
from app.models.enums import BonusType, TransactionType, WalletKind
from app.repositories import social_repo
from app.utils.money import to_minor
from app.utils.timeutil import humanize_delta, utcnow


# --------------------------- ежедневный бонус -----------------------------

@dataclass
class DailyState:
    eligible: bool
    reason: str = ""
    amount_minor: int = 0
    next_time: str = ""


async def daily_state(session: AsyncSession, user_id: int) -> DailyState:
    wallet = await session.get(Wallet, user_id)
    balance_major = (wallet.total / 100) if wallet else 0

    inputs = bonus_cfg.BonusInputs(
        deposits=0, games_played=0, balance=int(balance_major)
    )
    deposits, games = await social_repo.activity_window(
        session, user_id, bonus_cfg.ACTIVITY_WINDOW_DAYS
    )
    inputs = bonus_cfg.BonusInputs(
        deposits=deposits // 100, games_played=games, balance=int(balance_major)
    )

    ok, reason = bonus_cfg.eligible(inputs)
    if not ok:
        return DailyState(False, reason=reason)

    taken = await social_repo.bonus_taken_today(
        session, user_id, BonusType.DAILY, utcnow().date()
    )
    if taken is not None:
        return DailyState(
            False,
            reason="Бонус уже получен сегодня",
            next_time=(utcnow() + timedelta(days=1)).strftime("%d.%m.%Y %H:%M"),
        )

    amount = bonus_cfg.compute_amount(inputs)
    return DailyState(True, amount_minor=to_minor(amount))


@dataclass
class ClaimResult:
    ok: bool
    error_key: str | None = None
    context: dict | None = None
    amount_minor: int = 0


async def claim_daily(session: AsyncSession, user_id: int) -> ClaimResult:
    state = await daily_state(session, user_id)
    if not state.eligible:
        return ClaimResult(
            False,
            "ERR_GENERIC",
            {"detail": state.reason},
            0,
        )
    if state.amount_minor <= 0:
        return ClaimResult(False, "ERR_GENERIC", {"detail": "Бонус не сформирован"})

    from app.utils.money import format_amount

    day = utcnow().date()
    bonus = await social_repo.grant_bonus(
        session,
        user_id=user_id,
        kind=BonusType.DAILY,
        amount_minor=state.amount_minor,
        period_date=day,
        reason=f"Ежедневный бонус {day.isoformat()}",
    )
    if bonus is None:
        return ClaimResult(
            False, "ERR_GENERIC", {"detail": "Бонус уже получен сегодня"}
        )

    applied = await credit(
        session,
        user_id=user_id,
        amount_minor=state.amount_minor,
        kind=TransactionType.BONUS,
        wallet_kind=WalletKind.BONUS,
        key=f"daily:{user_id}:{day.isoformat()}",
        description="Ежедневный бонус",
    )
    if not applied.applied:
        return ClaimResult(
            False, "ERR_GENERIC", {"detail": "Бонус уже был начислен"}
        )
    return ClaimResult(True, amount_minor=state.amount_minor)


# -------------------------------- кешбэк ----------------------------------

def period_bounds(today: date | None = None) -> tuple[date, date, timedelta]:
    """Текущий период: (начало, конец, оставшееся время до начисления)."""
    today = today or utcnow().date()
    length = max(1, cashback_cfg.PERIOD_DAYS)
    index = today.toordinal() // length
    start = date.fromordinal(index * length)
    end = date.fromordinal((index + 1) * length)
    remaining = timedelta(days=(end - today).days)
    return start, end, remaining


@dataclass
class CashbackState:
    available_minor: int
    total_minor: int
    eta: str
    percent: str
    max_major: int
    min_turnover_major: int


async def cashback_state(session: AsyncSession, user_id: int) -> CashbackState:
    start, end, remaining = period_bounds()
    start_dt = datetime_start(start)
    end_dt = datetime_start(end)
    turnover, loss = await social_repo.period_stats(session, user_id, start_dt, end_dt)

    amount = cashback_cfg.compute(
        cashback_cfg.CashbackInputs(
            turnover=turnover // 100, net_loss=loss // 100, already_paid=0
        )
    )
    item = await social_repo.ensure_cashback(
        session,
        user_id=user_id,
        period_start=start,
        period_end=end,
        turnover_minor=turnover,
        loss_minor=loss,
        percent=cashback_cfg.PERCENT_OF_LOSS,
        amount_minor=to_minor(amount),
    )
    available = item.amount_minor if item.status != "paid" else 0
    total = await social_repo.total_cashback(session, user_id)
    return CashbackState(
        available_minor=available,
        total_minor=total,
        eta=humanize_delta(remaining),
        percent=cashback_cfg.percent_label(),
        max_major=cashback_cfg.MAX_PAYOUT,
        min_turnover_major=cashback_cfg.MIN_TURNOVER,
    )


def datetime_start(value: date):
    from datetime import datetime, time, timezone

    return datetime.combine(value, time.min, tzinfo=timezone.utc)


async def claim_cashback(session: AsyncSession, user_id: int) -> ClaimResult:
    start, _, _ = period_bounds()
    item = await social_repo.current_cashback(session, user_id, start)
    if item is None or item.amount_minor <= 0:
        return ClaimResult(False, "CASHBACK_NOTHING")
    if item.status == "paid":
        return ClaimResult(False, "CASHBACK_NOTHING")

    claimed = await social_repo.claim_cashback(session, item)
    if not claimed:
        return ClaimResult(False, "CASHBACK_NOTHING")

    applied = await credit(
        session,
        user_id=user_id,
        amount_minor=item.amount_minor,
        kind=TransactionType.CASHBACK,
        key=f"cashback:{user_id}:{start.isoformat()}",
        description=f"Кешбэк за период с {start.isoformat()}",
    )
    if not applied.applied:
        return ClaimResult(False, "CASHBACK_NOTHING")

    wallet = await session.get(Wallet, user_id)
    if wallet is not None:
        wallet.cashback_paid += item.amount_minor
        await session.flush()
    return ClaimResult(True, amount_minor=item.amount_minor)

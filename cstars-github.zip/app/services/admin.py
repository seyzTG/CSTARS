"""Административный сервис: статистика, блокировки, коэффициенты, аудит.

Все финансовые действия администратора оставляют запись в admin_actions.
"""

from __future__ import annotations

import json
from collections import deque
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AdminAction, Game, User, Wallet
from app.models.enums import AdminActionType

# последние ошибки — кольцевой буфер (для /errors)
_recent_errors: deque[dict] = deque(maxlen=50)


# ------------------------------- аудит -------------------------------------

async def audit(
    session: AsyncSession,
    *,
    admin_id: int,
    action: AdminActionType,
    target_user_id: int | None = None,
    payload: dict | str | None = None,
) -> None:
    data = payload if isinstance(payload, str) else json.dumps(
        payload or {}, ensure_ascii=False, default=str
    )[:2000]
    session.add(
        AdminAction(
            admin_id=admin_id,
            action=action.value,
            target_user_id=target_user_id,
            payload=data,
            created_at=datetime.now(timezone.utc),
        )
    )
    await session.flush()


async def recent_actions(session: AsyncSession, limit: int = 15) -> list[AdminAction]:
    query = (
        select(AdminAction)
        .order_by(AdminAction.id.desc())
        .limit(limit)
    )
    return list((await session.scalars(query)).all())


# ------------------------------ статистика ---------------------------------

async def stats(session: AsyncSession) -> dict:
    from app.models import GameRound, Payment, Withdrawal
    from app.models.enums import RoundStatus, WithdrawalStatus
    from app.repositories import finance_repo

    users = await session.scalar(select(func_count()))
    totals = await finance_repo.project_totals(session)
    pending = await session.scalar(
        select(func_count()).select_from(Withdrawal).where(
            Withdrawal.status == WithdrawalStatus.PENDING.value
        )
    )
    rounds = await session.scalar(
        select(func_count()).select_from(GameRound).where(
            GameRound.status.in_([RoundStatus.WON.value, RoundStatus.LOST.value])
        )
    )
    return {
        "users": int(users or 0),
        "active": 0,
        "deposited": totals["deposited"],
        "withdrawn": totals["withdrawn"],
        "turnover": totals["turnover"],
        "profit": totals["profit"],
        "pending_wd": int(pending or 0),
        "rounds": int(rounds or 0),
    }


def func_count():
    from sqlalchemy import func

    return func.count()


# ----------------------------- блокировки ----------------------------------

async def set_blocked(
    session: AsyncSession, *, admin_id: int, user_id: int, blocked: bool
) -> bool:
    user = await session.get(User, user_id)
    if user is None:
        return False
    user.is_blocked = blocked
    await session.flush()
    await audit(
        session, admin_id=admin_id,
        action=(AdminActionType.BLOCK_USER if blocked
                else AdminActionType.UNBLOCK_USER),
        target_user_id=user_id,
    )
    return True


async def grant_bonus(
    session: AsyncSession, *, admin_id: int, user_id: int, amount_minor: int
) -> bool:
    from app.models.enums import BonusType

    from app.repositories import social_repo

    wallet = await session.get(Wallet, user_id)
    if wallet is None:
        return False
    bonus = await social_repo.grant_bonus(
        session, user_id=user_id, kind=BonusType.WAGER,
        amount_minor=amount_minor, period_date=None,
        reason=f"Начислено администратором {admin_id}",
    )
    if bonus is None:
        return False
    from app.finance import credit
    from app.models.enums import TransactionType, WalletKind

    await credit(
        session, user_id=user_id, amount_minor=amount_minor,
        kind=TransactionType.BONUS, wallet_kind=WalletKind.BONUS,
        key=f"adminbonus:{bonus.id}",
        description=f"Бонус от администратора {admin_id}",
    )
    await audit(
        session, admin_id=admin_id, action=AdminActionType.GRANT_BONUS,
        target_user_id=user_id, payload={"amount": amount_minor},
    )
    return True


# --------------------------- коэффициенты ----------------------------------

async def set_outcome_coef(
    session: AsyncSession, *, admin_id: int, game_code: str,
    outcome_code: str, value: float,
) -> bool:
    """Изменить коэффициент исхода (хранится в games.config, JSON)."""
    if value <= 0 or value > 10000:
        return False
    game = await session.scalar(select(Game).where(Game.code == game_code))
    if game is None:
        game = Game(code=game_code, title=game_code, kind="builtin")
        session.add(game)
        await session.flush()
    config = dict(game.config or {})
    coefficients = dict(config.get("coefficients") or {})
    coefficients[outcome_code] = float(value)
    config["coefficients"] = coefficients
    game.config = config
    await session.flush()
    await audit(
        session, admin_id=admin_id,
        action=AdminActionType.UPDATE_COEFFICIENTS,
        payload={"game": game_code, "outcome": outcome_code, "value": value},
    )
    return True


async def coefficient_overrides(session: AsyncSession) -> dict[str, dict[str, float]]:
    """{game_code: {outcome_code: coef}} для всех переопределённых игр."""
    query = select(Game).where(Game.config.is_not(None))
    result: dict[str, dict[str, float]] = {}
    for game in (await session.scalars(query)).all():
        coefficients = (game.config or {}).get("coefficients")
        if coefficients:
            result[game.code] = {str(k): float(v) for k, v in coefficients.items()}
    return result


async def effective_coef(
    session: AsyncSession, game_code: str, outcome_code: str, default: float | None
) -> float | None:
    overrides = await coefficient_overrides(session)
    return overrides.get(game_code, {}).get(outcome_code, default)


# --------------------------- просмотр ошибок -------------------------------

def record_error(message: str) -> None:
    _recent_errors.append(
        {"at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
         "message": message[:500]}
    )


def recent_errors() -> list[dict]:
    return list(_recent_errors)

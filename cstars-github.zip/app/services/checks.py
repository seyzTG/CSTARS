"""Сервис персональных чеков.

Правила:
  * чек формируется ТОЛЬКО из собственных средств (бонусные отправить нельзя);
  * сумма ограничена конфигурацией (по умолчанию 1…100 000 ★);
  * токен одноразовый, погашение атомарно — параллельные активации проигрывают;
  * можно привязать чек к Telegram ID и задать срок действия.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import settings
from app.finance import InsufficientFunds, credit, debit
from app.models import Check, Wallet
from app.models.enums import CheckStatus, TransactionType, WalletKind
from app.repositories import check_repo
from app.utils.ids import check_link, new_token, uuid_hex
from app.utils.timeutil import utcnow


@dataclass
class CheckOutcome:
    ok: bool
    error_key: str | None = None
    context: dict | None = None
    check: Check | None = None
    url: str | None = None


async def create_check(
    session: AsyncSession,
    *,
    creator_id: int,
    amount_minor: int,
    target_user_id: int | None = None,
    bot_username: str | None = None,
) -> CheckOutcome:
    from app.utils.money import format_amount

    if amount_minor < settings.check_min * 100:
        return CheckOutcome(
            False, "CHECK_AMOUNT_INVALID", {"min": str(settings.check_min)}
        )
    if amount_minor > settings.check_max * 100:
        return CheckOutcome(
            False, "CHECK_AMOUNT_INVALID", {"max": f"{settings.check_max:,}".replace(",", " ")}
        )

    wallet = await session.get(Wallet, creator_id)
    real_available = wallet.real_balance if wallet else 0
    if amount_minor > real_available:
        return CheckOutcome(
            False,
            "CHECK_BONUS_ONLY",
            {"available": format_amount(real_available)},
        )

    check_id = uuid_hex()
    try:
        await debit(
            session,
            user_id=creator_id,
            amount_minor=amount_minor,
            kind=TransactionType.CHECK_CREATE,
            wallet_kind=WalletKind.REAL,
            key=f"check:{check_id}",
            description=f"Создание чека на {format_amount(amount_minor)} ★",
            check_id=check_id,
        )
    except InsufficientFunds:
        return CheckOutcome(
            False,
            "CHECK_BONUS_ONLY",
            {"available": format_amount(real_available)},
        )

    token = await _unique_token(session)
    item = await check_repo.create_check(
        session,
        check_id=check_id,
        token=token,
        creator_id=creator_id,
        amount_minor=amount_minor,
        target_user_id=target_user_id or None,
        expires_at=utcnow() + timedelta(hours=settings.check_ttl_hours),
    )
    url = check_link(bot_username or "", token) if bot_username else None
    return CheckOutcome(True, check=item, url=url)


async def _unique_token(session: AsyncSession) -> str:
    for _ in range(25):
        token = new_token(20)
        if await check_repo.get_by_token(session, token) is None:
            return token
    raise RuntimeError("unable to allocate check token")


async def activate_check(
    session: AsyncSession, *, user_id: int, token: str
) -> CheckOutcome:
    """Активировать чек. Параллельные погашения исключены условным UPDATE."""
    item = await check_repo.get_by_token(session, token)
    if item is None:
        return CheckOutcome(False, "CHECK_NOT_FOUND")

    if item.status == CheckStatus.REDEEMED.value:
        return CheckOutcome(False, "CHECK_ALREADY")
    if item.status == CheckStatus.CANCELLED.value:
        return CheckOutcome(False, "CHECK_NOT_FOUND")
    if item.status == CheckStatus.EXPIRED.value:
        return CheckOutcome(False, "CHECK_EXPIRED")
    if item.expires_at <= utcnow():
        await check_repo.mark_expired(session, item)
        return CheckOutcome(False, "CHECK_EXPIRED")
    if item.creator_id == user_id:
        return CheckOutcome(False, "CHECK_SELF")
    if item.target_user_id is not None and item.target_user_id != user_id:
        return CheckOutcome(False, "CHECK_WRONG_TARGET")

    # фиксируем значения ДО обновления/expire — иначе доступ к атрибутам
    # истёкшего объекта инициирует синхронную загрузку (MissingGreenlet)
    check_id, amount_minor = item.id, item.amount_minor

    # атомарный переход active → redeemed (защита от одновременного погашения)
    result = await session.execute(
        update(Check)
        .where(Check.id == check_id, Check.status == CheckStatus.ACTIVE.value)
        .values(
            status=CheckStatus.REDEEMED.value,
            redeemed_by=user_id,
            redeemed_at=utcnow(),
        )
        .execution_options(synchronize_session=False)
    )
    if result.rowcount == 0:
        session.expire_all()
        return CheckOutcome(False, "CHECK_ALREADY")

    applied = await credit(
        session,
        user_id=user_id,
        amount_minor=amount_minor,
        kind=TransactionType.CHECK_REDEEM,
        key=f"check_redeem:{check_id}",
        description="Активация чека",
        check_id=check_id,
    )
    if not applied.applied:
        return CheckOutcome(False, "CHECK_ALREADY")

    session.expire_all()
    fresh = await check_repo.get_by_id(session, check_id)
    return CheckOutcome(True, check=fresh)


async def cancel_check(
    session: AsyncSession, *, creator_id: int, check_id: str
) -> CheckOutcome:
    item = await check_repo.get_by_id(session, check_id)
    if item is None or item.creator_id != creator_id:
        return CheckOutcome(False, "CHECK_NOT_FOUND")
    if item.status != CheckStatus.ACTIVE.value:
        return CheckOutcome(False, "CHECK_ALREADY")

    check_id, amount_minor = item.id, item.amount_minor

    result = await session.execute(
        update(Check)
        .where(Check.id == check_id, Check.status == CheckStatus.ACTIVE.value)
        .values(status=CheckStatus.CANCELLED.value, cancelled_at=utcnow())
        .execution_options(synchronize_session=False)
    )
    if result.rowcount == 0:
        session.expire_all()
        return CheckOutcome(False, "CHECK_ALREADY")

    await credit(
        session,
        user_id=creator_id,
        amount_minor=amount_minor,
        kind=TransactionType.CHECK_CANCEL,
        key=f"check_cancel:{check_id}",
        description="Отмена чека — возврат средств",
        check_id=check_id,
    )
    session.expire_all()
    fresh = await check_repo.get_by_id(session, check_id)
    return CheckOutcome(True, check=fresh)

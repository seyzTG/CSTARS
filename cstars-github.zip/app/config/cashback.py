"""Параметры кешбэка.

Подтверждено референсом:
  * на экране есть «Доступно — X ★», «За всё время — X ★»,
    обратный отсчёт до начисления за текущий период и кнопка получения;
  * кешбэк — самостоятельная система, независимая от ежедневного бонуса.

Формула процента, лимит и длина периода на записи не раскрывались —
всё вынесено сюда (значения по умолчанию НЕПОДТВЕРЖДЕНЫ).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

# Длительность расчётного периода (НЕПОДТВЕРЖДЕНО: на записи виден только
# обратный отсчёт «через 1 день 9 часов 57 минут»).
PERIOD_DAYS = 3

# Процент кешбэка с фактически проигранной суммы за период (НЕПОДТВЕРЖДЕНО)
PERCENT_OF_LOSS = 2.0

# Окно учёта оборота, с которого вообще считается кешбэк (НЕПОДТВЕРЖДЕНО)
MIN_TURNOVER = 10

# Максимальное начисление за один период (НЕПОДТВЕРЖДЕНО)
MAX_PAYOUT = 10_000

# Зачёт уже выплаченного кешбэка в новый период (НЕПОДТВЕРЖДЕНО)
CARRY_OVER = False


def period_delta() -> timedelta:
    return timedelta(days=PERIOD_DAYS)


@dataclass(frozen=True)
class CashbackInputs:
    turnover: int      # игровой оборот за период
    net_loss: int      # проигрыш за период (>= 0)
    already_paid: int  # выплачено за этот период


def compute(inputs: CashbackInputs) -> int:
    """Сумма кешбэка за период. Не может превышать MAX_PAYOUT."""
    if inputs.turnover < MIN_TURNOVER or inputs.net_loss <= 0:
        return 0
    amount = inputs.net_loss * PERCENT_OF_LOSS / 100.0
    if not CARRY_OVER:
        amount = max(0.0, amount - inputs.already_paid)
    return int(min(MAX_PAYOUT, amount))


def percent_label() -> str:
    return f"{PERCENT_OF_LOSS:g}%"

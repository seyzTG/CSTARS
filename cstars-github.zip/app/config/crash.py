"""Crash: параметры полёта ракеты.

Все значения вынесены в ``.env`` (см. settings.py), чтобы менять механику
без правки обработчиков. Точка взрыва и задержки тиков генерируются
криптостойким генератором ``secrets`` (см. games/crash.py).
"""

from __future__ import annotations

from dataclasses import dataclass

from app.config.settings import settings


@dataclass(frozen=True)
class CrashConfig:
    """Неизменяемая конфигурация одного полёта."""

    min_multiplier: float
    max_multiplier: float
    house_edge: float
    flight_min_seconds: float
    flight_max_seconds: float
    tick_min_seconds: float
    tick_max_seconds: float


def get_crash_config() -> CrashConfig:
    """Собрать конфигурацию из настроек приложения (с защитой от опечаток)."""
    min_mult = max(1.01, float(settings.crash_min_multiplier))
    max_mult = max(min_mult, float(settings.crash_max_multiplier))
    house_edge = min(0.5, max(0.0, float(settings.crash_house_edge)))

    flight_min = max(1.0, float(settings.crash_flight_min_seconds))
    flight_max = max(flight_min, float(settings.crash_flight_max_seconds))

    tick_min = max(0.1, float(settings.crash_tick_min_seconds))
    tick_max = max(tick_min, float(settings.crash_tick_max_seconds))

    return CrashConfig(
        min_multiplier=min_mult,
        max_multiplier=max_mult,
        house_edge=house_edge,
        flight_min_seconds=flight_min,
        flight_max_seconds=flight_max,
        tick_min_seconds=tick_min,
        tick_max_seconds=tick_max,
    )


__all__ = ["CrashConfig", "get_crash_config"]

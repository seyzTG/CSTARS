"""Централизованный каталог Telegram Premium Custom Emoji.

ВАЖНО (согласно ТЗ):
  * Custom Emoji нельзя произвольно создать через Bot API — нужны реальные
    ``custom_emoji_id`` из проверенного каталога/конфигурации.
  * Выдуманные идентификаторы СЮДА не вшиты намеренно: если ID не задан,
    используется настраиваемый Unicode-резервный вариант.
  * ID можно назначить, не меняя код обработчиков:
      1) переменная окружения CUSTOM_EMOJI_IDS_JSON='{"star":"5368324170675496222", ...}'
      2) или отредактировать DEFAULT_CUSTOM_EMOJI_IDS ниже.

Роль -> рекомендуемый Unicode-резерв и пример ID.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from app.config.settings import settings

# role -> fallback unicode (резерв, отображается когда ID не задан/не принят)
EMOJI_FALLBACK: dict[str, str] = {
    "star": "⭐",
    "balance": "💰",
    "profile": "👤",
    "games": "🎮",
    "dice": "🎲",
    "football": "⚽",
    "basketball": "🏀",
    "darts": "🎯",
    "bowling": "🎳",
    "slots": "🎰",
    "blackjack": "🃏",
    "crash": "🚀",
    "deposit": "💵",
    "withdraw": "🏦",
    "cashback": "🎁",
    "referral": "🤝",
    "checks": "🧾",
    "top": "👑",
    "settings": "⚙️",
    "error": "❌",
    "success": "✅",
    "warning": "⚠️",
    "back": "↩️",
    "menu": "☰",
    "info": "ℹ️",
    "gift": "🎁",
    "bonus": "🎁",
    "privacy": "👁",
    "clock": "⏱",
    "chart": "📈",
    "trophy": "🏆",
    "edit": "✏️",
    "send": "📤",
    "copy": "📋",
    "link": "🔗",
    "shield": "🛡",
    "fire": "🔥",
    "memo": "📝",
    "money": "💵",
    "arrow": "➤",
    "crown": "👑",
    "gift_box": "🎁",
    "calendar": "📅",
    "id": "🆔",
    "turnover": "📊",
    "games_played": "🎮",
}

# role -> реальный custom_emoji_id (пусто по умолчанию: см. docstring)
DEFAULT_CUSTOM_EMOJI_IDS: dict[str, str] = {}


@dataclass(frozen=True)
class Emoji:
    """Готовый к выводу эмодзи: ID (если есть) + Unicode-резерв."""

    role: str
    custom_id: str | None
    fallback: str

    @property
    def has_custom(self) -> bool:
        return bool(self.custom_id)


def _load_overrides() -> dict[str, str]:
    raw = (settings.custom_emoji_ids_json or "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): str(v) for k, v in data.items()}


_OVERRIDES = _load_overrides()


def emoji(role: str) -> Emoji:
    """Вернуть эмодзи по роли: сначала переопределение из окружения,
    затем каталог по умолчанию, затем Unicode-резерв."""
    custom_id = _OVERRIDES.get(role) or DEFAULT_CUSTOM_EMOJI_IDS.get(role) or None
    fallback = EMOJI_FALLBACK.get(role, "•")
    return Emoji(role=role, custom_id=custom_id, fallback=fallback)


def resolve_id(role: str) -> str | None:
    return emoji(role).custom_id


def known_roles() -> list[str]:
    return sorted(EMOJI_FALLBACK)

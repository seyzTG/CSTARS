"""Правила и коэффициенты игровых режимов.

ФИЛЬТР ДОСТОВЕРНОСТИ
--------------------
* ``verified=True``  — параметр виден на референсе (видеозапись @kuki_app).
* ``verified=False`` — параметр НЕ подтверждён референсом. Он вынесен в эту
  конфигурацию и может быть изменён без правки обработчиков.
* Сопоставление значений Telegram Dice (``value_map``) не видно на записи:
  оно помечено как непроверенное. Если выпавшее значение не сопоставлено,
  раунд считается ничьей и ставка возвращается (см. games/engine.py).

Коэффициенты подменю «Тотал»/«Диапазон» на референсе не открыты, поэтому
вычисляются из истинной вероятности и модели выплат ``TOTAL_RTP_MODEL``
(настраивается), если для события не задан явный коэффициент.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from itertools import product as _product
from typing import Iterable

# Модель выплат для событий без явного коэффициента (RTP).
TOTAL_RTP_MODEL = 0.95

# --- Кости: коэффициенты, заданные ЯВНО для каждого количества кубиков ---
# Нельзя переносить коэффициенты одного режима на другой автоматически.
DICE_COUNTS: tuple[int, ...] = (1, 2, 3)

DICE_COEFFICIENTS: dict[int, dict[str, float]] = {
    # verified: Чётное/Нечётное ×1.8, конкретное число ×5.4 (режим «1 Куб»)
    1: {"even": 1.8, "odd": 1.8, "number": 5.4},
    # непроверенные значения: вероятность чёт/нечет суммы всегда 1/2;
    # «число хотя бы на одном кубике» p=11/36 и 1-(5/6)^3 соответственно.
    2: {"even": 1.8, "odd": 1.8, "number": 3.2},
    3: {"even": 1.8, "odd": 1.8, "number": 2.3},
}

# Подменю «Тотал»: событие = точная сумма. Коэффициент = (1/p) * TOTAL_RTP_MODEL.
DICE_TOTALS: dict[int, tuple[int, ...]] = {
    1: tuple(range(1, 7)),
    2: tuple(range(2, 13)),
    3: tuple(range(3, 19)),
}

# Подменю «Диапазон»: (заголовок кнопки, от, до) — по умолчанию, непроверено.
DICE_RANGES: dict[int, tuple[tuple[str, int, int], ...]] = {
    1: (("1–2", 1, 2), ("3–4", 3, 4), ("5–6", 5, 6)),
    2: (("2–6", 2, 6), ("7", 7, 7), ("8–12", 8, 12)),
    3: (("3–9", 3, 9), ("10–12", 10, 12), ("13–18", 13, 18)),
}


# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Outcome:
    """Исход игры: код, подпись на кнопке, коэффициент и правила победы."""

    code: str
    label: str
    coef: float | None                 # None => вычислить из вероятности
    verified: bool = False
    hidden: bool = False               # не показывать кнопку (см. боулинг 2/6)
    dice_values: tuple[int, ...] = ()  # прямое соответствие значению Dice
    group: str | None = None           # группировка исходов (для костей: even/odd/...)

    @property
    def coef_label(self) -> str:
        return f"×{self.coef:g}" if self.coef is not None else ""


@dataclass(frozen=True)
class GameSpec:
    code: str
    title: str
    emoji_role: str            # роль в каталоге custom emoji
    dice_emoji: str            # эмодзи для send_dice
    outcomes: tuple[Outcome, ...]
    value_map: dict[int, str] = field(default_factory=dict)
    # второй бросок, классифицирующий результат (футбол)
    classification_map: dict[int, str] | None = None
    classification_roles: dict[str, str] = field(default_factory=dict)
    dice_counts: tuple[int, ...] = ()
    verified: bool = False

    def outcome(self, code: str) -> Outcome | None:
        for item in self.outcomes:
            if item.code == code:
                return item
        return None

    def visible_outcomes(self) -> list[Outcome]:
        return [o for o in self.outcomes if not o.hidden]


# --------------------------- вероятности для кубиков ------------------------

def sum_ways(count: int, target: int) -> int:
    """Число способов получить сумму ``target`` на ``count`` кубиках (1..6)."""
    return sum(1 for combo in _product(range(1, 7), repeat=count) if sum(combo) == target)


def total_outcomes(count: int) -> tuple[Outcome, ...]:
    """Исходы подменю «Тотал» с коэффициентом из модели выплат."""
    total = 6 ** count
    result: list[Outcome] = []
    for value in DICE_TOTALS.get(count, ()):
        ways = sum_ways(count, value)
        if not ways:
            continue
        coef = round((total / ways) * TOTAL_RTP_MODEL, 2)
        result.append(
            Outcome(
                code=f"total_{value}",
                label=f"Тотал {value}",
                coef=coef,
                verified=False,
                group="total",
            )
        )
    return tuple(result)


def range_outcomes(count: int) -> tuple[Outcome, ...]:
    """Исходы подменю «Диапазон»."""
    total = 6 ** count
    result: list[Outcome] = []
    for label, low, high in DICE_RANGES.get(count, ()):
        ways = sum(sum_ways(count, v) for v in range(low, high + 1))
        if not ways:
            continue
        coef = round((total / ways) * TOTAL_RTP_MODEL, 2)
        result.append(
            Outcome(
                code=f"range_{low}_{high}",
                label=label,
                coef=coef,
                verified=False,
                group="range",
            )
        )
    return tuple(result)


def number_outcomes(count: int) -> tuple[Outcome, ...]:
    """Числа 1–6: выпало ли хотя бы на одном кубике (для 1 куба — точное)."""
    coef = DICE_COEFFICIENTS.get(count, {}).get("number")
    return tuple(
        Outcome(
            code=f"number_{n}",
            label=f"{n} (×{coef:g})",
            coef=coef,
            verified=count == 1,
            group="number",
        )
        for n in range(1, 7)
    )


def dice_outcomes(count: int) -> tuple[Outcome, ...]:
    """Полный набор исходов для выбранного количества кубиков."""
    coefs = DICE_COEFFICIENTS.get(count, DICE_COEFFICIENTS[1])
    prefix = "" if count == 1 else f"{count}_"
    return (
        Outcome(code=f"{prefix}even", label=f"Чётное (×{coefs['even']:g})",
                coef=coefs["even"], verified=count == 1, group="parity"),
        Outcome(code=f"{prefix}odd", label=f"Нечётное (×{coefs['odd']:g})",
                coef=coefs["odd"], verified=count == 1, group="parity"),
        *number_outcomes(count),
        *total_outcomes(count),
        *range_outcomes(count),
    )


# ------------------------------- игры --------------------------------------

FOOTBALL = GameSpec(
    code="football",
    title="Футбол",
    emoji_role="football",
    dice_emoji="⚽",
    verified=True,                       # названия и коэффициенты видны на записи
    # официальный ⚽: 4–5 — гол, 1–3 — промах/штанга; второй бросок уточняет
    # подвид гола (значения 1–5, поэтому 5 тоже сопоставлен)
    value_map={1: "miss", 2: "miss", 3: "post", 4: "goal", 5: "goal"},
    classification_map={1: "corner", 2: "corner", 3: "goal_post",
                        4: "center", 5: "goal_post"},
    classification_roles={"center": "Гол в центр", "goal_post": "Гол от штанги",
                          "corner": "Гол в угол"},
    outcomes=(
        Outcome("goal", "Гол", 1.5, verified=True),
        Outcome("miss", "Промах", 2.25, verified=True),
        Outcome("goal_center", "Гол в центр", 4.5, verified=True),
        Outcome("goal_post", "Гол от штанги", 4.5, verified=True),
        Outcome("goal_corner", "Гол в угол", 4.5, verified=True),
        Outcome("post", "Штанга", 4.5, verified=True),
    ),
)

BASKETBALL = GameSpec(
    code="basketball",
    title="Баскетбол",
    emoji_role="basketball",
    dice_emoji="🏀",
    verified=False,                      # на референсе вкладка не открывалась
    value_map={1: "miss", 2: "miss", 3: "basket", 4: "basket", 5: "three"},
    outcomes=(
        Outcome("miss", "Мимо", 1.8, verified=False),
        Outcome("basket", "Попадание", 1.8, verified=False),
        Outcome("three", "Три очка", 4.5, verified=False),
    ),
)

DARTS = GameSpec(
    code="darts",
    title="Дартс",
    emoji_role="darts",
    dice_emoji="🎯",
    verified=True,                       # подписи и коэффициенты видны на записи
    # официальный 🎯: 6 — буллзе (центр), 1 — промах; остальные — сектора
    value_map={1: "bounce", 2: "white", 3: "red", 4: "white", 5: "red",
               6: "center"},
    outcomes=(
        Outcome("center", "В центр (×5.4)", 5.4, verified=True),
        Outcome("white", "Белое (×2.7)", 2.7, verified=True),
        Outcome("red", "Красное (×1.8)", 1.8, verified=True),
        Outcome("bounce", "Отскок (×5.4)", 5.4, verified=True),
    ),
)

BOWLING = GameSpec(
    code="bowling",
    title="Боулинг",
    emoji_role="bowling",
    dice_emoji="🎳",
    verified=True,
    # непроверено: 1 — промах, 2..5 — сбито N/6, 6 — страйк
    value_map={1: "miss", 2: "pins_1", 3: "pins_3", 4: "pins_4", 5: "pins_5", 6: "strike"},
    outcomes=(
        Outcome("miss", "Промах", 5.4, verified=True),
        Outcome("strike", "Страйк", 5.4, verified=True),
        Outcome("pins_1", "Сбито 1/6", 5.4, verified=True),
        Outcome("pins_3", "Сбито 3/6", 5.4, verified=True),
        Outcome("pins_4", "Сбито 4/6", 5.4, verified=True),
        Outcome("pins_5", "Сбито 5/6", 5.4, verified=True),
        # на референсе кнопка «Сбито 2/6» отсутствует — исход скрыт,
        # но определён, чтобы расчёт оставался полным при перенастройке value_map.
        Outcome("pins_2", "Сбито 2/6", 5.4, verified=False, hidden=True),
    ),
)

SLOTS = GameSpec(
    code="slots",
    title="Слоты",
    emoji_role="slots",
    dice_emoji="🎰",
    verified=True,                       # подписи и коэффициенты видны на записи
    # Официальный 🎰 Telegram Dice: значение 1..64 закодировано тремя
    # барабанами по 4 символа (bar/grape/lemon/seven). Тройки:
    #   1  = BAR BAR BAR
    #   22 = виноград ×3
    #   43 = лимон ×3
    #   64 = семёрка ×3
    # Остальные значения (7..64, кроме троек) — без тройки.
    value_map={1: "bars", 22: "grapes", 43: "lemons", 64: "sevens"},
    outcomes=(
        Outcome("sevens", "3 Семёрок", 57.6, verified=True),
        Outcome("bars", "3 Бара", 57.6, verified=True),
        Outcome("lemons", "3 Лимона", 57.6, verified=True),
        Outcome("grapes", "3 Винограда", 57.6, verified=True),
        Outcome("any_combination", "Любая комбинация", 14.4, verified=True),
        # подменю «Другое »
        Outcome("pair", "Пара", 1.44, verified=False, hidden=True,
                group="other"),
        Outcome("two_sevens", "Две семёрки", 6.4, verified=False, hidden=True,
                group="other"),
        Outcome("all_different", "Все разные", 2.4, verified=False, hidden=True,
                group="other"),
    ),
)

BLACKJACK = GameSpec(
    code="blackjack",
    title="21 Очко",
    emoji_role="blackjack",
    dice_emoji="🃏",
    verified=False,                      # механика своя, референс не открывался
    # ставка на раздачу: победа ×2, ничья — возврат (см. handlers/blackjack.py)
    outcomes=(
        Outcome("play", "21 Очко", 2.0, verified=False),
    ),
    value_map={},
)

DICE = GameSpec(
    code="dice",
    title="Кости",
    emoji_role="dice",
    dice_emoji="🎲",
    verified=True,
    dice_counts=DICE_COUNTS,
    outcomes=dice_outcomes(1),
    value_map={},
)

CRASH = GameSpec(
    code="crash",
    title="Crash",
    emoji_role="crash",
    dice_emoji="🚀",
    verified=False,                      # механика своя, референс не открывался
    # исход один: игрок забирает выигрыш по текущему множителю до взрыва
    # (коэффициент динамический, задаётся полётом — см. games/crash.py)
    outcomes=(
        Outcome("cashout", "Забрать", None, verified=False),
    ),
    value_map={},
)

GAMES: dict[str, GameSpec] = {
    g.code: g
    for g in (DICE, FOOTBALL, BASKETBALL, DARTS, BOWLING, SLOTS, BLACKJACK, CRASH)
}

# Порядок вкладок на игровой панели (как на референсе + «21 Очко» + «Crash»)
GAME_TAB_ORDER: tuple[str, ...] = (
    "dice", "football", "basketball", "darts", "bowling", "slots", "blackjack",
    "crash",
)


def outcomes_for(game_code: str, dice_count: int = 1) -> tuple[Outcome, ...]:
    """Актуальный набор исходов (для костей зависит от количества кубиков)."""
    if game_code == "dice":
        return dice_outcomes(dice_count)
    spec = GAMES.get(game_code)
    return spec.outcomes if spec else ()


def outcome_by_code(game_code: str, code: str, dice_count: int = 1) -> Outcome | None:
    for item in outcomes_for(game_code, dice_count):
        if item.code == code:
            return item
    return None


def visible_outcomes(game_code: str, dice_count: int = 1) -> list[Outcome]:
    return [o for o in outcomes_for(game_code, dice_count) if not o.hidden]


def unverified_parameters() -> list[str]:
    """Список параметров, не подтверждённых референсом (для отчёта/документации)."""
    lines: list[str] = []
    for code, spec in GAMES.items():
        for outcome in spec.outcomes:
            if not outcome.verified:
                lines.append(f"{code}: исход '{outcome.label}' — коэффициент не подтверждён")
        if not spec.verified:
            lines.append(f"{code}: набор исходов в целом не подтверждён")
        if spec.value_map:
            lines.append(f"{code}: соответствие значений Telegram Dice — не подтверждено")
    lines.append("Кости: коэффициенты для 2 и 3 кубиков не подтверждены")
    lines.append("Кости: состав подменю «Тотал»/«Диапазон» не подтверждён")
    return lines


def iter_all_outcomes() -> Iterable[tuple[str, Outcome]]:
    for code, spec in GAMES.items():
        for outcome in spec.outcomes:
            yield code, outcome

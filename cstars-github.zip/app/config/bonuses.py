"""Формула и условия ежедневного бонуса.

На референсе подтверждено только:
  * бонус зависит от суммы пополнений и активности за последние 14 дней;
  * условие выдачи: баланс должен быть меньше 1 ★;
  * при нарушении условия показывается сообщение о причине отказа.

Конкретная формула размера на записи не раскрывалась — поэтому вся математика
лежит ЗДЕСЬ и настраивается без правки обработчиков. Значения по умолчанию
помечены как НЕПОДТВЕРЖДЁННЫЕ.
"""

from __future__ import annotations

from dataclasses import dataclass

# Окно анализа (подтверждено референсом)
ACTIVITY_WINDOW_DAYS = 14

# Условие выдачи (подтверждено референсом): баланс строго меньше этого значения
MAX_BALANCE_FOR_BONUS = 1          # в единицах (звёздах)

# Ограничение: сколько раз можно получить бонус в течение суток (НЕПОДТВЕРЖДЕНО)
CLAIMS_PER_DAY = 1

# --- Параметры размера бонуса (НЕПОДТВЕРЖДЕНО) ---
BASE_BONUS = 1                      # базовая часть
PER_DEPOSIT_PERCENT = 0.005          # 0.5% от суммы пополнений за окно
PER_GAME_BONUS = 0.01               # 0.01★ за каждую сыгранную игру за окно
MIN_BONUS = 1                        # минимум
MAX_BONUS = 100                      # максимум


@dataclass(frozen=True)
class BonusInputs:
    """Данные пользователя за окно ACTIVITY_WINDOW_DAYS."""

    deposits: int          # сумма пополнений (целые единицы)
    games_played: int      # число сыгранных игр
    balance: int           # текущий баланс (целые единицы)


def eligible(inputs: BonusInputs) -> tuple[bool, str]:
    """Право на бонус + причина отказа (для показа пользователю)."""
    if inputs.balance >= MAX_BALANCE_FOR_BONUS:
        return False, (
            f"Для получения бонуса баланс должен быть меньше "
            f"{MAX_BALANCE_FOR_BONUS} ★"
        )
    return True, ""


def compute_amount(inputs: BonusInputs) -> int:
    """Размер бонуса. Формула настраивается, значения по умолчанию непроверены."""
    amount = (
        BASE_BONUS
        + inputs.deposits * PER_DEPOSIT_PERCENT
        + inputs.games_played * PER_GAME_BONUS
    )
    amount = max(MIN_BONUS, min(MAX_BONUS, amount))
    return int(amount)


def describe() -> str:
    """Человекочитаемое описание условий (для экрана бонуса)."""
    return (
        f"Размер бонуса зависит от общей суммы пополнений и вашей активности "
        f"в боте за последние {ACTIVITY_WINDOW_DAYS} дней."
    )

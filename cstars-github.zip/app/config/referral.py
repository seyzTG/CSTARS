"""Параметры реферальной программы.

Подтверждено референсом:
  * вознаграждение — 35% от прибыли проекта со ставок приглашённых
    пользователей за вычетом бонусов;
  * ссылка вида https://t.me/<BOT_USERNAME>?start=<REFERRAL_TOKEN>;
  * статистика: приглашено / заработано / доступно к выплате.

ВАЖНО: процент применяется к ПРИБЫЛИ ПРОЕКТА, а не к каждой ставке.
Поэтому здесь задаётся формула, а не фиксированное начисление за ставку.
"""

from __future__ import annotations

from dataclasses import dataclass

# Доля прибыли проекта, выплачиваемая партнёру (подтверждено: 35%)
DEFAULT_PERCENT = 35.0

# Доля прибыли проекта в ставке (house edge). НЕПОДТВЕРЖДЕНО — настраивается.
# Прибыль = ставка игрока * HOUSE_EDGE - выплаченный выигрыш.
HOUSE_EDGE = 0.05

# Бонусы, выданные игроку, вычитаются из прибыли ДО расчёта доли партнёра
# (подтверждено: «за вычетом бонусов»).
DEDUCT_BONUSES = True


@dataclass(frozen=True)
class RoundProfit:
    """Итог одного раунда глазами проекта."""

    stake: int           # сумма ставки
    payout: int          # выплаченный выигрыш
    bonus_spent: int     # сколько бонусных единиц списано в ставку

    @property
    def gross(self) -> int:
        """Вклад ставки в прибыль до вычета бонусов."""
        return int(round(self.stake * HOUSE_EDGE)) - self.payout

    @property
    def net(self) -> int:
        if DEDUCT_BONUSES:
            return self.gross - self.bonus_spent
        return self.gross


def reward_for(round_profit: RoundProfit, percent: float = DEFAULT_PERCENT) -> int:
    """Вознаграждение партнёра за один раунд.

    Отрицательный результат (убыток проекта) даёт отрицательное/нулевое
    вознаграждение — оно НЕ обнуляется молча, а суммируется с накопителем,
    чтобы компенсироваться будущей прибылью (см. referral_service).
    """
    return int(round(round_profit.net * percent / 100.0))


def formula_text(percent: float = DEFAULT_PERCENT) -> str:
    return (
        "(ставка × прибыль проекта − бонусы) ÷ 2 × "
        f"{percent:g}% = заработок по программе"
    )

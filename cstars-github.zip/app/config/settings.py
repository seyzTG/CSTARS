"""Настройки приложения (Pydantic Settings, чтение из переменных окружения)."""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- Основное ---
    bot_token: str = Field(default="0:TEST-TOKEN", alias="BOT_TOKEN")
    bot_username: str = Field(default="YourBotUsername", alias="BOT_USERNAME")
    env: Literal["dev", "prod"] = Field(default="dev", alias="ENV")
    admin_ids: list[int] = Field(default_factory=list, alias="ADMIN_IDS")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # --- База данных ---
    db_host: str = Field(default="localhost", alias="DB_HOST")
    db_port: int = Field(default=5432, alias="DB_PORT")
    db_name: str = Field(default="kuki", alias="DB_NAME")
    db_user: str = Field(default="kuki", alias="DB_USER")
    db_password: str = Field(default="", alias="DB_PASSWORD")
    db_echo: bool = Field(default=False, alias="DB_ECHO")
    database_url: str | None = Field(default=None, alias="DATABASE_URL")

    # --- Redis ---
    redis_url: str = Field(default="redis://localhost:6379/0", alias="REDIS_URL")
    use_redis: bool = Field(default=False, alias="USE_REDIS")

    # --- Платежи ---
    stars_enabled: bool = Field(default=True, alias="STARS_ENABLED")
    units_per_star: float = Field(default=1.0, alias="UNITS_PER_STAR")

    cryptobot_api_key: str = Field(default="", alias="CRYPTOBOT_API_KEY")
    cryptobot_api_url: str = Field(
        default="https://api.cryptobot.pay", alias="CRYPTOBOT_API_URL"
    )

    xrocket_api_key: str = Field(default="", alias="XROCKET_API_KEY")
    xrocket_api_url: str = Field(
        default="https://api.xrocket.me", alias="XROCKET_API_URL"
    )

    crypto_external_enabled: bool = Field(default=False, alias="CRYPTO_EXTERNAL_ENABLED")
    gifts_enabled: bool = Field(default=False, alias="GIFTS_ENABLED")

    # --- Premium Custom Emoji ---
    custom_emoji_ids_json: str = Field(default="", alias="CUSTOM_EMOJI_IDS_JSON")

    # --- Игры ---
    bet_min: int = Field(default=1, alias="BET_MIN")
    bet_max: int = Field(default=5000, alias="BET_MAX")

    # --- Crash ---
    crash_min_multiplier: float = Field(default=1.15, alias="CRASH_MIN_MULTIPLIER")
    crash_max_multiplier: float = Field(default=500.0, alias="CRASH_MAX_MULTIPLIER")
    crash_house_edge: float = Field(default=0.03, alias="CRASH_HOUSE_EDGE")
    crash_flight_min_seconds: float = Field(default=8.0, alias="CRASH_FLIGHT_MIN_SECONDS")
    crash_flight_max_seconds: float = Field(default=40.0, alias="CRASH_FLIGHT_MAX_SECONDS")
    crash_tick_min_seconds: float = Field(default=1.5, alias="CRASH_TICK_MIN_SECONDS")
    crash_tick_max_seconds: float = Field(default=2.0, alias="CRASH_TICK_MAX_SECONDS")

    # --- Рефералы ---
    referral_percent: float = Field(default=35.0, alias="REFERRAL_PERCENT")

    # --- Чеки ---
    check_min: int = Field(default=1, alias="CHECK_MIN")
    check_max: int = Field(default=100_000, alias="CHECK_MAX")
    check_ttl_hours: int = Field(default=168, alias="CHECK_TTL_HOURS")

    # --- Вывод ---
    withdraw_min: int = Field(default=1, alias="WITHDRAW_MIN")
    withdraw_max: int = Field(default=100_000, alias="WITHDRAW_MAX")
    withdraw_commission_percent: float = Field(
        default=0.0, alias="WITHDRAW_COMMISSION_PERCENT"
    )

    # --- Служебное ---
    rate_limit_per_second: float = Field(default=3.0, alias="RATE_LIMIT_PER_SECOND")
    auto_create_tables: bool = Field(default=True, alias="AUTO_CREATE_TABLES")

    # ---------------- Validators ----------------
    @field_validator("admin_ids", mode="before")
    @classmethod
    def _split_admin_ids(cls, value: object) -> object:
        if isinstance(value, str):
            raw = value.replace(";", ",").replace(" ", ",")
            return [int(p) for p in raw.split(",") if p.strip().lstrip("-").isdigit()]
        if isinstance(value, (int, float)):
            return [int(value)]
        if isinstance(value, (list, tuple, set)):
            return [int(v) for v in value]
        return value

    @property
    def is_admin(self) -> list[int]:
        return self.admin_ids

    @property
    def database_dsn(self) -> str:
        if self.database_url:
            return self.database_url
        return (
            f"postgresql+asyncpg://{self.db_user}:{self.db_password}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

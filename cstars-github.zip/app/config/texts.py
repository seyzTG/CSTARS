"""Все тексты интерфейса бота.

Формат — собственная мини-разметка, разбираемая в ``app/utils/format.py``:
  <b> <i> <u> <s> <code> <a href="..."> <blockquote> и плейсхолдеры {{e:роль}}.

Плейсхолдер {{e:роль}} подставляет Telegram Premium Custom Emoji, если для роли
задан реальный custom_emoji_id, иначе — Unicode-резерв (см. config/custom_emojis.py).

Короткие подписи кнопок и полей повторяют референс. Длинные пояснительные
абзацы сформулированы на их основе (структура и смысл совпадают).
"""

from __future__ import annotations

from app.config import bonuses as bonus_cfg
from app.config import cashback as cashback_cfg
from app.config import referral as ref_cfg

BOT_NAME = "CSTARS"
CHANNEL_URL = "https://t.me/your_channel"   # замените на свой канал (настраивается)
SUPPORT_URL = "https://t.me/your_support"   # замените на свой контакт поддержки

# ------------------------------ старт / меню -------------------------------

WELCOME = "Добро пожаловать, <b>{name}</b>!"

MENU = (
    "<blockquote>{{e:star}} <b>Добро пожаловать в {bot}!</b></blockquote>\n"
    "<blockquote>{{e:send}} Подписывайтесь на <a href=\"{channel}\">наш канал</a>, "
    "чтобы первыми узнавать о новостях, конкурсах и розыгрышах</blockquote>"
)

# ------------------------------ клавиатуры ---------------------------------

KB_PLAY = "Играть"
KB_PROFILE = "Профиль"
KB_BALANCE = "Баланс"
KB_MENU = "Меню"
KB_BACK = "‹ Назад"
KB_CANCEL = "Отменить"

BTN_DEPOSIT = "Пополнить"
BTN_WITHDRAW = "Вывести"
BTN_CASHBACK = "Кешбэк"
BTN_PRIVACY = "Приватность"

BTN_PARTNER = "Партнёрская программа"
BTN_DAILY_BONUS = "Ежедневный бонус"
BTN_CHECKS = "Чеки"
BTN_TOP = "Топ"
BTN_INFO = "Информация"

# ------------------------------ игровая панель -----------------------------

GAME_PANEL_TITLE = "{{e:star}} <b>Выберите исход игры!</b>"
GAME_PANEL_BET = "{{e:balance}} <b>Ставка:</b> {bet} ★"
GAME_PANEL_BALANCE = "{{e:money}} <b>Баланс:</b> {balance} ★"
GAME_PANEL_HINT = "<i>Коснитесь исхода — бросок начнётся сразу.</i>"

BTN_EDIT_BET = "Изменить ставку"
BTN_MODES = "Режимы"

BET_INPUT_PROMPT = "{{e:edit}} Введите сумму ставки"
BET_INVALID = "{{e:warning}} Введите целое число от {min} до {max}."
BET_MIN_ERROR = "{{e:warning}} Минимальная ставка — {min} ★"
BET_MAX_ERROR = "{{e:warning}} Максимальная ставка — {max} ★"
BET_NO_FUNDS = "{{e:warning}} Недостаточно средств на балансе."
BET_OUTCOME_UNAVAILABLE = "{{e:warning}} Этот исход недоступен для выбранного режима."
BET_LOCKED = "{{e:warning}} Дождитесь окончания текущего броска."

ROUND_LOST = (
    "{{e:error}} <b>Проигрыш</b>\n"
    "Исход: <b>{outcome}</b>\n"
    "Ставка: <b>{bet} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
ROUND_WON = (
    "{{e:success}} <b>Выигрыш</b>\n"
    "Исход: <b>{outcome}</b>\n"
    "Коэффициент: <b>×{coef:g}</b>\n"
    "Ставка: <b>{bet} ★</b>\n"
    "Выигрыш: <b>+{win} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
ROUND_VOID = (
    "{{e:warning}} <b>Ставка возвращена</b>\n"
    "Причина: результат не был сопоставлен с исходом — настройте правило игры.\n"
    "Баланс: <b>{balance} ★</b>"
)

DICE_TOTAL_SUBMENU = "Тотал — выберите сумму"
DICE_RANGE_SUBMENU = "Диапазон — выберите границы"
BTN_BACK_TO_OUTCOMES = "‹ К исходам"
BTN_OTHER = "Другое ›"
SLOTS_OTHER_SUBMENU = "Другое — выберите комбинацию"

# -------------------------------- 21 Очко ----------------------------------

BJ_PANEL_TITLE = "{{e:star}} <b>21 Очко — сделайте ставку и раздайте карты!</b>"
BJ_PANEL_HINT = "<i>«Раздать карты» списывает ставку и начинает раздачу.</i>"

BTN_BJ_DEAL = "Раздать карты"
BTN_BJ_HIT = "➕ Взять еще"
BTN_BJ_STAND = "🛑 Хватит / Пасс"

BJ_HAND = (
    "{{e:star}} <b>Ваши карты:</b> {player} ({player_value} очков)\n"
    "{{e:profile}} <b>Дилер:</b> {dealer}\n"
    "{{e:balance}} <b>Ставка:</b> {bet} ★\n"
    "{{e:money}} <b>Баланс:</b> {balance} ★"
)

BJ_WIN = (
    "{{e:success}} <b>Вы выиграли!</b>\n"
    "Ваши карты: {player} ({player_value} очков)\n"
    "Карты дилера: {dealer} ({dealer_value} очков)\n"
    "Ставка: <b>{bet} ★</b>\n"
    "Выигрыш: <b>+{win} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
BJ_PUSH = (
    "{{e:warning}} <b>Ничья, возврат ставки</b>\n"
    "Ваши карты: {player} ({player_value} очков)\n"
    "Карты дилера: {dealer} ({dealer_value} очков)\n"
    "Ставка: <b>{bet} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
BJ_BUST = (
    "{{e:error}} <b>Перебор! Вы проиграли</b>\n"
    "Ваши карты: {player} ({player_value} очков)\n"
    "Карты дилера: {dealer} ({dealer_value} очков)\n"
    "Ставка: <b>{bet} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
BJ_LOSE = (
    "{{e:error}} <b>Вы проиграли</b>\n"
    "Ваши карты: {player} ({player_value} очков)\n"
    "Карты дилера: {dealer} ({dealer_value} очков)\n"
    "Ставка: <b>{bet} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)

BJ_NO_GAME = "{{e:warning}} Сначала раздайте карты."
BJ_ALREADY = "{{e:warning}} Раздача уже идёт — сыграйте этот раунд до конца."

# --------------------------------- Crash ------------------------------------

CRASH_PANEL_TITLE = "{{e:star}} <b>Crash — запустите ракету и заберите выигрыш!</b>"
CRASH_PANEL_HINT = (
    "<i>Множитель растёт в реальном времени. Нажмите «Забрать» до взрыва "
    "— ставка сгорает, если ракета упадёт раньше.</i>"
)

BTN_CRASH_START = "🚀 Запустить ракету"
BTN_CRASH_TAKE = "💰 Забрать"

CRASH_LAUNCH = (
    "🚀 <b>Ракета в полёте!</b>\n"
    "Множитель: <b>×{mult}</b>\n"
    "Можно забрать: <b>{amount} ★</b>\n"
    "Ставка: {bet} ★"
)
CRASH_TAKEN = (
    "🚀 <b>Вы забрали ×{mult}!</b>\n"
    "Ставка: {bet} ★\n"
    "Выигрыш: <b>+{win} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
CRASH_BOOM = (
    "💥 <b>Ракета взорвалась на ×{mult}!</b>\n"
    "Ставка: {bet} ★ — сгорела.\n"
    "Баланс: <b>{balance} ★</b>"
)
CRASH_NO_RUN = "{{e:warning}} Ракета уже завершила полёт."
CRASH_ALREADY = "{{e:warning}} Дождитесь окончания текущего полёта."

# ------------------------------ профиль / баланс ---------------------------

PROFILE = (
    "{{e:profile}} <b>Имя:</b> {name}\n"
    "{{e:id}} <b>ID:</b> <code>{user_id}</code>\n"
    "\n"
    "{{e:balance}} <b>Баланс:</b> {balance} ★\n"
    "{{e:deposit}} <b>Пополнено:</b> {deposited} ★\n"
    "{{e:withdraw}} <b>Выведено:</b> {withdrawn} ★\n"
    "\n"
    "{{e:turnover}} <b>Оборот:</b> {turnover} ★\n"
    "{{e:games_played}} <b>Сыграно игр:</b> {games}\n"
    "{{e:calendar}} <b>Регистрация:</b> {registered}"
)

BALANCE_SCREEN = "{{e:balance}} <b>Баланс:</b> {balance} ★"

# ------------------------------ пополнение ---------------------------------

DEPOSIT_TITLE = "{{e:deposit}} <b>Выберите способ пополнения</b>"
WITHDRAW_TITLE = "{{e:withdraw}} <b>Выберите удобный способ вывода</b>"

BTN_STARS = "Telegram Stars"
BTN_CRYPTOBOT = "Crypto Bot"
BTN_XROCKET = "xRocket"
BTN_CRYPTO = "Криптовалюта"
BTN_GIFTS = "Telegram Gifts"

PAY_NOT_CONFIGURED = (
    "{{e:warning}} Способ временно недоступен: интеграция не настроена.\n"
    "Добавьте API-ключ в переменные окружения и перезапустите бота."
)
PAY_PROVIDER_ERROR = "{{e:error}} Не удалось создать платёж. Попробуйте позже."
PAY_SUCCESS = (
    "{{e:success}} <b>Платёж подтверждён</b>\n"
    "Зачислено: <b>+{amount} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
STARS_CHOOSE_AMOUNT = "{{e:star}} Выберите сумму пополнения (Telegram Stars)"
STARS_INVOICE_ERROR = "{{e:error}} Не удалось выставить счёт. Попробуйте позже."

# ------------------------------ вывод --------------------------------------

WD_CHOOSE_AMOUNT = "{{e:withdraw}} Введите сумму вывода (мин. {min} ★, макс. {max} ★)"
WD_INVALID_AMOUNT = "{{e:warning}} Некорректная сумма."
WD_NO_FUNDS = "{{e:warning}} Недостаточно средств на балансе."
WD_CREATED = (
    "{{e:success}} <b>Заявка на вывод создана</b>\n"
    "ID заявки: <code>{wid}</code>\n"
    "Сумма: <b>{amount} ★</b>\n"
    "Комиссия: <b>{commission} ★</b>\n"
    "К получению: <b>{total} ★</b>\n"
    "Статус: <b>{status}</b>"
)
WD_STATUS_CHANGED = "{{e:info}} Заявка <code>{wid}</code>: <b>{status}</b>{comment}"
WD_HISTORY_EMPTY = "{{e:info}} Заявок на вывод пока нет."
WD_HISTORY = "<b>История выводов</b>\n{items}"

# ------------------------------ чеки ---------------------------------------

CHECKS_MENU = (
    "{{e:checks}} <b>Чеки</b>\n"
    "<blockquote>Создайте чек или мульти-чек, чтобы мгновенно отправить средства "
    "любому игроку или группе пользователей.</blockquote>\n"
    "<blockquote>В каждый чек встроена реферальная ссылка: игрок, активирующий "
    "бота по чеку, становится вашим рефералом.</blockquote>"
)
CHECKS_TYPES = (
    "{{e:checks}} <b>Создание чека</b>\n"
    "Персональный чек — для отправки средств одному пользователю.\n"
    "Мультичек — для отправки средств нескольким пользователям."
)
CHECK_PERSONAL = (
    "{{e:checks}} <b>Персональный чек</b>\n"
    "Отправьте средства одному пользователю.\n"
    "<i>Чек можно привязать к конкретному Telegram ID — активировать сможет "
    "только он.</i>"
)
CHECK_AMOUNT_PROMPT = "{{e:money}} Введите сумму чека (мин. {min} ★)"
CHECK_MULTICHECK = (
    "{{e:checks}} <b>Мультичек</b>\n"
    "Разделите сумму на несколько чеков одним действием."
)
CHECK_AMOUNT_INVALID = "{{e:warning}} Сумма чека: от {min} до {max} ★."
CHECK_MAX_ERROR = "{{e:warning}} Максимум {max} ★"
CHECK_NO_FUNDS = "{{e:warning}} Недостаточно звёзд на балансе."
CHECK_BONUS_ONLY = (
    "{{e:warning}} Бонусные звёзды нельзя отправить чеком.\n"
    "Доступно к отправке: <b>{available} ★</b>\n"
    "Бонус за регистрацию можно только отыграть."
)
CHECK_TARGET_PROMPT = "{{e:id}} Введите Telegram ID получателя или отправьте <code>0</code>, чтобы открыть чек всем."
CHECK_TARGET_INVALID = "{{e:warning}} Некорректный Telegram ID."
CHECK_CREATED = (
    "{{e:success}} <b>Чек создан</b>\n"
    "Сумма: <b>{amount} ★</b>\n"
    "Получатель: <b>{target}</b>\n"
    "Действует до: <b>{expires}</b>\n"
    "Ссылка: {url}"
)
CHECKS_ACTIVE_EMPTY = "{{e:info}} Активных чеков нет."
CHECKS_ACTIVE = "<b>Активные чеки</b>\n{items}"
CHECK_CANCELLED = "{{e:success}} Чек отменён, средства возвращены на баланс."
CHECK_ACTIVATED = (
    "{{e:success}} <b>Чек активирован</b>\n"
    "Зачислено: <b>+{amount} ★</b>\n"
    "Баланс: <b>{balance} ★</b>"
)
CHECK_ALREADY = "{{e:warning}} Этот чек уже использован."
CHECK_EXPIRED = "{{e:warning}} Срок действия чека истёк."
CHECK_NOT_FOUND = "{{e:warning}} Чек не найден."
CHECK_WRONG_TARGET = "{{e:warning}} Этот чек привязан к другому пользователю."
CHECK_SELF = "{{e:warning}} Нельзя активировать собственный чек."

# ------------------------------ партнёрская программа ----------------------

REF_MAIN = (
    "{{e:referral}} <b>Зарабатывайте {percent:g}% от прибыли проекта "
    "с каждой ставки приглашённых игроков</b>\n"
    "\n"
    "<blockquote>{{e:success}} <b>Активно:</b> получайте долю от прибыли за "
    "каждого нового пользователя, который играет в боте. Подробнее — /ref</blockquote>\n"
    "\n"
    "<b>Ваша реферальная ссылка:</b>\n"
    "<code>{link}</code>\n"
    "\n"
    "{{e:memo}} <b>Статистика:</b>\n"
    "• Всего приглашено: <b>{invited}</b>\n"
    "• Всего заработано с них: <b>{earned} ★</b>\n"
    "{{e:success}} Доступно к выплате: <b>{pending} ★</b>"
)
REF_SEND = "Отправить приглашение"
REF_COPY = "Копировать реф-ссылку"
REF_DETAILS_BTN = "Подробнее"

REF_DETAILS = (
    "{{e:referral}} <b>Партнёрская программа</b>\n"
    "<blockquote>Приглашайте игроков по своей ссылке и получайте "
    "{percent:g}% от прибыли проекта с каждой их ставки — постоянно, без "
    "ограничений по числу приглашений.</blockquote>\n"
    "\n"
    "{{e:memo}} <b>Формула расчёта прибыли:</b>\n"
    "<blockquote>{formula}</blockquote>\n"
    "\n"
    "{{e:fire}} <b>Доход в масштабе:</b>\n"
    "<blockquote>• 1 активный игрок прокручивает 5 000 ★ в день → вы получаете "
    "{daily} ★ в день (≈ {monthly} ★ в месяц)\n"
    "• 10 активных игроков по 2 000 ★ в день → {daily10} ★ в день "
    "(≈ {monthly10} ★ в месяц)</blockquote>\n"
    "\n"
    "{{e:success}} <b>Вывод в любой момент</b> — прибыль начисляется сразу "
    "после расчёта ставки, забирайте кнопкой «Забрать», когда захотите."
)
REF_CLAIM = "Забрать"
REF_CLAIMED = "{{e:success}} Начислено <b>+{amount} ★</b> на баланс."
REF_CLAIM_NOTHING = "{{e:info}} К выплате пока нет начислений."
REF_NOTIFY = "{{e:success}} Реферальное начисление: <b>+{amount} ★</b> от приглашённого игрока."

# ------------------------------ бонусы / кешбэк ----------------------------

DAILY_BONUS = (
    "{{e:bonus}} <b>Ежедневный бонус</b>\n"
    "\n"
    "{description}\n"
    "\n"
    "{status_line}"
)
DAILY_BONUS_OK = "{{e:success}} Бонус доступен: <b>{amount} ★</b>"
DAILY_BONUS_TAKEN = "{{e:info}} Бонус уже получен. Следующий — {next_time}."
DAILY_BONUS_GIVEN = "{{e:success}} Начислено: <b>+{amount} ★</b> (бонусные звёзды)."
BTN_TAKE_BONUS = "Получить бонус"
BTN_BONUS_UNAVAILABLE = "Бонус недоступен"

CASHBACK_SCREEN = (
    "{{e:cashback}} <b>Кешбэк</b>\n"
    "\n"
    "{{e:money}} <b>Доступно</b> — {available} ★\n"
    "{{e:chart}} <b>За всё время</b> — {total} ★\n"
    "\n"
    "<i>Начисление за текущий период будет произведено через {eta}</i>"
)
CASHBACK_TAKEN = "{{e:success}} Кешбэк начислен: <b>+{amount} ★</b>"
CASHBACK_NOTHING = "{{e:warning}} К начислению пока ничего не сформировано."
CASHBACK_DETAILS = (
    "{{e:cashback}} <b>Как работает кешбэк</b>\n"
    "<blockquote>Процент считается от фактически проигранной суммы за период: "
    "{percent} от проигрыша, не больше {max} ★ за период.</blockquote>\n"
    "<blockquote>Оборот от {min_turnover} ★ — только с таких периодов "
    "начисляется кешбэк. Выплата не дублируется: повторное получение за тот же "
    "период невозможно.</blockquote>"
)
BTN_GET_CASHBACK = "Получить кешбэк"
BTN_CASHBACK_UNAVAILABLE = "Кешбэк недоступен"
BTN_DETAILS = "Подробнее"

# ------------------------------ топ ----------------------------------------

TOP_TITLE = "{{e:trophy}} <b>Топ игроков</b>"
TOP_EMPTY = "{{e:info}} В этом периоде пока нет результатов."
TOP_ME = "{{e:star}} Вы: <b>—</b>, {place} место, {value} ★"
TOP_LINE = "{rank} {name} — {value} ★"
TOP_PERIODS = ("За всё время", "За сегодня", "Вчера", "Неделя", "Месяц")

# ------------------------------ приватность --------------------------------

PRIVACY_TEXT = (
    "<blockquote>Выберите, как вас будут видеть другие игроки. Это имя "
    "отображается в топе, в общем канале и рядом с вашими ставками.</blockquote>\n"
    "\n"
    "{{e:profile}} Отображается: <b>{display}</b>"
)
BTN_ANONYMITY = "Анонимность"
BTN_NAME_TG = "Имя TG"
BTN_NICKNAME = "Никнейм"
BTN_CHANGE_NICKNAME = "Изменить никнейм"
NICKNAME_PROMPT = "{{e:edit}} Введите новый никнейм (2–32 символа):"
NICKNAME_INVALID = "{{e:warning}} Некорректный никнейм."
PRIVACY_SAVED = "{{e:success}} Настройки приватности сохранены."

# ------------------------------ режимы -------------------------------------

MODES_TITLE = "{{e:games}} <b>Игровые режимы</b>\nВыберите игру — панель переключится."
MODES_HISTORY_BTN = "История ставок"
MODES_HISTORY_EMPTY = "{{e:info}} Ставок пока нет."
MODES_HISTORY = "<b>История ставок</b>\n{items}"
CUSTOM_MODES_EMPTY = "{{e:info}} Авторские режимы пока недоступны."
CUSTOM_MODE_ERROR = "{{e:warning}} Авторский режим недоступен."

# ------------------------------ информация ---------------------------------

INFO = (
    "{{e:info}} <b>Информация</b>\n"
    "<blockquote>{bot} — бот с честными играми на Telegram Stars.</blockquote>\n"
    "• Результаты бросков определяются официальными играми Telegram.\n"
    "• Ставки, выигрыши и бонусы хранятся в журнале операций.\n"
    "• Поддержка: {support}\n"
    "• Наш канал: {channel}"
)
BTN_RULES = "Правила"
INFO_RULES = (
    "{{e:memo}} <b>Правила</b>\n"
    "• Минимальная ставка — {min} ★, максимальная — {max} ★.\n"
    "• Коэффициенты указаны на кнопках исходов и задаются конфигурацией.\n"
    "• Бонусные звёзды нельзя вывести и отправить чеком — только отыграть.\n"
    "• Результат, не сопоставленный с исходом, возвращает ставку игроку."
)
BTN_SUPPORT = "Поддержка"

# ------------------------------ ошибки -------------------------------------

ERR_GENERIC = "{{e:error}} Что-то пошло не так. Попробуйте ещё раз."
ERR_ACCESS_DENIED = "{{e:error}} Недостаточно прав."
ERR_NOT_REGISTERED = "{{e:warning}} Сначала выполните /start."
ERR_BLOCKED = "{{e:error}} Доступ к боту ограничен."
ERR_RATE_LIMIT = "{{e:warning}} Слишком много действий — подождите пару секунд."
ERR_SESSION = "{{e:warning}} Действие уже выполняется, повторите позже."

# ------------------------------ админ --------------------------------------

ADMIN_STATS = (
    "{{e:info}} <b>Статистика проекта</b>\n"
    "Пользователей: <b>{users}</b>\n"
    "Активных за сутки: <b>{active}</b>\n"
    "Пополнено: <b>{deposited} ★</b>\n"
    "Выведено: <b>{withdrawn} ★</b>\n"
    "Оборот ставок: <b>{turnover} ★</b>\n"
    "Прибыль: <b>{profit} ★</b>\n"
    "Заявок на вывод: <b>{pending_wd}</b>"
)
ADMIN_WITHDRAW_APPROVED = "{{e:success}} Заявка {wid} подтверждена."
ADMIN_WITHDRAW_REJECTED = "{{e:warning}} Заявка {wid} отклонена."
ADMIN_USER = (
    "{{e:profile}} <b>{name}</b> (<code>{user_id}</code>)\n"
    "Баланс: <b>{balance} ★</b> (бонус {bonus} ★)\n"
    "Пополнено: <b>{deposited} ★</b> / выведено: <b>{withdrawn} ★</b>\n"
    "Оборот: <b>{turnover} ★</b>, игр: <b>{games}</b>\n"
    "Статус: <b>{status}</b>"
)

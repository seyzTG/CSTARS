"""Средние слои (middlewares): сессия БД, регистрация, лимиты, права."""

from app.middlewares.admin import AdminAccessMiddleware
from app.middlewares.db import DbSessionMiddleware
from app.middlewares.throttle import ThrottleMiddleware
from app.middlewares.user import UserMiddleware

__all__ = [
    "AdminAccessMiddleware",
    "DbSessionMiddleware",
    "ThrottleMiddleware",
    "UserMiddleware",
]

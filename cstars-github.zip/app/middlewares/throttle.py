"""Middleware: ограничение частоты действий на пользователя (антифлуд).

Простое скользящее окно в памяти процесса. Для нескольких инстансов или
жёстких лимитов используйте Redis-хранилище (см. app/database/redis.py).
"""

from __future__ import annotations

import time
from collections import defaultdict
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware, Bot
from aiogram.types import TelegramObject

from app.config.settings import settings
from app.config.texts import ERR_RATE_LIMIT
from app.utils.format import render


class ThrottleMiddleware(BaseMiddleware):
    def __init__(self, per_second: float | None = None) -> None:
        self.per_second = per_second or settings.rate_limit_per_second
        self._hits: dict[int, list[float]] = defaultdict(list)
        self._last_warn: dict[int, float] = {}

    def _allowed(self, user_id: int) -> bool:
        now = time.monotonic()
        window = 1.0 / self.per_second if self.per_second > 0 else 0.0
        hits = [t for t in self._hits[user_id] if now - t < window]
        hits.append(now)
        self._hits[user_id] = hits
        return len(hits) <= max(1, int(self.per_second))

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user = data.get("event_from_user")
        if tg_user is None or tg_user.is_bot:
            return await handler(event, data)

        if self._allowed(tg_user.id):
            return await handler(event, data)

        now = time.monotonic()
        if now - self._last_warn.get(tg_user.id, 0) > 2.0:
            self._last_warn[tg_user.id] = now
            bot: Bot | None = data.get("bot")
            if bot is not None:
                text, entities = render(ERR_RATE_LIMIT)
                try:
                    await bot.send_message(
                        tg_user.id, text, entities=entities
                    )
                except Exception:  # noqa: BLE001 — вторичное действие
                    pass
        return None

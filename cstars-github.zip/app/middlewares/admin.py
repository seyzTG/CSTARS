"""Middleware: серверная проверка прав администратора по Telegram ID.

Права НЕ определяются наличием кнопки или команды: админ-маршруты
пропускают только тех, чей ID есть в ADMIN_IDS (или is_admin в БД).
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware, Bot
from aiogram.types import TelegramObject

from app.config.settings import settings
from app.config.texts import ERR_ACCESS_DENIED
from app.models import User
from app.utils.format import render


def is_admin(user: User | None, tg_user_id: int | None = None) -> bool:
    """Единая проверка прав на сервере."""
    if tg_user_id is not None and tg_user_id in settings.admin_ids:
        return True
    if user is not None and user.is_admin:
        return True
    return False


class AdminAccessMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user = data.get("event_from_user")
        db_user: User | None = data.get("db_user")
        if is_admin(db_user, tg_user.id if tg_user else None):
            data["is_admin_command"] = True
            return await handler(event, data)

        bot: Bot | None = data.get("bot")
        if bot is not None and tg_user is not None:
            text, entities = render(ERR_ACCESS_DENIED)
            try:
                await bot.send_message(tg_user.id, text, entities=entities)
            except Exception:  # noqa: BLE001
                pass
        return None

"""Middleware: гарантирует наличие пользователя в data обработчика.

Любой апдейт от известного пользователя создаёт/загружает запись в БД
(включая wallet и настройки), чтобы обработчики не проверяли это вручную.
Заблокированные аккаунты не проходят дальше.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, User as TgUser
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories import user_repo


class UserMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        tg_user: TgUser | None = data.get("event_from_user")
        session: AsyncSession | None = data.get("session")

        if tg_user is None or tg_user.is_bot or session is None:
            return await handler(event, data)

        user = await user_repo.get_user(session, tg_user.id)
        if user is None:
            start_payload = data.get("command") or data.get("start_payload")
            user, _created, _inviter = await _register(
                session, tg_user, start_payload if isinstance(start_payload, str) else None
            )
        elif user.is_blocked:
            # заблокированным аккаунтам доступ закрыт, кроме админ-команд
            if not data.get("is_admin_command"):
                return None
        data["db_user"] = user
        return await handler(event, data)


async def _register(
    session: AsyncSession, tg_user: TgUser, start_payload: str | None
):
    from app.services import users as users_service

    return await users_service.register(
        session,
        user_id=tg_user.id,
        username=tg_user.username,
        first_name=tg_user.first_name,
        last_name=tg_user.last_name,
        start_payload=start_payload,
    )

"""Движок бросков и оценки исходов.

Принципы:
  * результат определяется ОФИЦИАЛЬНЫМИ играми Telegram (send_dice) — сервер
    не подменяет исход своим случайным числом;
  * сопоставление значений Dice → исходы задаётся конфигурацией
    (config/games.py) и отмечено там как непроверенное;
  * если выпавшее значение не сопоставлено, раунд объявляется ничьей
    (VOID) и ставка возвращается — так игрок не теряет деньги из-за
    неполной конфигурации.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from aiogram import Bot
from aiogram.types import Message

from app.config.games import GameSpec, outcome_by_code


@dataclass
class RollResult:
    """Результат одного броска (или серии бросков)."""

    game_code: str
    values: list[int] = field(default_factory=list)
    classification: str | None = None   # второй бросок (футбол)
    outcome_code: str | None = None     # итоговый исход по конфигурации
    outcome_label: str | None = None
    is_void: bool = False               # значение не сопоставлено → возврат ставки
    messages: list[Message] = field(default_factory=list)

    @property
    def summary(self) -> str:
        parts = [str(v) for v in self.values]
        if self.classification:
            parts.append(self.classification)
        return ", ".join(parts)


async def roll_dice(bot: Bot, chat_id: int, emoji: str) -> tuple[int, Message]:
    """Один официальный бросок Telegram Dice. Возвращает (значение, сообщение)."""
    message = await bot.send_dice(chat_id=chat_id, emoji=emoji)
    value = message.dice.value if message.dice else 0
    return value, message


# ---------------------------------------------------------------------------
# Слоты: официальный 🎰 (значение 1..64 = три барабана по 4 символа)
# Символы барабана: 0=BAR, 1=виноград, 2=лимон, 3=семёрка.
# ---------------------------------------------------------------------------

SLOT_TRIPLES: dict[int, str] = {
    1: "bars",
    22: "grapes",
    43: "lemons",
    64: "sevens",
}
SLOT_SEVEN = 3


def decode_slot(value: int) -> tuple[int, int, int]:
    """Раскодировать значение 🎰 (1..64) в три символа барабанов (0..3)."""
    normalized = max(1, min(64, int(value))) - 1
    return (
        normalized & 3,
        (normalized >> 2) & 3,
        (normalized >> 4) & 3,
    )


def check_slots(outcome_code: str, value: int) -> bool:
    """Победа по ставке на слоты. ``value`` — значение 🎰 (1..64)."""
    reels = decode_slot(value)
    triple = SLOT_TRIPLES.get(max(1, min(64, int(value))))
    if outcome_code in {"sevens", "bars", "lemons", "grapes"}:
        return triple == outcome_code
    if outcome_code == "any_combination":
        return triple is not None
    if outcome_code == "pair":
        # хотя бы два одинаковых символа (пара или тройка)
        return len(set(reels)) <= 2
    if outcome_code == "two_sevens":
        return reels.count(SLOT_SEVEN) == 2
    if outcome_code == "all_different":
        return len(set(reels)) == 3
    return False


def resolve_outcome(
    spec: GameSpec,
    values: list[int],
    classification: str | None = None,
) -> tuple[str | None, str | None, bool]:
    """Определить итоговый исход по значениям Dice.

    Возвращает (outcome_code, outcome_label, is_void).
    """
    if not values:
        return None, None, True

    # --- кости: исход зависит от суммы / состава, а не от value_map ---
    if spec.code == "dice":
        return _resolve_dice(spec, values[0] if len(values) == 1 else values)

    # --- слоты: значение 🎰 1..64 раскодируется в три барабана ---
    if spec.code == "slots":
        value = values[0]
        code = SLOT_TRIPLES.get(max(1, min(64, int(value))))
        if code is None:
            return "other", "Другое", False
        outcome = spec.outcome(code)
        return outcome.code, outcome.label, False

    if spec.classification_map is not None:
        # двухшаговая механика (футбол): 1-й бросок → базовый исход,
        # при «голе» второй бросок уточняет подвид
        primary = spec.value_map.get(values[0])
        if primary == "goal":
            if classification is None:
                return None, None, True
            kind = spec.classification_map.get(values[1] if len(values) > 1 else 0)
            if kind is None:
                return None, None, True
            code = {
                "center": "goal_center",
                "goal_post": "goal_post",
                "corner": "goal_corner",
            }.get(kind)
            if code is None:
                return None, None, True
            outcome = spec.outcome(code)
            if outcome is None:
                return None, None, True
            return outcome.code, outcome.label, False
        if primary is None:
            return None, None, True
        outcome = spec.outcome(primary)
        if outcome is None:
            return None, None, True
        return outcome.code, outcome.label, False

    outcome_code = spec.value_map.get(values[0])
    if outcome_code is None:
        return None, None, True
    outcome = spec.outcome(outcome_code)
    if outcome is None:
        return None, None, True
    return outcome.code, outcome.label, False


def _resolve_dice(
    spec: GameSpec, value: int | list[int]
) -> tuple[str | None, str | None, bool]:
    values = value if isinstance(value, list) else [value]
    total = sum(values)

    if len(values) == 1:
        prefix = ""
    else:
        prefix = f"{len(values)}_"

    # исход проверяется по выбранному игроком коду в evaluate(), здесь мы
    # возвращаем «фактический» исход для журнала
    from app.config.games import DICE_COEFFICIENTS

    coefs = DICE_COEFFICIENTS.get(len(values), DICE_COEFFICIENTS[1])
    if total % 2 == 0:
        code = f"{prefix}even"
        label = f"Чётное (×{coefs['even']:g})"
    else:
        code = f"{prefix}odd"
        label = f"Нечётное (×{coefs['odd']:g})"
    return code, label, False


def _check_dice_outcome(outcome_code: str, values: list[int]) -> bool | None:
    """Победа по выбранному исходу костей. None → исход не про исход костей."""
    total = sum(values)
    if outcome_code.endswith("even"):
        return total % 2 == 0
    if outcome_code.endswith("odd"):
        return total % 2 == 1
    if outcome_code.startswith("number_"):
        target = int(outcome_code.split("_", 1)[1])
        return any(v == target for v in values)
    if outcome_code.startswith("total_"):
        target = int(outcome_code.split("_", 1)[1])
        return total == target
    if outcome_code.startswith("range_"):
        parts = outcome_code.split("_")
        low, high = int(parts[1]), int(parts[2])
        return low <= total <= high
    return None


def evaluate(
    game_code: str,
    outcome_code: str,
    result: RollResult,
) -> bool | None:
    """Соответствие поставленного исхода фактическому результату.

    Возвращает True (победа), False (поражение) или None (ничья → возврат).
    """
    if result.is_void:
        return None

    if game_code == "blackjack":
        # исход раздачи считает handlers/blackjack.py (сравнение рук):
        # win → победа, push → ничья (возврат), lose → проигрыш
        if result.outcome_code == "win":
            return True
        if result.outcome_code == "push":
            return None
        if result.outcome_code == "lose":
            return False
        return None

    if game_code == "slots":
        if not result.values:
            return None
        return check_slots(outcome_code, result.values[0])

    if game_code == "dice":
        won = _check_dice_outcome(outcome_code, result.values)
        return won if won is not None else None

    if game_code == "football":
        # «Гол» выигрывает при любом подроме гола
        if outcome_code == "goal":
            return result.outcome_code in {"goal_center", "goal_post", "goal_corner"}
        return outcome_code == result.outcome_code

    return outcome_code == result.outcome_code


async def perform_roll(
    bot: Bot,
    chat_id: int,
    spec: GameSpec,
    dice_count: int = 1,
) -> RollResult:
    """Выполнить бросок(и) и вернуть результат с определённым исходом."""
    result = RollResult(game_code=spec.code)

    if spec.code == "dice":
        for _ in range(max(1, min(3, dice_count))):
            value, message = await roll_dice(bot, chat_id, spec.dice_emoji)
            result.values.append(value)
            result.messages.append(message)
    else:
        value, message = await roll_dice(bot, chat_id, spec.dice_emoji)
        result.values.append(value)
        result.messages.append(message)

        # футбол: при голе — второй бросок для классификации подвида
        if spec.classification_map is not None:
            primary = spec.value_map.get(value)
            if primary == "goal":
                second, second_message = await roll_dice(bot, chat_id, spec.dice_emoji)
                result.values.append(second)
                result.messages.append(second_message)
                result.classification = spec.classification_map.get(second)

    code, label, void = resolve_outcome(spec, result.values, result.classification)
    result.outcome_code = code
    result.outcome_label = label
    result.is_void = void
    return result

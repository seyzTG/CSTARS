"""Авторские режимы: результат генерируется сервером криптографически
стойким генератором (secrets), поскольку официальной Telegram-анимации
для пользовательских режимов нет."""

from __future__ import annotations

import secrets
from dataclasses import dataclass


@dataclass(frozen=True)
class CustomOutcome:
    code: str
    label: str
    coef: float
    weight: int = 1


def parse_outcomes(raw: list[dict]) -> list[CustomOutcome]:
    """Разобрать конфигурацию исходов авторского режима."""
    outcomes: list[CustomOutcome] = []
    for item in raw:
        try:
            outcomes.append(
                CustomOutcome(
                    code=str(item["code"]),
                    label=str(item.get("label", item["code"])),
                    coef=float(item.get("coef", 2.0)),
                    weight=max(1, int(item.get("weight", 1))),
                )
            )
        except (KeyError, TypeError, ValueError):
            continue
    return outcomes


def _weighted_choice(outcomes: list[CustomOutcome]) -> CustomOutcome:
    """Выбор с учётом весов через cryptographically secure RNG."""
    total = sum(o.weight for o in outcomes)
    if total <= 0:
        raise ValueError("custom mode has no outcomes")
    threshold = secrets.randbelow(total)
    cumulative = 0
    for outcome in outcomes:
        cumulative += outcome.weight
        if threshold < cumulative:
            return outcome
    return outcomes[-1]


def roll_custom(raw_outcomes: list[dict]) -> tuple[str, str, float] | None:
    """Сделать бросок авторского режима. Возвращает (code, label, coef)."""
    outcomes = parse_outcomes(raw_outcomes)
    if not outcomes:
        return None
    picked = _weighted_choice(outcomes)
    return picked.code, picked.label, picked.coef

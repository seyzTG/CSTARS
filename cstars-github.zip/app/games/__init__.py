"""Игровой модуль: официальные Telegram Dice, расчёт исходов, авторские режимы."""

from app.games.engine import RollResult, evaluate, roll_dice
from app.games.custom import roll_custom

__all__ = ["RollResult", "evaluate", "roll_dice", "roll_custom"]

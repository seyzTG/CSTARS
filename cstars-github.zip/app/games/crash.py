"""Crash: модель полёта ракеты.

Точка взрыва определяется сервером криптостойким генератором (``secrets``);
эмулятор не вмешивается в исход. Множитель растёт от стартового значения
до точки взрыва по экспоненте, а сообщение в чате обновляется каждые
1.5–2 секунды (точный интервал задаётся конфигурацией).
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal

from app.config.crash import CrashConfig

# шаг отображения множителя: 1.15, 1.35, 2.10 и т.д.
STEP = Decimal("0.01")


def quantize_multiplier(value: float | Decimal | str) -> Decimal:
    """Округлить множитель до двух знаков после запятой."""
    return Decimal(str(value)).quantize(STEP, rounding=ROUND_HALF_UP)


def format_multiplier(value: Decimal) -> str:
    """Отображение множителя: «1.15», «2.10», «10.00»."""
    return f"{value:.2f}"


@dataclass(frozen=True)
class CrashPlan:
    """Заранее определённый полёт: точка взрыва и время полёта."""

    crash_multiplier: Decimal
    flight_seconds: float
    start_multiplier: Decimal

    def multiplier_at(self, elapsed: float) -> Decimal:
        """Текущий множитель в момент ``elapsed`` секунд после запуска.

        Рост экспоненциальный: от стартового значения до ``crash_multiplier``.
        Значение никогда не превышает точку взрыва.
        """
        if elapsed <= 0:
            return self.start_multiplier
        progress = min(1.0, max(0.0, elapsed / self.flight_seconds))
        base = float(self.start_multiplier)
        target = float(self.crash_multiplier)
        value = base * (target / base) ** progress
        value = min(value, target)
        return quantize_multiplier(value)

    def is_crash(self, multiplier: Decimal) -> bool:
        """Достигнута ли точка взрыва."""
        return multiplier >= self.crash_multiplier


def plan_crash(config: CrashConfig) -> CrashPlan:
    """Определить точку взрыва и длительность полёта (CSPRNG)."""
    start = quantize_multiplier(config.min_multiplier)

    # Классическое распределение точки взрыва с комиссией проекта:
    # P(взрыв >= x) = (1 - house_edge) / x при x >= 1.
    r = secrets.randbelow(1_000_000) / 1_000_000.0
    if r < config.house_edge:
        raw = config.min_multiplier
    else:
        raw = (1.0 - config.house_edge) / (1.0 - r)
    raw = max(config.min_multiplier, min(config.max_multiplier, raw))
    crash = quantize_multiplier(raw)

    span = max(0.0, config.flight_max_seconds - config.flight_min_seconds)
    flight = config.flight_min_seconds + span * (
        secrets.randbelow(10_000) / 10_000.0
    )
    return CrashPlan(
        crash_multiplier=crash,
        flight_seconds=max(0.1, flight),
        start_multiplier=start,
    )


def next_tick(config: CrashConfig) -> float:
    """Случайная задержка до следующего обновления множителя."""
    span = max(0.0, config.tick_max_seconds - config.tick_min_seconds)
    return config.tick_min_seconds + span * (
        secrets.randbelow(10_000) / 10_000.0
    )


__all__ = [
    "CrashPlan",
    "format_multiplier",
    "next_tick",
    "plan_crash",
    "quantize_multiplier",
]

"""21 Очко (Blackjack): колода, руки и правила дилера.

Принципы (как в остальных играх):
  * результат считает сервер, но перемешивание — криптостойкий ГПСЧ
    (``secrets.SystemRandom``): исход не подменяется в пользу игрока;
  * дилер добирает карты, пока у него меньше 17, и останавливается на 17;
  * туз считается 11, пока сумма не превышает 21 — затем как 1.

Состояние раунда (колода/руки/раунд ставки) живёт в FSM-данных под ключом
``bj`` — см. handlers/blackjack.py.
"""

from __future__ import annotations

import secrets
from itertools import product

RANKS: tuple[str, ...] = ("A", "2", "3", "4", "5", "6", "7", "8", "9",
                          "10", "J", "Q", "K")
SUITS: dict[str, str] = {"S": "♠️", "H": "♥️", "D": "♦️", "C": "♣️"}

_RANK_TITLES: dict[str, str] = {"A": "Туз", "K": "Король",
                                "Q": "Дама", "J": "Валет"}


def new_deck() -> list[str]:
    """Новая колода из 52 карт, перемешанная CSPRNG (``secrets``)."""
    deck = [f"{rank}|{suit}" for rank, suit in product(RANKS, SUITS)]
    secrets.SystemRandom().shuffle(deck)
    return deck


def draw(deck: list[str]) -> str:
    """Взять верхнюю карту из колоды."""
    return deck.pop()


def initial_hands(deck: list[str]) -> tuple[list[str], list[str]]:
    """Раздача: по две карты игроку и дилеру."""
    player = [draw(deck), draw(deck)]
    dealer = [draw(deck), draw(deck)]
    return player, dealer


def card_value(card: str) -> int:
    rank = card.split("|", 1)[0]
    if rank == "A":
        return 11
    if rank in ("K", "Q", "J"):
        return 10
    return int(rank)


def hand_value(cards: list[str]) -> int:
    """Сумма руки: туз — 11 или 1, чтобы не выйти за 21."""
    total = sum(card_value(c) for c in cards)
    aces = sum(1 for c in cards if c.startswith("A|"))
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


def is_blackjack(cards: list[str]) -> bool:
    """Натуральный блэкджек: ровно две карты на 21."""
    return len(cards) == 2 and hand_value(cards) == 21


def dealer_play(deck: list[str], dealer: list[str]) -> list[str]:
    """Дилер добирает карты, пока у него меньше 17."""
    while hand_value(dealer) < 17:
        dealer.append(draw(deck))
    return dealer


def decide(player: list[str], dealer: list[str]) -> str:
    """Итог сравнения рук: ``win`` / ``push`` / ``lose``."""
    pv, dv = hand_value(player), hand_value(dealer)
    if pv > 21:
        return "lose"
    if dv > 21:
        return "win"
    if pv > dv:
        return "win"
    if pv < dv:
        return "lose"
    return "push"


def format_card(card: str) -> str:
    """Карта для сообщения: «Туз♦️», «10♠️»."""
    rank, _, suit = card.partition("|")
    title = _RANK_TITLES.get(rank, rank)
    return f"{title}{SUITS.get(suit, suit)}"


def format_hand(cards: list[str]) -> str:
    return ", ".join(format_card(c) for c in cards)


__all__ = [
    "RANKS",
    "SUITS",
    "new_deck",
    "draw",
    "initial_hands",
    "card_value",
    "hand_value",
    "is_blackjack",
    "dealer_play",
    "decide",
    "format_card",
    "format_hand",
]

"""Финансовый модуль: атомарный журнал операций и работа с балансами.

Правила:
  * баланс НИКОГДА не меняется без записи в ``transactions``;
  * каждая операция идемпотентна через ``idempotency_key`` — повторное
    уведомление провайдера или повтор клика не изменит баланс повторно;
  * отрицательный баланс невозможен: условие проверяется прямо в UPDATE;
  * внутренние единицы, Telegram Stars и криптовалюты НИКОГДА не смешиваются —
    конвертация выполняется только через явный курс (settings.units_per_star).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Sequence

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Transaction, TransactionStatus, TransactionType, Wallet, WalletKind
from app.utils.ids import uuid_hex
from app.utils.logging import get_logger

log = get_logger(__name__)


class LedgerError(Exception):
    """Базовая ошибка финансового модуля."""


class InsufficientFunds(LedgerError):
    """Недостаточно средств в конкретном кошельке."""

    def __init__(self, required: int, available: int) -> None:
        super().__init__(f"required={required}, available={available}")
        self.required = required
        self.available = available


class DuplicateOperation(LedgerError):
    """Операция с таким ключом уже была выполнена."""


@dataclass(frozen=True)
class AppliedResult:
    """Итог применения операции."""

    transaction: Transaction | None      # None, если операция уже была (идемпотентный повтор)
    bonus_spent: int = 0                # сколько списано бонусных единиц
    real_spent: int = 0                 # сколько списано собственных средств
    applied: bool = True                # False → повтор, баланс не менялся


async def ensure_wallet(session: AsyncSession, user_id: int) -> Wallet:
    wallet = await session.get(Wallet, user_id)
    if wallet is not None:
        return wallet
    try:
        async with session.begin_nested():
            wallet = Wallet(user_id=user_id)
            session.add(wallet)
            await session.flush()
    except IntegrityError:
        # кошелёк уже создан параллельно — берём существующий
        session.expire_all()
        wallet = await session.get(Wallet, user_id)
        if wallet is None:
            raise LedgerError(f"wallet for {user_id} not created") from None
    return wallet


async def get_balances(session: AsyncSession, user_id: int) -> tuple[int, int]:
    wallet = await ensure_wallet(session, user_id)
    return wallet.real_balance, wallet.bonus_balance


async def _find(session: AsyncSession, key: str) -> Transaction | None:
    return await session.scalar(select(Transaction).where(Transaction.idempotency_key == key))


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def _insert(
    session: AsyncSession,
    *,
    user_id: int,
    kind: TransactionType,
    wallet_kind: WalletKind,
    amount: int,
    key: str,
    description: str | None,
    status: TransactionStatus = TransactionStatus.COMPLETED,
    external_id: str | None = None,
    game_round_id: int | None = None,
    check_id: str | None = None,
    payment_id: int | None = None,
    withdrawal_id: str | None = None,
) -> Transaction:
    transaction = Transaction(
        id=uuid_hex(),
        user_id=user_id,
        type=kind.value,
        wallet=wallet_kind.value,
        amount=amount,
        currency="XTR",
        status=status.value,
        idempotency_key=key,
        description=description,
        external_id=external_id,
        game_round_id=game_round_id,
        check_id=check_id,
        payment_id=payment_id,
        withdrawal_id=withdrawal_id,
        completed_at=_now() if status == TransactionStatus.COMPLETED else None,
    )
    session.add(transaction)
    await session.flush()
    return transaction


async def _move_balance(
    session: AsyncSession,
    *,
    user_id: int,
    amount: int,
    wallet_kind: WalletKind,
) -> int:
    """Атомарное изменение одного кошелька. Возвращает новый остаток.

    Списание (amount < 0) невозможно, если остаток ушёл бы в минус:
    условие проверяется в самом UPDATE — защита от гонок.
    """
    column = (
        Wallet.real_balance
        if wallet_kind == WalletKind.REAL
        else Wallet.bonus_balance
    )
    if amount >= 0:
        result = await session.execute(
            update(Wallet)
            .where(Wallet.user_id == user_id)
            .values({column: column + amount})
            .execution_options(synchronize_session=False)
        )
    else:
        result = await session.execute(
            update(Wallet)
            .where(Wallet.user_id == user_id, column + amount >= 0)
            .values({column: column + amount})
            .execution_options(synchronize_session=False)
        )
    if result.rowcount == 0:
        wallet = await session.get(Wallet, user_id)
        available = 0
        if wallet is not None:
            available = (
                wallet.real_balance
                if wallet_kind == WalletKind.REAL
                else wallet.bonus_balance
            )
        raise InsufficientFunds(abs(amount), available)
    # синхронизируем объект в identity map с изменённой строкой
    wallet = await session.get(Wallet, user_id)
    if wallet is not None:
        await session.refresh(
            wallet, attribute_names=["real_balance", "bonus_balance"]
        )
    return 0


async def _balance_after(session: AsyncSession, user_id: int) -> int:
    wallet = await session.get(Wallet, user_id)
    if wallet is None:
        return 0
    return wallet.total


async def credit(
    session: AsyncSession,
    *,
    user_id: int,
    amount_minor: int,
    kind: TransactionType,
    wallet_kind: WalletKind = WalletKind.REAL,
    key: str,
    description: str | None = None,
    external_id: str | None = None,
    payment_id: int | None = None,
    check_id: str | None = None,
    game_round_id: int | None = None,
    withdrawal_id: str | None = None,
    status: TransactionStatus = TransactionStatus.COMPLETED,
) -> AppliedResult:
    """Зачисление. Повтор с тем же ключом ничего не делает."""
    if amount_minor <= 0:
        raise LedgerError("credit amount must be positive")
    await ensure_wallet(session, user_id)

    existing = await _find(session, key)
    if existing is not None:
        return AppliedResult(transaction=existing, applied=False)

    try:
        async with session.begin_nested():
            transaction = await _insert(
                session,
                user_id=user_id,
                kind=kind,
                wallet_kind=wallet_kind,
                amount=amount_minor,
                key=key,
                description=description,
                status=status,
                external_id=external_id,
                game_round_id=game_round_id,
                check_id=check_id,
                payment_id=payment_id,
                withdrawal_id=withdrawal_id,
            )
            await _move_balance(
                session, user_id=user_id, amount=amount_minor, wallet_kind=wallet_kind
            )
            transaction.balance_after = await _balance_after(session, user_id)
    except IntegrityError:
        # гонка: операция с этим ключом уже применена другим путём
        session.expire_all()
        existing = await _find(session, key)
        if existing is None:
            raise
        return AppliedResult(transaction=existing, applied=False)
    log.info("credit user=%s kind=%s amount=%s", user_id, kind.value, amount_minor)
    return AppliedResult(transaction=transaction)


async def debit(
    session: AsyncSession,
    *,
    user_id: int,
    amount_minor: int,
    kind: TransactionType,
    wallet_kind: WalletKind = WalletKind.REAL,
    key: str,
    description: str | None = None,
    game_round_id: int | None = None,
    check_id: str | None = None,
    withdrawal_id: str | None = None,
) -> AppliedResult:
    """Списание строго из одного кошелька."""
    if amount_minor <= 0:
        raise LedgerError("debit amount must be positive")
    await ensure_wallet(session, user_id)

    existing = await _find(session, key)
    if existing is not None:
        return AppliedResult(transaction=existing, applied=False)

    try:
        async with session.begin_nested():
            transaction = await _insert(
                session,
                user_id=user_id,
                kind=kind,
                wallet_kind=wallet_kind,
                amount=-amount_minor,
                key=key,
                description=description,
                game_round_id=game_round_id,
                check_id=check_id,
                withdrawal_id=withdrawal_id,
            )
            await _move_balance(
                session, user_id=user_id, amount=-amount_minor, wallet_kind=wallet_kind
            )
            transaction.balance_after = await _balance_after(session, user_id)
    except IntegrityError:
        session.expire_all()
        existing = await _find(session, key)
        if existing is None:
            raise
        return AppliedResult(transaction=existing, applied=False)
    log.info("debit user=%s kind=%s amount=%s", user_id, kind.value, amount_minor)
    return AppliedResult(transaction=transaction)


async def debit_split(
    session: AsyncSession,
    *,
    user_id: int,
    amount_minor: int,
    kind: TransactionType,
    key: str,
    prefer: WalletKind = WalletKind.BONUS,
    description: str | None = None,
    game_round_id: int | None = None,
) -> AppliedResult:
    """Списание суммы с приоритетом одного кошелька (бонус → собственные).

    Используется для ставок: сначала расходуются бонусные звёзды,
    недостающее берётся из собственных средств. Обе части атомарны
    и попадают в журнал отдельными строками (ключ ``key#bonus``/``key#real``).
    """
    if amount_minor <= 0:
        raise LedgerError("debit amount must be positive")
    await ensure_wallet(session, user_id)

    bonus_key, real_key = f"{key}#bonus", f"{key}#real"
    first = await _find(session, bonus_key)
    second = await _find(session, real_key)
    if first is not None or second is not None:
        bonus_spent = -first.amount if first else 0
        real_spent = -second.amount if second else 0
        return AppliedResult(
            transaction=second or first, bonus_spent=bonus_spent,
            real_spent=real_spent, applied=False,
        )

    primary = WalletKind.BONUS if prefer == WalletKind.BONUS else WalletKind.REAL
    secondary = WalletKind.REAL if primary == WalletKind.BONUS else WalletKind.BONUS

    wallet = await ensure_wallet(session, user_id)
    if primary == WalletKind.BONUS:
        from_primary = min(wallet.bonus_balance, amount_minor)
    else:
        from_primary = min(wallet.real_balance, amount_minor)
    from_secondary = amount_minor - from_primary

    bonus_spent = from_primary if primary == WalletKind.BONUS else from_secondary
    real_spent = from_primary if primary == WalletKind.REAL else from_secondary

    try:
        async with session.begin_nested():
            if from_primary:
                await _insert(
                    session, user_id=user_id, kind=kind, wallet_kind=primary,
                    amount=-from_primary, key=bonus_key,
                    description=description, game_round_id=game_round_id,
                )
                await _move_balance(
                    session, user_id=user_id, amount=-from_primary, wallet_kind=primary
                )
            if from_secondary:
                await _insert(
                    session, user_id=user_id, kind=kind, wallet_kind=secondary,
                    amount=-from_secondary, key=real_key,
                    description=description, game_round_id=game_round_id,
                )
                await _move_balance(
                    session, user_id=user_id, amount=-from_secondary, wallet_kind=secondary
                )
    except IntegrityError:
        session.expire_all()
        existing_first = await _find(session, bonus_key)
        existing_second = await _find(session, real_key)
        if existing_first is None and existing_second is None:
            raise
        return AppliedResult(
            transaction=existing_second or existing_first,
            bonus_spent=-existing_first.amount if existing_first else 0,
            real_spent=-existing_second.amount if existing_second else 0,
            applied=False,
        )
    log.info(
        "debit_split user=%s total=%s bonus=%s real=%s",
        user_id, amount_minor, bonus_spent, real_spent,
    )
    return AppliedResult(
        transaction=await _find(session, real_key) or await _find(session, bonus_key),
        bonus_spent=bonus_spent,
        real_spent=real_spent,
    )


async def sum_by_types(
    session: AsyncSession,
    user_id: int | None,
    kinds: Sequence[TransactionType],
    statuses: Sequence[TransactionStatus] = (TransactionStatus.COMPLETED,),
) -> int:
    """Сумма операций заданных типов (для отчётов/статистики)."""
    from sqlalchemy import func

    query = select(func.coalesce(func.sum(Transaction.amount), 0)).where(
        Transaction.type.in_([k.value for k in kinds]),
        Transaction.status.in_([s.value for s in statuses]),
    )
    if user_id is not None:
        query = query.where(Transaction.user_id == user_id)
    return int(await session.scalar(query) or 0)

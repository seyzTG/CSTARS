"""Клиент Redis (опционально): FSM-состояния и кеширование.

Если USE_REDIS=false или бот запущен в тестах — используется память процесса.
"""

from __future__ import annotations

from typing import Any

from app.config.settings import settings

_redis: Any = None
_memory: dict[str, bytes] = {}


async def get_redis() -> Any | None:
    """Вернуть подключение Redis или None (тогда работает dict-хранилище)."""
    global _redis
    if not settings.use_redis:
        return None
    if _redis is None:
        import redis.asyncio as aioredis  # лениво, чтобы не тянуть пакет без нужды

        _redis = aioredis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=False,
        )
    return _redis


async def cache_get(key: str) -> bytes | None:
    client = await get_redis()
    if client is None:
        return _memory.get(key)
    return await client.get(key)


async def cache_set(key: str, value: bytes, ttl: int | None = None) -> None:
    client = await get_redis()
    if client is None:
        _memory[key] = value
        return
    if ttl:
        await client.setex(key, ttl, value)
    else:
        await client.set(key, value)


async def cache_delete(key: str) -> None:
    client = await get_redis()
    if client is None:
        _memory.pop(key, None)
        return
    await client.delete(key)


async def close_redis() -> None:
    global _redis
    if _redis is not None:
        await _redis.aclose()
        _redis = None
    _memory.clear()

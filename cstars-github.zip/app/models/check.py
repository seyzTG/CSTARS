"""Персональные чеки и мульти-чеки."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Index, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base, TimestampMixin
from app.models.enums import CheckStatus


class Check(Base, TimestampMixin):
    """Одноразовый чек: активируется по ссылке, погашается атомарно."""

    __tablename__ = "checks"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)   # uuid4().hex
    token: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    creator_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    amount_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    # чек всегда формируется из НАСТОЯЩИХ средств — бонусные отправить нельзя
    target_user_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status: Mapped[str] = mapped_column(
        String(16), default=CheckStatus.ACTIVE.value, nullable=False
    )
    parent_id: Mapped[str | None] = mapped_column(String(32), nullable=True)  # мультичек
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    redeemed_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    redeemed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    cancelled_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        Index("ix_checks_status", "status"),
        Index("ix_checks_creator", "creator_id", "created_at"),
        Index("ix_checks_parent", "parent_id"),
    )

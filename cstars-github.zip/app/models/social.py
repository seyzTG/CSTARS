"""Рефералы, бонусы и кешбэк."""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    BigInteger,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base, BigIntPK, TimestampMixin
from app.models.enums import BonusStatus, BonusType, ReferralStatus, RewardStatus


class Referral(Base, TimestampMixin):
    """Связь «пригласивший — приглашённый». Одна запись на пользователя."""

    __tablename__ = "referrals"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    inviter_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    invitee_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    status: Mapped[str] = mapped_column(
        String(16), default=ReferralStatus.ACTIVE.value, nullable=False
    )
    registered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.utcnow, nullable=False
    )

    __table_args__ = (
        Index("ix_referrals_inviter", "inviter_id"),
        UniqueConstraint("inviter_id", "invitee_id", name="uq_referral_pair"),
    )


class ReferralReward(Base, TimestampMixin):
    """Начисление партнёру. Отрицательные значения корректируют накопитель."""

    __tablename__ = "referral_rewards"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    inviter_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    invitee_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    round_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    amount_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), default=RewardStatus.PENDING.value, nullable=False
    )
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (Index("ix_rewards_inviter_status", "inviter_id", "status"),)


class Bonus(Base, TimestampMixin):
    """Выданный бонус (ежедневный / регистрационный и т.п.)."""

    __tablename__ = "bonuses"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String(24), default=BonusType.DAILY.value)
    amount_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), default=BonusStatus.PAID.value, nullable=False
    )
    period_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    claimed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        # один бонус одного типа за одну дату
        UniqueConstraint("user_id", "kind", "period_date", name="uq_bonus_period"),
        Index("ix_bonuses_user_created", "user_id", "created_at"),
    )


class Cashback(Base, TimestampMixin):
    """Кешбэк за расчётный период. Повторное получение невозможно."""

    __tablename__ = "cashback"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    turnover_minor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    loss_minor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    percent: Mapped[float] = mapped_column(default=0.0, nullable=False)
    amount_minor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), default=BonusStatus.PENDING.value, nullable=False
    )
    claimed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        UniqueConstraint("user_id", "period_start", name="uq_cashback_period"),
        Index("ix_cashback_status", "status"),
    )


class LeaderboardSnapshot(Base, TimestampMixin):
    """Кэш рассчитанного топа по периоду (для дешёвых перерисовок)."""

    __tablename__ = "leaderboard_snapshots"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    period: Mapped[str] = mapped_column(String(16), nullable=False)
    computed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.utcnow, nullable=False
    )
    payload: Mapped[str] = mapped_column(String(4000), default="[]", nullable=False)
    entries: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    __table_args__ = (UniqueConstraint("period", name="uq_leaderboard_period"),)


class AdminAction(Base, TimestampMixin):
    """Аудит-лог любых административных действий."""

    __tablename__ = "admin_actions"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    admin_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    action: Mapped[str] = mapped_column(String(32), nullable=False)
    target_user_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    payload: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=datetime.utcnow, nullable=False
    )

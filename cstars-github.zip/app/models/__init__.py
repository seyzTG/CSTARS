"""Все ORM-модели проекта (единая точка импорта для Alembic/метаданных)."""

from app.models.check import Check
from app.models.enums import (
    AdminActionType,
    BonusStatus,
    BonusType,
    CheckStatus,
    PaymentProvider,
    PaymentStatus,
    PrivacyMode,
    ReferralStatus,
    RewardStatus,
    RoundStatus,
    TransactionStatus,
    TransactionType,
    WalletKind,
    WebhookStatus,
    WithdrawalStatus,
)
from app.models.finance import Transaction, WebhookEvent
from app.models.game import Bet, CustomGameMode, Game, GameRound
from app.models.payment import Payment, Withdrawal
from app.models.social import (
    AdminAction,
    Bonus,
    Cashback,
    LeaderboardSnapshot,
    Referral,
    ReferralReward,
)
from app.models.user import User, UserSettings, Wallet

__all__ = [
    "User",
    "UserSettings",
    "Wallet",
    "Transaction",
    "WebhookEvent",
    "Game",
    "CustomGameMode",
    "GameRound",
    "Bet",
    "Payment",
    "Withdrawal",
    "Check",
    "Referral",
    "ReferralReward",
    "Bonus",
    "Cashback",
    "LeaderboardSnapshot",
    "AdminAction",
    # enums
    "TransactionType",
    "TransactionStatus",
    "WalletKind",
    "RoundStatus",
    "PaymentStatus",
    "PaymentProvider",
    "WithdrawalStatus",
    "CheckStatus",
    "PrivacyMode",
    "BonusType",
    "BonusStatus",
    "ReferralStatus",
    "RewardStatus",
    "AdminActionType",
    "WebhookStatus",
]

"""Пользователи, настройки и кошельки."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base, TimestampMixin
from app.models.enums import PrivacyMode


class User(Base, TimestampMixin):
    __tablename__ = "users"

    # Первичный ключ = Telegram ID (без суррогатных id)
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)

    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    display_name: Mapped[str | None] = mapped_column(String(64), nullable=True)
    nickname: Mapped[str | None] = mapped_column(String(32), nullable=True)
    privacy_mode: Mapped[str] = mapped_column(
        String(16), default=PrivacyMode.TG_NAME.value, nullable=False
    )
    referral_token: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    referred_by_id: Mapped[int | None] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    language: Mapped[str] = mapped_column(String(8), default="ru", nullable=False)
    registered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    settings: Mapped[UserSettings | None] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    wallet: Mapped["Wallet | None"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_users_referred_by", "referred_by_id"),
        Index("ix_users_created", "registered_at"),
    )

    @property
    def public_name(self) -> str:
        """Имя для публичных экранов с учётом настройки приватности."""
        if self.privacy_mode == PrivacyMode.ANONYMOUS.value:
            return "Аноним"
        if self.privacy_mode == PrivacyMode.NICKNAME.value and self.nickname:
            return self.nickname
        if self.username:
            return f"@{self.username}"
        parts = [p for p in (self.first_name, self.last_name) if p]
        if parts:
            return " ".join(parts)
        return str(self.id)

    def display_label(self) -> str:
        """Как показывают имя внутри карточек самого пользователя.

        Учитывает настройку приватности: «Анонимность» → Аноним,
        «Никнейм» → никнейм, иначе Telegram-имя.
        """
        if self.privacy_mode == PrivacyMode.ANONYMOUS.value:
            return "Аноним"
        if self.privacy_mode == PrivacyMode.NICKNAME.value and self.nickname:
            return self.nickname
        if self.username:
            return f"@{self.username}"
        parts = [p for p in (self.first_name, self.last_name) if p]
        return " ".join(parts) if parts else str(self.id)


class UserSettings(Base, TimestampMixin):
    __tablename__ = "user_settings"

    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    hide_from_top: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    notify_payments: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    notify_games: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    allow_checks: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    user: Mapped[User] = relationship(back_populates="settings")


class Wallet(Base, TimestampMixin):
    """Балансы. REAL — собственные средства, BONUS — бонусные (не выводятся)."""

    __tablename__ = "balances"

    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True
    )
    # суммы в минорных единицах (×100) — только целые числа
    real_balance: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    bonus_balance: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    deposited_total: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    withdrawn_total: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    turnover: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    games_played: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    cashback_paid: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)

    user: Mapped[User] = relationship(back_populates="wallet")

    @property
    def total(self) -> int:
        return self.real_balance + self.bonus_balance

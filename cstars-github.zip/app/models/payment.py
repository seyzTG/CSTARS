"""Платежи и заявки на вывод."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base, BigIntPK, TimestampMixin
from app.models.enums import PaymentStatus, WithdrawalStatus


class Payment(Base, TimestampMixin):
    """Пополнение через один из платёжных адаптеров."""

    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    provider: Mapped[str] = mapped_column(String(24), nullable=False)
    amount_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)  # внутр. единицы ×100
    # настоящая валюта провайдера (XTR/USDT/...) — НЕ равна внутренним единицам
    provider_amount: Mapped[float | None] = mapped_column(nullable=True)
    provider_currency: Mapped[str | None] = mapped_column(String(16), nullable=True)
    status: Mapped[str] = mapped_column(
        String(16), default=PaymentStatus.PENDING.value, nullable=False
    )
    payload: Mapped[str | None] = mapped_column(String(256), nullable=True)
    external_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    invoice_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    __table_args__ = (
        Index("ix_payments_external", "external_id"),
        Index("ix_payments_status", "status"),
    )


class Withdrawal(Base, TimestampMixin):
    """Заявка на вывод. Статус «Выполнено» ставится только после реальной выплаты."""

    __tablename__ = "withdrawals"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)  # uuid4().hex
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    amount_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    commission_minor: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    payout_minor: Mapped[int] = mapped_column(BigInteger, nullable=False)
    method: Mapped[str] = mapped_column(String(24), nullable=False)
    destination: Mapped[str | None] = mapped_column(String(128), nullable=True)
    status: Mapped[str] = mapped_column(
        String(16), default=WithdrawalStatus.PENDING.value, nullable=False
    )
    admin_comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    decided_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    decided_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    user_notified: Mapped[bool] = mapped_column(default=False, nullable=False)

    __table_args__ = (
        Index("ix_withdrawals_status", "status"),
        Index("ix_withdrawals_user_created", "user_id", "created_at"),
    )

"""Перечисления домена."""

from __future__ import annotations

import enum


class TransactionType(str, enum.Enum):
    DEPOSIT = "deposit"                # пополнение
    BET = "bet"                        # списание ставки
    PAYOUT = "payout"                  # выплата выигрыша
    REFUND = "refund"                  # возврат ставки
    BONUS = "bonus"                    # начисление бонуса
    CASHBACK = "cashback"              # начисление кешбэка
    REFERRAL = "referral"              # реферальное начисление
    CHECK_CREATE = "check_create"      # создание чека
    CHECK_REDEEM = "check_redeem"      # погашение чека
    CHECK_CANCEL = "check_cancel"      # отмена чека
    WITHDRAW = "withdraw"              # вывод средств
    WITHDRAW_REJECT = "withdraw_reject"# возврат при отклонении заявки
    CANCEL = "cancel"                  # отмена операции


class WalletKind(str, enum.Enum):
    """Раздельные кошельки: настоящие средства и бонусные."""

    REAL = "real"
    BONUS = "bonus"


class TransactionStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class RoundStatus(str, enum.Enum):
    PENDING = "pending"
    WON = "won"
    LOST = "lost"
    VOID = "void"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PaymentProvider(str, enum.Enum):
    STARS = "stars"
    CRYPTOBOT = "cryptobot"
    XROCKET = "xrocket"
    CRYPTO = "crypto"
    GIFTS = "gifts"


class WithdrawalStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    PAID = "paid"


class CheckStatus(str, enum.Enum):
    ACTIVE = "active"
    REDEEMED = "redeemed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


class PrivacyMode(str, enum.Enum):
    """Как пользователя показывают другим (топ, общий канал, ставки)."""

    TG_NAME = "tg_name"      # имя Telegram
    NICKNAME = "nickname"    # свой никнейм
    ANONYMOUS = "anonymous"  # «Аноним»


class BonusType(str, enum.Enum):
    DAILY = "daily"
    REGISTRATION = "registration"
    WAGER = "wager"


class BonusStatus(str, enum.Enum):
    PENDING = "pending"
    PAID = "paid"
    CANCELLED = "cancelled"


class ReferralStatus(str, enum.Enum):
    ACTIVE = "active"
    REJECTED = "rejected"   # самоприглашение / повтор


class RewardStatus(str, enum.Enum):
    PENDING = "pending"     # накоплено, ещё не выведено
    PAID = "paid"           # списано на баланс
    ADJUSTED = "adjusted"   # скорректировано отрицательным результатом


class AdminActionType(str, enum.Enum):
    APPROVE_WITHDRAWAL = "approve_withdrawal"
    REJECT_WITHDRAWAL = "reject_withdrawal"
    BLOCK_USER = "block_user"
    UNBLOCK_USER = "unblock_user"
    GRANT_BONUS = "grant_bonus"
    UPDATE_COEFFICIENTS = "update_coefficients"
    UPDATE_BONUSES = "update_bonuses"
    UPDATE_CASHBACK = "update_cashback"
    UPDATE_REFERRAL = "update_referral"
    CUSTOM_MODE = "custom_mode"
    BALANCE_ADJUST = "balance_adjust"


class WebhookStatus(str, enum.Enum):
    RECEIVED = "received"
    PROCESSED = "processed"
    FAILED = "failed"

"""Транзакционный журнал финансов."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base, BigIntPK, TimestampMixin
from app.models.enums import TransactionStatus, TransactionType, WalletKind


class Transaction(Base, TimestampMixin):
    """Одна финансовая операция. Баланс НИКОГДА не меняется без записи здесь."""

    __tablename__ = "transactions"

    id: Mapped[str] = mapped_column(String(32), primary_key=True)  # uuid4().hex
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    type: Mapped[str] = mapped_column(String(24), nullable=False)
    wallet: Mapped[str] = mapped_column(String(8), default=WalletKind.REAL.value)
    amount: Mapped[int] = mapped_column(BigInteger, nullable=False)  # >0 зачисление, <0 списание
    currency: Mapped[str] = mapped_column(String(8), default="XTR", nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), default=TransactionStatus.PENDING.value, nullable=False
    )
    balance_after: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    external_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    # связь с игровым раундом / чеком / платежом / заявкой
    game_round_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    check_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    payment_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    withdrawal_id: Mapped[str | None] = mapped_column(String(32), nullable=True)
    # идемпотентность: повтор с тем же ключом не создаёт вторую операцию
    idempotency_key: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        Index("ix_transactions_user_created", "user_id", "created_at"),
        Index("ix_transactions_type", "type"),
        Index("ix_transactions_external", "external_id"),
        Index("ix_transactions_status", "status"),
        Index("ix_transactions_round", "game_round_id"),
    )


class WebhookEvent(Base, TimestampMixin):
    """Входящее событие платёжного провайдера (идемпотентная обработка)."""

    __tablename__ = "webhook_events"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    provider: Mapped[str] = mapped_column(String(24), nullable=False)
    external_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="received", nullable=False)
    processed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    attempt: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    __table_args__ = (
        # повторная доставка того же события не обрабатывается дважды
        Index(
            "uq_webhook_event",
            "provider",
            "external_id",
            "event_type",
            unique=True,
        ),
    )

"""Игровые сущности: игры, раунды, ставки, авторские режимы."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base, BigIntPK, TimestampMixin
from app.models.enums import RoundStatus


class Game(Base, TimestampMixin):
    """Каталог игр (встроенные + опубликованные авторские)."""

    __tablename__ = "games"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(64), nullable=False)
    kind: Mapped[str] = mapped_column(String(16), default="builtin", nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    # произвольная конфигурация режима (JSON): исходы, коэффициенты, правила
    config: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)


class CustomGameMode(Base, TimestampMixin):
    """Авторский режим: создаётся администратором, результат — серверный CSPRNG."""

    __tablename__ = "custom_game_modes"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(64), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    # [{"code": "a", "label": "A", "coef": 2.0, "weight": 1}, ...]
    outcomes: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    __table_args__ = (Index("ix_custom_modes_enabled", "enabled"),)


class GameRound(Base, TimestampMixin):
    """Один бросок/вращение."""

    __tablename__ = "game_rounds"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    game_code: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # значения Telegram Dice (для нескольких бросков — список)
    dice_values: Mapped[list | None] = mapped_column(JSON, nullable=True)
    outcome_code: Mapped[str | None] = mapped_column(String(48), nullable=True)
    outcome_label: Mapped[str | None] = mapped_column(String(64), nullable=True)
    multiplier: Mapped[float | None] = mapped_column(nullable=True)
    stake: Mapped[int] = mapped_column(BigInteger, nullable=False)       # минорные
    payout: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    bonus_spent: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    status: Mapped[str] = mapped_column(
        String(16), default=RoundStatus.PENDING.value, nullable=False
    )
    message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    # защита от повторной обработки одного игрового действия
    action_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        Index("ix_rounds_user_created", "user_id", "created_at"),
        Index("ix_rounds_status", "status"),
    )


class Bet(Base, TimestampMixin):
    """Выбранный игроком исход в рамках раунда."""

    __tablename__ = "bets"

    id: Mapped[int] = mapped_column(BigIntPK, primary_key=True, autoincrement=True)
    round_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("game_rounds.id", ondelete="CASCADE"), nullable=False
    )
    user_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    game_code: Mapped[str] = mapped_column(String(32), nullable=False)
    outcome_code: Mapped[str] = mapped_column(String(48), nullable=False)
    outcome_label: Mapped[str] = mapped_column(String(64), nullable=False)
    amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    multiplier: Mapped[float] = mapped_column(nullable=False)
    potential_payout: Mapped[int] = mapped_column(BigInteger, nullable=False)
    won: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    is_custom: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    __table_args__ = (
        Index("ix_bets_round", "round_id"),
        Index("ix_bets_user_created", "user_id", "created_at"),
        Index("ix_bets_outcome", "game_code", "outcome_code"),
    )

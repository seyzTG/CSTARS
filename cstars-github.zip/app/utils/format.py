"""Построение текстов сообщений: мини-разметка → текст + MessageEntity.

Поддерживаемые теги:
    <b> <i> <u> <s> <code> <pre> <a href="url"> <blockquote>
Плейсхолдеры эмодзи:
    {{e:роль}}   →  Unicode-резерв + (если задан ID) сущность custom_emoji

Почему без parse_mode: Telegram Bot API не отдаёт <tg-emoji> в HTML-разметке,
поэтому собственные сущности строятся вручную — это даёт настоящие
Premium Custom Emoji, а не имитацию.
"""

from __future__ import annotations

import html as _html
import re
from dataclasses import dataclass

from aiogram.types import MessageEntity

from app.config.custom_emojis import emoji as resolve_emoji

_SUPPORTED = {"b": "bold", "i": "italic", "u": "underline", "s": "strikethrough",
              "code": "code", "pre": "pre", "blockquote": "blockquote"}

# {{e:роль}} — в сыром шаблоне; {e:роль} — после .format() или пред-форматирования
_EMOJI_DOUBLE = re.compile(r"\{\{e:([A-Za-z0-9_]+)\}\}")
_EMOJI_SINGLE = re.compile(r"\{e:([A-Za-z0-9_]+)\}")
_EMOJI_ANY = re.compile(r"\{\{?e:[A-Za-z0-9_]+\}\}?")

# Сентинел в приватной зоне Unicode: переживает .format(), парсер заменяет на эмодзи
_SENTINEL = "\ue000"


@dataclass
class _Open:
    tag: str
    entity_type: str
    start: int                 # индекс символа в итоговом тексте
    attrs: dict[str, str]


def utf16_len(value: str) -> int:
    """Длина строки в UTF-16 код-юнитах (требование Telegram)."""
    return sum(2 if ord(ch) > 0xFFFF else 1 for ch in value)


def _utf16_prefix(value: str) -> list[int]:
    table = [0] * (len(value) + 1)
    offset = 0
    for index, ch in enumerate(value):
        table[index] = offset
        offset += 2 if ord(ch) > 0xFFFF else 1
    table[len(value)] = offset
    return table


def _unescape(value: str) -> str:
    return (
        value.replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", '"')
        .replace("&amp;", "&")
    )


def render(template: str, **context: object) -> tuple[str, list[MessageEntity]]:
    """Разобрать шаблон и вернуть (чистый текст, сущности)."""
    # Плейсхолдеры эмодзи вырезаются ДО .format(): иначе {{e:x}} схлопнется
    # в {e:x}, парсер его не найдёт и пользователь увидит «{e:balance}».
    roles: list[str] = []

    def _stash(match: re.Match[str]) -> str:
        roles.append(match.group(1))
        return f"{_SENTINEL}{len(roles) - 1}{_SENTINEL}"

    prepared = _EMOJI_DOUBLE.sub(_stash, template)
    if context:
        try:
            text = prepared.format(**context)
        except (KeyError, IndexError, ValueError):
            # шаблон уже отформатирован обработчиком — берём как есть
            text = prepared
    else:
        text = prepared
    # подстраховка: одиночный {e:роль} из пред-отформатированных шаблонов
    text = _EMOJI_SINGLE.sub(_stash, text)

    out: list[str] = []
    entities: list[tuple[int, int, dict]] = []   # (start_char, end_char, kwargs)
    stack: list[_Open] = []

    index = 0
    length = len(text)

    def close_top() -> None:
        if not stack:
            return
        opened = stack.pop()
        end = len(out)
        if end > opened.start:
            entities.append((opened.start, end, _entity_kwargs(opened)))

    while index < length:
        # --- плейсхолдер эмодзи (сентинел после .format()) ---
        if text[index] == _SENTINEL:
            close_at = text.find(_SENTINEL, index + 1)
            if close_at != -1:
                try:
                    role = roles[int(text[index + 1:close_at])]
                except (ValueError, IndexError):
                    role = ""
                if role:
                    item = resolve_emoji(role)
                    start = len(out)
                    out.append(item.fallback)
                    if item.has_custom:
                        entities.append(
                            (start, len(out),
                             {"type": "custom_emoji",
                              "custom_emoji_id": item.custom_id})
                        )
                index = close_at + 1
                continue

        ch = text[index]

        if ch == "<":
            tag_end = text.find(">", index)
            if tag_end != -1:
                raw_tag = text[index + 1:tag_end].strip()
                if raw_tag.startswith("/"):
                    name = raw_tag[1:].strip().lower()
                    # закрыть ближайший соответствующий тег
                    for pos in range(len(stack) - 1, -1, -1):
                        if stack[pos].tag == name:
                            while len(stack) - 1 >= pos:
                                close_top()
                            break
                    index = tag_end + 1
                    continue
                if raw_tag.startswith("a "):
                    href = ""
                    if "href=" in raw_tag:
                        part = raw_tag.split("href=", 1)[1].strip().strip('"').strip("'")
                        href = part.split()[0].strip('"').strip("'") if part else ""
                    stack.append(_Open("a", "text_link", len(out), {"url": href}))
                    index = tag_end + 1
                    continue
                name = raw_tag.split()[0].lower() if raw_tag else ""
                if name in _SUPPORTED:
                    stack.append(_Open(name, _SUPPORTED[name], len(out), {}))
                    index = tag_end + 1
                    continue
                # неизвестный тег — выводим как текст
                out.append(_html.escape(text[index:tag_end + 1]))
                index = tag_end + 1
                continue

        if ch == "&":
            entity_value = _unescape(text[index:index + 6])
            if entity_value != text[index:index + 6] or text.startswith("&amp;", index) \
                    or text.startswith("&lt;", index) or text.startswith("&gt;", index) \
                    or text.startswith("&quot;", index):
                handled = False
                for token in ("&amp;", "&lt;", "&gt;", "&quot;"):
                    if text.startswith(token, index):
                        out.append(_unescape(token))
                        index += len(token)
                        handled = True
                        break
                if handled:
                    continue

        out.append(ch)
        index += 1

    while stack:
        close_top()

    plain = "".join(out)
    prefix = _utf16_prefix(plain)
    built: list[MessageEntity] = []
    for start, end, kwargs in entities:
        offset = prefix[start]
        entity_length = prefix[end] - offset
        if entity_length <= 0:
            continue
        built.append(MessageEntity(type=kwargs.pop("type"), offset=offset,
                                   length=entity_length, **kwargs))
    return plain, built


def _entity_kwargs(opened: _Open) -> dict:
    if opened.tag == "a":
        return {"type": "text_link", "url": opened.attrs.get("url", "")}
    return {"type": opened.entity_type}


def single(template: str, **context: object) -> tuple[str, list[MessageEntity]]:
    """Алиас render() для обработчиков."""
    return render(template, **context)


def plain_text(value: str) -> str:
    """Убрать плейсхолдеры эмодзи — для callback-тостов, где сущности не работают."""
    return _EMOJI_ANY.sub("", value).strip()

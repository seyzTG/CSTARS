"""Логирование без утечки секретов."""

from __future__ import annotations

import logging
import re
import sys

from app.config.settings import settings

# маскируем токены/ключи в любых записях лога
_SECRET_PATTERNS = [
    re.compile(r"\b\d{8,12}:[A-Za-z0-9_-]{30,}\b"),     # bot token
    re.compile(r"(?i)(api[_-]?key|token|secret|password)\s*[=:]\s*\S+"),
]


def sanitize(message: str) -> str:
    for pattern in _SECRET_PATTERNS:
        message = pattern.sub(lambda m: f"{m.group(1) if m.lastindex else ''}***", message)
    return message


class SanitizingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        original = super().format(record)
        return sanitize(original)


def setup_logging() -> None:
    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(
        SanitizingFormatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    )
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(settings.log_level.upper())
    # гасим шум транспортного слоя aiogram
    logging.getLogger("aiogram").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)

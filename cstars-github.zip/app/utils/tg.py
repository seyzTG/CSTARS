"""Вспомогательные функции отправки сообщений с собственными сущностями."""

from __future__ import annotations

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardMarkup,
    Message,
)

from app.utils.format import plain_text, render
from app.utils.logging import get_logger

log = get_logger(__name__)


async def send(
    message: Message,
    template: str,
    *,
    reply_markup: InlineKeyboardMarkup | None = None,
    **context: object,
) -> Message | None:
    """Отправить новое сообщение с мини-разметкой."""
    text, entities = render(template, **context)
    try:
        return await message.answer(
            text, entities=entities, reply_markup=reply_markup
        )
    except TelegramBadRequest as exc:
        log.warning("send failed: %s", str(exc)[:200])
        return None


async def edit(
    message: Message,
    template: str,
    *,
    reply_markup: InlineKeyboardMarkup | None = None,
    **context: object,
) -> bool:
    """Отредактировать сообщение (без создания дублей)."""
    text, entities = render(template, **context)
    try:
        await message.edit_text(
            text, entities=entities, reply_markup=reply_markup
        )
        return True
    except TelegramBadRequest as exc:
        # «message is not modified» — норма при повторном рендере
        if "not modified" in str(exc).lower():
            return True
        log.warning("edit failed: %s", str(exc)[:200])
        return False


async def edit_or_send(
    message: Message,
    template: str,
    *,
    reply_markup: InlineKeyboardMarkup | None = None,
    **context: object,
) -> Message | None:
    """Редактировать текущее сообщение либо отправить новое."""
    if await edit(message, template, reply_markup=reply_markup, **context):
        return message
    return await send(message, template, reply_markup=reply_markup, **context)


async def answer(
    query: CallbackQuery, text: str | None = None, *, alert: bool = False
) -> None:
    """Ответить на callback, подавив часики клика."""
    try:
        await query.answer(plain_text(text) if text else text, show_alert=alert)
    except TelegramBadRequest:
        pass


async def try_edit_markup(
    message: Message, reply_markup: InlineKeyboardMarkup | None
) -> None:
    try:
        await message.edit_reply_markup(reply_markup=reply_markup)
    except TelegramBadRequest:
        pass

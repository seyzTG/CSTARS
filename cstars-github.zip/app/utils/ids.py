"""Генерация идентификаторов и токенов (криптографически стойкие)."""

from __future__ import annotations

import hashlib
import secrets
import uuid


def uuid_hex() -> str:
    return uuid.uuid4().hex


def new_token(length: int = 24) -> str:
    """URL-безопасный токен (чеки, реферальные ссылки)."""
    return secrets.token_urlsafe(length)[:length]


def referral_token() -> str:
    return secrets.token_urlsafe(10)


def referral_link(bot_username: str, token: str) -> str:
    return f"https://t.me/{bot_username}?start={token}"


def check_link(bot_username: str, token: str) -> str:
    return f"https://t.me/{bot_username}?start=check_{token}"


def action_id(*parts: object) -> str:
    """Стабильный идентификатор действия — защита от повторной обработки."""
    raw = ":".join(str(p) for p in parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:40]

"""Денежные единицы: хранение в минорных единицах (×100), вывод и проверки."""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal

SCALE = 100


def to_minor(amount: int | float | str) -> int:
    """Перевести «целые звёзды» в минорные единицы хранения."""
    return int(Decimal(str(amount)).scaleb(2).to_integral_value(rounding=ROUND_HALF_UP))


def to_major(minor: int) -> Decimal:
    """Минорные единицы → Decimal для отображения."""
    return (Decimal(minor) / SCALE).quantize(Decimal("0.01"))


def format_amount(minor: int) -> str:
    """123456 → «1234.56», 500000 → «5000», 1050 → «10.5»."""
    value = to_major(minor)
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def apply_multiplier(minor: int, coefficient: float) -> int:
    """Начисление выигрыша: ставка × коэффициент, округление до минорных."""
    result = Decimal(minor) * Decimal(str(coefficient))
    return int(result.to_integral_value(rounding=ROUND_HALF_UP))


def parse_amount(raw: str) -> int | None:
    """Разобрать ввод пользователя (целые/дробные) в минорные единицы."""
    text = raw.strip().replace(",", ".").replace(" ", "").replace("★", "")
    if not text:
        return None
    try:
        value = Decimal(text)
    except Exception:
        return None
    if value <= 0:
        return None
    if value.as_tuple().exponent < -2:
        return None
    return to_minor(value)

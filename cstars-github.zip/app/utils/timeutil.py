"""Время и человекочитаемые интервалы (для отсчётов кешбэка/бонусов)."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def plural_ru(number: int, one: str, few: str, many: str) -> str:
    """Русская плюрализация: 1 день, 2 дня, 5 дней."""
    n = abs(number)
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return few
    return many


def humanize_delta(delta: timedelta) -> str:
    """«1 день 9 часов 57 минут» / «2 часа» / «меньше минуты»."""
    total = max(0, int(delta.total_seconds()))
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    parts: list[str] = []
    if days:
        parts.append(f"{days} {plural_ru(days, 'день', 'дня', 'дней')}")
    if hours:
        parts.append(f"{hours} {plural_ru(hours, 'час', 'часа', 'часов')}")
    if minutes and not days:
        parts.append(f"{minutes} {plural_ru(minutes, 'минута', 'минуты', 'минут')}")
    if not parts:
        return "меньше минуты"
    return " ".join(parts)


def format_dt(value: datetime | None) -> str:
    if value is None:
        return "—"
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().strftime("%d.%m.%Y %H:%M")


def format_date(value: datetime | None) -> str:
    if value is None:
        return "—"
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone().strftime("%d.%m.%Y")


def day_bounds(moment: datetime, days_back: int = 0) -> tuple[datetime, datetime]:
    """Границы суток (UTC) для топов: сегодня/вчера/неделя/месяц."""
    start = moment.replace(hour=0, minute=0, second=0, microsecond=0)
    start = start - timedelta(days=days_back)
    return start, start + timedelta(days=1)

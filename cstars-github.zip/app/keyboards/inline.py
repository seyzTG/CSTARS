"""Inline-клавиатуры разделов (кнопки и callback-data повторяют референс).

Формат callback-data: «префикс:действие:параметр» (короче 64 байт).
"""

from __future__ import annotations

from urllib.parse import quote

from aiogram.enums import ButtonStyle
from aiogram.types import (
    CopyTextButton,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.config import texts
from app.config.custom_emojis import emoji as resolve_emoji
from app.config.custom_emojis import resolve_id
from app.config.games import GAMES, GAME_TAB_ORDER, visible_outcomes
from app.services.withdrawals import SUPPORTED_METHODS


def _btn(
    text: str,
    callback_data: str,
    *,
    icon: str | None = None,
    style: str | None = None,
) -> InlineKeyboardButton:
    """Кнопка с Premium-иконкой (если задан custom_emoji_id роли) и цветом.

    Если у роли нет своего Premium-эмодзи (например, «blackjack»), перед
    текстом подставляется Unicode-резерв из каталога.
    """
    custom_id = resolve_id(icon) if icon else None
    if icon and custom_id is None:
        text = f"{resolve_emoji(icon).fallback} {text}"
    return InlineKeyboardButton(
        text=text,
        callback_data=callback_data,
        icon_custom_emoji_id=custom_id,
        style=style,
    )


# Короткие подписи вкладок игр (иконка — из каталога по emoji_role)
TAB_TITLES: dict[str, str] = {
    "dice": "Кости",
    "football": "Футбол",
    "basketball": "Баскет",
    "darts": "Дартс",
    "bowling": "Боулинг",
    "slots": "Слоты",
    "blackjack": "21 Очко",
    "crash": "Crash",
}


def _back(target: str = "menu") -> InlineKeyboardButton:
    return _btn(texts.KB_BACK, f"nav:{target}", icon="back")


# ------------------------------ главное меню -------------------------------

def build_menu_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn(texts.BTN_PARTNER, "nav:referral", icon="referral"))
    builder.row(_btn(texts.BTN_DAILY_BONUS, "nav:daily", icon="bonus"))
    builder.row(
        _btn(texts.BTN_CHECKS, "nav:checks", icon="checks"),
        _btn(texts.BTN_TOP, "top:all", icon="top"),
    )
    builder.row(_btn(texts.BTN_INFO, "nav:info", icon="info"))
    return builder.as_markup()


# ------------------------------- профиль -----------------------------------

def build_profile_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        _btn(texts.BTN_DEPOSIT, "nav:deposit", icon="deposit",
             style=ButtonStyle.SUCCESS),
        _btn(texts.BTN_WITHDRAW, "nav:withdraw", icon="withdraw"),
    )
    builder.row(_btn(texts.BTN_CASHBACK, "nav:cashback", icon="cashback"))
    builder.row(_btn(texts.BTN_PRIVACY, "nav:privacy", icon="privacy"))
    return builder.as_markup()


# ----------------------------- игровая панель ------------------------------

def build_game_panel(
    *,
    game_code: str,
    bet_major: str,
    balance_major: str,
    dice_count: int = 1,
) -> InlineKeyboardMarkup:
    """Панель игры: вкладки игр, исходы, ставка, режимы."""
    builder = InlineKeyboardBuilder()

    # вкладки игр (иконка + короткое имя), активная — primary; по 4 в строке
    tabs: list[InlineKeyboardButton] = []
    for code in GAME_TAB_ORDER:
        spec = GAMES[code]
        title = TAB_TITLES.get(code, spec.title)
        label = f"[{title}]" if code == game_code else title
        tabs.append(_btn(
            label, f"game:tab:{code}",
            icon=spec.emoji_role,
            style=ButtonStyle.PRIMARY if code == game_code else None,
        ))
    for i in range(0, len(tabs), 4):
        builder.row(*tabs[i:i + 4])

    if game_code == "blackjack":
        # ставка уже выбрана: одна кнопка — раздача (списание + 2 карты)
        builder.row(_btn(
            texts.BTN_BJ_DEAL, "game:bj:start", icon="blackjack",
            style=ButtonStyle.SUCCESS,
        ))
    elif game_code == "crash":
        # ставка уже выбрана: одна кнопка — запуск ракеты
        builder.row(_btn(
            texts.BTN_CRASH_START, "game:crash:start",
            style=ButtonStyle.SUCCESS,
        ))
    elif game_code == "dice":
        builder.row(
            _btn("1 Куб" if dice_count == 1 else "[1 Куб]", "game:count:1",
                 style=ButtonStyle.PRIMARY if dice_count == 1 else None),
            _btn("2 Куба" if dice_count == 2 else "[2 Куба]", "game:count:2",
                 style=ButtonStyle.PRIMARY if dice_count == 2 else None),
            _btn("3 Куба" if dice_count == 3 else "[3 Куба]", "game:count:3",
                 style=ButtonStyle.PRIMARY if dice_count == 3 else None),
        )
        builder.row(
            _btn("Тотал ›", "game:sub:total", icon="dice"),
            _btn("Диапазон ›", "game:sub:range", icon="dice"),
        )
        coefs = visible_outcomes("dice", dice_count)
        parity = [o for o in coefs if o.group == "parity"]
        numbers = [o for o in coefs if o.group == "number"]
        if len(parity) == 2:
            builder.row(
                InlineKeyboardButton(text=parity[0].label, callback_data=f"game:bet:{parity[0].code}"),
                InlineKeyboardButton(text=parity[1].label, callback_data=f"game:bet:{parity[1].code}"),
            )
        for i in range(0, len(numbers), 3):
            chunk = numbers[i:i + 3]
            builder.row(*[
                InlineKeyboardButton(text=o.label, callback_data=f"game:bet:{o.code}")
                for o in chunk
            ])
    elif game_code == "slots":
        outcomes = visible_outcomes("slots")
        for i in range(0, len(outcomes), 2):
            chunk = outcomes[i:i + 2]
            builder.row(*[
                InlineKeyboardButton(text=o.label, callback_data=f"game:bet:{o.code}")
                for o in chunk
            ])
        builder.row(_btn(texts.BTN_OTHER, "game:sub:slots", icon="slots"))
    else:
        outcomes = visible_outcomes(game_code)
        for i in range(0, len(outcomes), 2):
            chunk = outcomes[i:i + 2]
            builder.row(*[
                InlineKeyboardButton(text=o.label, callback_data=f"game:bet:{o.code}")
                for o in chunk
            ])

    builder.row(_btn(texts.BTN_EDIT_BET, "game:edit", icon="edit"))
    builder.row(_btn(texts.BTN_MODES, "nav:modes", icon="dice"))
    return builder.as_markup()


def build_dice_submenu(kind: str, dice_count: int) -> InlineKeyboardMarkup:
    """Подменю «Тотал» / «Диапазон»."""
    from app.config.games import dice_outcomes

    builder = InlineKeyboardBuilder()
    group = "total" if kind == "total" else "range"
    items = [o for o in dice_outcomes(dice_count) if o.group == group]
    for i in range(0, len(items), 3):
        chunk = items[i:i + 3]
        builder.row(*[
            InlineKeyboardButton(
                text=f"{o.label} (×{o.coef:g})" if o.coef else o.label,
                callback_data=f"game:bet:{o.code}",
            )
            for o in chunk
        ])
    builder.row(_btn(
        texts.BTN_BACK_TO_OUTCOMES, "game:panel", icon="back"))
    return builder.as_markup()


def build_slots_submenu() -> InlineKeyboardMarkup:
    """Подменю слотов «Другое»: дополнительные комбинации."""
    spec = GAMES["slots"]
    builder = InlineKeyboardBuilder()
    for outcome in spec.outcomes:
        if outcome.group == "other":
            builder.row(InlineKeyboardButton(
                text=outcome.label, callback_data=f"game:bet:{outcome.code}",
            ))
    builder.row(_btn(texts.BTN_BACK_TO_OUTCOMES, "game:panel", icon="back"))
    return builder.as_markup()


def build_blackjack_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура активной раздачи: «ещё» / «хватит»."""
    builder = InlineKeyboardBuilder()
    builder.row(
        _btn(texts.BTN_BJ_HIT, "game:bj:hit"),
        _btn(texts.BTN_BJ_STAND, "game:bj:stand", style=ButtonStyle.DANGER),
    )
    return builder.as_markup()


def build_blackjack_result_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура после завершения раздачи: новая игра или к панели."""
    builder = InlineKeyboardBuilder()
    builder.row(_btn(
        texts.BTN_BJ_DEAL, "game:bj:start", icon="blackjack",
        style=ButtonStyle.SUCCESS,
    ))
    builder.row(_btn(texts.KB_BACK, "game:panel", icon="back"))
    return builder.as_markup()


def build_crash_keyboard(round_id: int) -> InlineKeyboardMarkup:
    """Клавиатура активного полёта: только «Забрать»."""
    builder = InlineKeyboardBuilder()
    builder.row(_btn(
        texts.BTN_CRASH_TAKE, f"crash:take:{round_id}",
        style=ButtonStyle.SUCCESS,
    ))
    return builder.as_markup()


def build_crash_result_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура после завершения полёта: новый запуск или к панели."""
    builder = InlineKeyboardBuilder()
    builder.row(_btn(
        texts.BTN_CRASH_START, "game:crash:start",
        style=ButtonStyle.SUCCESS,
    ))
    builder.row(_btn(texts.KB_BACK, "game:panel", icon="back"))
    return builder.as_markup()


# ------------------------------ балансы/оплаты -----------------------------

def build_deposit_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn(texts.BTN_STARS, "pay:dep:stars", icon="star",
                     style=ButtonStyle.SUCCESS))
    builder.row(
        _btn(texts.BTN_CRYPTOBOT, "pay:dep:cryptobot", icon="money"),
        _btn(texts.BTN_XROCKET, "pay:dep:xrocket", icon="money"),
    )
    builder.row(_btn(texts.BTN_CRYPTO, "pay:dep:crypto", icon="money"))
    builder.row(_btn(texts.BTN_GIFTS, "pay:dep:gifts", icon="gift"))
    builder.row(_back("profile"))
    return builder.as_markup()


def build_withdraw_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for code, _label in SUPPORTED_METHODS:
        text = texts.BTN_STARS if code == "stars" else (
            texts.BTN_CRYPTOBOT if code == "cryptobot" else (
                texts.BTN_XROCKET if code == "xrocket" else texts.BTN_CRYPTO
            )
        )
        builder.row(_btn(text, f"pay:wd:{code}",
                         icon="star" if code == "stars" else "withdraw"))
    builder.row(_back("profile"))
    return builder.as_markup()


def build_stars_amount_keyboard() -> InlineKeyboardMarkup:
    """Быстрый выбор суммы пополнения Stars."""
    builder = InlineKeyboardBuilder()
    for amount in (10, 50, 100, 500, 1000):
        builder.row(_btn(f"{amount} ★", f"pay:stars:{amount}", icon="star"))
    builder.row(_back("deposit"))
    return builder.as_markup()


# ------------------------------- кешбэк ------------------------------------

def build_cashback_keyboard(*, available: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn(
        texts.BTN_GET_CASHBACK if available else texts.BTN_CASHBACK_UNAVAILABLE,
        "cb:claim" if available else "cb:info",
        icon="cashback",
        style=ButtonStyle.SUCCESS if available else None,
    ))
    builder.row(_btn(texts.BTN_DETAILS, "cb:details", icon="chart"))
    builder.row(_back("profile"))
    return builder.as_markup()


# ----------------------------- приватность ---------------------------------

def build_privacy_keyboard(mode: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn(
        texts.BTN_ANONYMITY if mode != "anonymous" else f"[{texts.BTN_ANONYMITY}]",
        "privacy:mode:anonymous",
        icon="privacy",
        style=ButtonStyle.PRIMARY if mode == "anonymous" else None,
    ))
    builder.row(
        _btn(
            texts.BTN_NAME_TG if mode != "tg_name" else f"[{texts.BTN_NAME_TG}]",
            "privacy:mode:tg_name",
            icon="profile",
            style=ButtonStyle.PRIMARY if mode == "tg_name" else None,
        ),
        _btn(
            texts.BTN_NICKNAME if mode != "nickname" else f"[{texts.BTN_NICKNAME}]",
            "privacy:mode:nickname",
            icon="edit",
            style=ButtonStyle.PRIMARY if mode == "nickname" else None,
        ),
    )
    builder.row(_btn(texts.BTN_CHANGE_NICKNAME, "privacy:nickname", icon="edit"))
    builder.row(_back("profile"))
    return builder.as_markup()


# -------------------------------- топ --------------------------------------

def build_top_keyboard(period: str) -> InlineKeyboardMarkup:
    mapping = {
        "all": "За всё время",
        "today": "За сегодня",
        "yesterday": "Вчера",
        "week": "Неделя",
        "month": "Месяц",
    }
    builder = InlineKeyboardBuilder()
    builder.row(
        _btn(
            f"• {mapping['all']} •" if period == "all" else mapping["all"],
            "top:all",
            icon="top",
            style=ButtonStyle.PRIMARY if period == "all" else None,
        ),
        _btn(
            f"• {mapping['today']} •" if period == "today" else mapping["today"],
            "top:today",
            icon="clock",
            style=ButtonStyle.PRIMARY if period == "today" else None,
        ),
    )
    builder.row(
        _btn(
            f"• {mapping['yesterday']} •" if period == "yesterday" else mapping["yesterday"],
            "top:yesterday",
            icon="clock",
            style=ButtonStyle.PRIMARY if period == "yesterday" else None,
        ),
        _btn(
            f"• {mapping['week']} •" if period == "week" else mapping["week"],
            "top:week",
            icon="chart",
            style=ButtonStyle.PRIMARY if period == "week" else None,
        ),
        _btn(
            f"• {mapping['month']} •" if period == "month" else mapping["month"],
            "top:month",
            icon="chart",
            style=ButtonStyle.PRIMARY if period == "month" else None,
        ),
    )
    builder.row(_back("menu"))
    return builder.as_markup()


# -------------------------------- чеки -------------------------------------

def build_checks_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn("Создать чек", "check:types", icon="checks",
                     style=ButtonStyle.SUCCESS))
    builder.row(_btn("Создать из чата", "check:share", icon="send"))
    builder.row(_btn("Активные чеки", "check:list", icon="memo"))
    builder.row(_back("menu"))
    return builder.as_markup()


def build_check_types_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn("Персональный чек", "check:personal", icon="checks"))
    builder.row(_btn("Мультичек", "check:multi", icon="checks"))
    builder.row(_back("checks"))
    return builder.as_markup()


def build_check_personal_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn("Создать персональный чек", "check:new", icon="checks",
                     style=ButtonStyle.SUCCESS))
    builder.row(_back("check:types"))
    return builder.as_markup()


def build_active_checks_keyboard(checks: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    from app.utils.money import format_amount

    for item in checks:
        builder.row(_btn(
            f"Отменить {format_amount(item.amount_minor)} ★",
            f"check:cancel:{item.id}",
            icon="error",
            style=ButtonStyle.DANGER,
        ))
    builder.row(_btn("Обновить", "check:list", icon="clock"))
    builder.row(_back("checks"))
    return builder.as_markup()


# --------------------------- партнёрская программа -------------------------

def build_referral_keyboard(link: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    share_url = (
        "https://t.me/share/url?url=" + quote(link, safe="")
        + "&text=" + quote("Играй в CSTARS и получай бонусы!", safe="")
    )
    builder.row(InlineKeyboardButton(
        text=texts.REF_SEND, url=share_url,
        icon_custom_emoji_id=resolve_id("send")))
    builder.row(InlineKeyboardButton(
        text=texts.REF_COPY, copy_text=CopyTextButton(text=link),
        icon_custom_emoji_id=resolve_id("copy")))
    builder.row(_btn(texts.BTN_DETAILS, "ref:details", icon="memo"))
    builder.row(_back("menu"))
    return builder.as_markup()


def build_referral_details_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn(texts.REF_CLAIM, "ref:claim", icon="fire",
                     style=ButtonStyle.SUCCESS))
    builder.row(_back("referral"))
    return builder.as_markup()


# ------------------------------ информация ---------------------------------

def build_info_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(_btn(texts.BTN_RULES, "info:rules", icon="memo"))
    builder.row(InlineKeyboardButton(
        text=texts.BTN_SUPPORT, url=texts.SUPPORT_URL,
        icon_custom_emoji_id=resolve_id("shield")))
    builder.row(_back("menu"))
    return builder.as_markup()


# ------------------------------- режимы ------------------------------------

def build_modes_keyboard(active_code: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for code in GAME_TAB_ORDER:
        spec = GAMES[code]
        title = TAB_TITLES.get(code, spec.title)
        label = title if code != active_code else f"[{title}]"
        builder.row(_btn(
            label, f"game:select:{code}",
            icon=spec.emoji_role,
            style=ButtonStyle.PRIMARY if code == active_code else None,
        ))
    builder.row(_btn(texts.MODES_HISTORY_BTN, "modes:history", icon="memo"))
    builder.row(_back("game"))
    return builder.as_markup()


def build_custom_modes_keyboard(modes: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for mode in modes:
        builder.row(_btn(mode.title, f"custom:play:{mode.code}", icon="dice"))
    builder.row(_back("game"))
    return builder.as_markup()


# -------------------------------- админ ------------------------------------

def build_admin_withdrawal_keyboard(wid: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        _btn("Подтвердить", f"adm:wd:pay:{wid}", icon="success",
             style=ButtonStyle.SUCCESS),
        _btn("Отклонить", f"adm:wd:reject:{wid}", icon="error",
             style=ButtonStyle.DANGER),
    )
    return builder.as_markup()

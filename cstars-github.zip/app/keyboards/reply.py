"""Reply-клавиатура (как на референсе): Играть / Профиль+Баланс / Меню.

Кнопки несут Premium-иконку (icon_custom_emoji_id из каталога ролей)
и цветовой стиль (aiogram ButtonStyle): «Играть» — primary,
«Отменить» — danger.
"""

from __future__ import annotations

from aiogram.enums import ButtonStyle
from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove

from app.config import texts
from app.config.custom_emojis import resolve_id


def _key(text: str, *, icon: str | None = None,
         style: str | None = None) -> KeyboardButton:
    return KeyboardButton(
        text=text,
        icon_custom_emoji_id=resolve_id(icon) if icon else None,
        style=style,
    )


def main_keyboard() -> ReplyKeyboardMarkup:
    """Главное меню бота — единая клавиатура для всех разделов."""
    keyboard = [
        [_key(texts.KB_PLAY, icon="games", style=ButtonStyle.PRIMARY)],
        [_key(texts.KB_PROFILE, icon="profile"),
         _key(texts.KB_BALANCE, icon="balance")],
        [_key(texts.KB_MENU, icon="menu")],
    ]
    return ReplyKeyboardMarkup(
        keyboard=keyboard, resize_keyboard=True, is_persistent=True
    )


def simple_cancel_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура ввода (красная «Отменить»), как при изменении ставки."""
    return ReplyKeyboardMarkup(
        keyboard=[[_key(texts.KB_CANCEL, icon="error",
                        style=ButtonStyle.DANGER)]],
        resize_keyboard=True,
    )


def remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()

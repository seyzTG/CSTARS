"""Клавиатуры бота: reply (главная) и inline (разделы, панель игр)."""

from app.keyboards.inline import (
    build_cashback_keyboard,
    build_checks_keyboard,
    build_crash_keyboard,
    build_crash_result_keyboard,
    build_custom_modes_keyboard,
    build_deposit_keyboard,
    build_game_panel,
    build_info_keyboard,
    build_menu_keyboard,
    build_modes_keyboard,
    build_privacy_keyboard,
    build_profile_keyboard,
    build_referral_keyboard,
    build_slots_submenu,
    build_stars_amount_keyboard,
    build_top_keyboard,
    build_withdraw_keyboard,
)
from app.keyboards.reply import main_keyboard, simple_cancel_keyboard

__all__ = [
    "main_keyboard",
    "simple_cancel_keyboard",
    "build_menu_keyboard",
    "build_profile_keyboard",
    "build_game_panel",
    "build_deposit_keyboard",
    "build_withdraw_keyboard",
    "build_cashback_keyboard",
    "build_privacy_keyboard",
    "build_top_keyboard",
    "build_checks_keyboard",
    "build_referral_keyboard",
    "build_info_keyboard",
    "build_modes_keyboard",
    "build_custom_modes_keyboard",
    "build_stars_amount_keyboard",
    "build_crash_keyboard",
    "build_crash_result_keyboard",
]

"""Тесты: регистрация, деньги, форматирование, приватность."""

from __future__ import annotations

import pytest

from app.utils.money import apply_multiplier, format_amount, parse_amount, to_minor


# ------------------------------- деньги ------------------------------------

def test_to_minor_and_format():
    assert to_minor(5) == 500
    assert to_minor("10.5") == 1050
    assert format_amount(500) == "5"
    assert format_amount(1050) == "10.5"
    assert format_amount(16840630) == "168406.3"


def test_parse_amount():
    assert parse_amount("5000") == 500000
    assert parse_amount("1,5") == 150
    assert parse_amount(" 10 ★ ") == 1000
    assert parse_amount("abc") is None
    assert parse_amount("-5") is None
    assert parse_amount("0") is None
    assert parse_amount("1.999") is None  # больше двух знаков после запятой


def test_coefficients_rounding():
    # ×1.8 от 100 ★ → 180 ★
    assert apply_multiplier(10000, 1.8) == 18000
    # ×5.4 от 10 ★ → 54 ★
    assert apply_multiplier(1000, 5.4) == 5400
    # дробные случаи округляются до минорных единиц
    assert apply_multiplier(1000, 2.7) == 2700


# ----------------------------- регистрация ---------------------------------

async def test_registration_creates_user_wallet_settings(session, make_user):
    from app.services import users as users_service

    user, created, inviter = await users_service.register(
        session, user_id=101, username="alice",
        first_name="Alice", last_name=None,
    )
    assert created is True
    assert inviter is None
    assert user.id == 101

    from app.models import UserSettings, Wallet

    assert await session.get(UserSettings, 101) is not None
    assert await session.get(Wallet, 101) is not None

    # повторный /start не создаёт второго пользователя
    again, created_again, _ = await users_service.register(
        session, user_id=101, username="alice",
        first_name="Alice", last_name=None,
    )
    assert created_again is False
    assert again.id == 101


async def test_registration_with_referral_and_self_invite_protection(session):
    from app.services import users as users_service

    inviter, _, _ = await users_service.register(
        session, user_id=1, username="inviter", first_name="I",
    )
    newcomer, created, inv_id = await users_service.register(
        session, user_id=2, username="guest", first_name="G",
        start_payload=inviter.referral_token,
    )
    assert created and inv_id == 1

    # самоприглашение запрещено
    _, _, self_inv = await users_service.register(
        session, user_id=1, username="inviter", first_name="I",
        start_payload=inviter.referral_token,
    )
    assert self_inv is None


# ----------------------------- приватность ---------------------------------

async def test_privacy_display(session, make_user):
    from app.models.enums import PrivacyMode
    from app.services import users as users_service

    user = await make_user(201, first_name="Oleg", username="oleg")
    profile = await users_service.load_profile(session, user)
    assert profile.public_name == "@oleg"

    await users_service.set_privacy(session, 201, PrivacyMode.ANONYMOUS)
    await session.refresh(user)
    profile = await users_service.load_profile(session, user)
    assert profile.public_name == "Аноним"

    await users_service.set_privacy(session, 201, PrivacyMode.NICKNAME)
    await users_service.set_nickname(session, 201, "Игрок")
    await session.refresh(user)
    profile = await users_service.load_profile(session, user)
    assert profile.public_name == "Игрок"


def test_nickname_validation():
    from app.services import users as users_service

    assert users_service.nickname_valid("ab")
    assert users_service.nickname_valid("x" * 32)
    assert not users_service.nickname_valid("a")
    assert not users_service.nickname_valid("x" * 33)

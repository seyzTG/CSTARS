"""Тесты: игровые режимы, коэффициенты, выигрыши/проигрыши, списание ставок."""

from __future__ import annotations

import pytest

from app.config.games import (
    DICE_COEFFICIENTS,
    GAMES,
    outcome_by_code,
    sum_ways,
    visible_outcomes,
)
from app.games.engine import RollResult, evaluate, resolve_outcome


# --------------------------- конфигурация игр ------------------------------

def test_all_game_modes_present():
    assert set(GAMES) == {"dice", "football", "basketball", "darts",
                          "bowling", "slots", "blackjack", "crash"}


def test_verified_coefficients_match_reference():
    """Коэффициенты, подтверждённые референсом."""
    assert DICE_COEFFICIENTS[1]["even"] == 1.8
    DICE_COEFFICIENTS[1]["odd"] == 1.8
    assert DICE_COEFFICIENTS[1]["number"] == 5.4

    darts = GAMES["darts"]
    assert darts.outcome("center").coef == 5.4
    assert darts.outcome("white").coef == 2.7
    assert darts.outcome("red").coef == 1.8
    assert darts.outcome("bounce").coef == 5.4

    football = GAMES["football"]
    assert football.outcome("goal").coef == 1.5
    assert football.outcome("miss").coef == 2.25
    assert football.outcome("post").coef == 4.5

    bowling = GAMES["bowling"]
    assert all(o.coef == 5.4 for o in bowling.outcomes if o.code != "pins_2")

    slots = GAMES["slots"]
    assert slots.outcome("sevens").coef == 57.6
    assert slots.outcome("any_combination").coef == 14.4


def test_dices_per_count_coefficients_independent():
    """Коэффициенты 2/3 кубов заданы отдельно, не копируются автоматически."""
    assert DICE_COEFFICIENTS[2]["number"] != DICE_COEFFICIENTS[1]["number"]
    assert DICE_COEFFICIENTS[3]["number"] != DICE_COEFFICIENTS[2]["number"]


def test_dice_submenu_coefficients_from_probability():
    """Тотал/Диапазон: коэффициент = (1/p) × модель выплат (≤ 1/p)."""
    total = 6 ** 3
    ways = sum_ways(3, 10)
    coef = outcome_by_code("dice", "total_10", 3).coef
    fair = total / ways
    assert coef <= fair
    assert abs(coef - fair * 0.95) < 0.02


def test_hidden_outcome_not_shown_but_exists():
    codes = [o.code for o in visible_outcomes("bowling")]
    assert "pins_2" not in codes          # кнопка отсутствует, как на референсе
    assert outcome_by_code("bowling", "pins_2") is not None


# ---------------------------- оценка бросков -------------------------------

def _roll(game: str, values: list[int], cls: str | None = None) -> RollResult:
    result = RollResult(game_code=game, values=values, classification=cls)
    code, label, void = resolve_outcome(GAMES[game], values, cls)
    result.outcome_code, result.outcome_label, result.is_void = code, label, void
    return result


def test_dice_single_parity_and_number():
    roll = _roll("dice", [4])
    assert evaluate("dice", "even", roll) is True
    assert evaluate("dice", "odd", roll) is False
    assert evaluate("dice", "number_4", roll) is True
    assert evaluate("dice", "number_5", roll) is False


def test_dice_multiple_sum():
    roll = _roll("dice", [6, 5])
    assert evaluate("dice", "2_even", roll) is False   # сумма 11 — нечётная
    assert evaluate("dice", "2_odd", roll) is True
    assert evaluate("dice", "number_6", roll) is True  # есть на одном кубике
    assert evaluate("dice", "total_11", roll) is True
    assert evaluate("dice", "range_8_12", roll) is True
    assert evaluate("dice", "range_2_6", roll) is False


def test_football_goal_classification():
    # 4 → гол, второй бросок классифицирует подвид
    roll = _roll("football", [4, 4], cls="center")
    assert roll.outcome_code == "goal_center"
    assert evaluate("football", "goal", roll) is True       # «Гол» выигрывает при любом голе
    assert evaluate("football", "goal_center", roll) is True
    assert evaluate("football", "goal_post", roll) is False
    assert evaluate("football", "miss", roll) is False


def test_football_miss_and_post():
    miss = _roll("football", [2])
    assert evaluate("football", "miss", miss) is True
    assert evaluate("football", "goal", miss) is False
    post = _roll("football", [3])
    assert evaluate("football", "post", post) is True


def test_darts_and_bowling_and_slots():
    # официальный 🎯: 6 — буллзе (центр), 1 — промах (отскок), 4/2 — белое, 3/5 — красное
    assert evaluate("darts", "center", _roll("darts", [6])) is True
    assert evaluate("darts", "white", _roll("darts", [2])) is True
    assert evaluate("darts", "red", _roll("darts", [3])) is True
    # «Красное» не выигрывает, если выпал другой сектор
    assert evaluate("darts", "red", _roll("darts", [2])) is False
    assert evaluate("darts", "red", _roll("darts", [1])) is False
    assert evaluate("bowling", "strike", _roll("bowling", [6])) is True
    assert evaluate("bowling", "miss", _roll("bowling", [1])) is True
    # официальный 🎰: 1 — три бара, 64 — три семёрки
    assert evaluate("slots", "sevens", _roll("slots", [64])) is True
    assert evaluate("slots", "bars", _roll("slots", [1])) is True
    assert evaluate("slots", "bars", _roll("slots", [64])) is False


def test_unmapped_value_returns_void():
    """Значение вне value_map → ничья (возврат), а не проигрыш."""
    # у дартса сопоставлены все значения 1..6, поэтому берём футбол (6 не задан)
    result = evaluate("football", "goal", _roll("football", [6]))
    assert result is None


# --------------------------- 21 Очко (blackjack) ----------------------------

def test_blackjack_hand_value_aces_and_faces():
    from app.games import blackjack as bj_mod

    assert bj_mod.hand_value(["A|S", "K|H"]) == 21          # натуральный
    assert bj_mod.hand_value(["A|S", "A|H", "9|C"]) == 21   # туз 11 + 10
    assert bj_mod.hand_value(["A|S", "A|H", "A|C", "A|D"]) == 14
    assert bj_mod.hand_value(["K|S", "Q|H"]) == 20          # фигуры = 10
    assert bj_mod.is_blackjack(["A|S", "K|H"])
    assert not bj_mod.is_blackjack(["A|S", "A|H", "9|C"])


def test_blackjack_deck_is_complete_and_shuffled():
    from app.games import blackjack as bj_mod

    deck = bj_mod.new_deck()
    assert len(deck) == 52
    assert len(set(deck)) == 52
    assert all(card.split("|")[0] in bj_mod.RANKS for card in deck)
    assert all(card.split("|")[1] in bj_mod.SUITS for card in deck)


def test_blackjack_dealer_stands_on_17():
    from app.games import blackjack as bj_mod

    deck = ["5|S", "6|D"]            # pop() берёт с конца: сначала 6|D
    dealer = ["4|S", "9|H"]          # 13 → добирает 6|D → 19, останов
    bj_mod.dealer_play(deck, dealer)
    assert bj_mod.hand_value(dealer) == 19
    assert len(dealer) == 3

    # мягкие 17 (туз как 11) — дилер тоже останавливается
    soft = ["A|S", "6|H"]
    bj_mod.dealer_play(["K|C", "K|D"], soft)
    assert bj_mod.hand_value(soft) == 17 and len(soft) == 2


def test_blackjack_decide_outcomes():
    from app.games import blackjack as bj_mod

    assert bj_mod.decide(["K|S", "Q|H"], ["A|C", "9|H"]) == "push"   # 20 против 20
    assert bj_mod.decide(["A|S", "K|H"], ["A|C", "Q|H"]) == "push"  # оба натуральных
    assert bj_mod.decide(["A|S", "K|H"], ["Q|S", "9|H"]) == "win"
    assert bj_mod.decide(["10|S", "9|H"], ["Q|S", "K|H"]) == "lose"
    assert bj_mod.decide(["10|S", "9|H", "5|D"], ["Q|S", "K|H"]) == "lose"  # 24
    assert bj_mod.decide(["10|S", "9|H"], ["Q|S", "K|H", "8|D"]) == "win"   # 29 у дилера


def test_blackjack_evaluate_round_result():
    win = RollResult(game_code="blackjack", outcome_code="win")
    push = RollResult(game_code="blackjack", outcome_code="push")
    lose = RollResult(game_code="blackjack", outcome_code="lose")
    assert evaluate("blackjack", "play", win) is True
    assert evaluate("blackjack", "play", push) is None      # ничья → возврат
    assert evaluate("blackjack", "play", lose) is False


async def test_blackjack_settlement_win_push(session, make_user):
    """21 Очко: победа ×2, ничья — возврат ставки."""
    from app.models import Wallet
    from app.services import settlement

    user = await make_user(304)
    wallet = await session.get(Wallet, 304)
    wallet.real_balance = 1000  # 10 ★

    assert settlement.validate_bet(
        stake_minor=500, outcome_code="play", game_code="blackjack").ok

    round_id, bonus, real, dup = await settlement.start_round(
        session, user_id=304, game_code="blackjack", outcome_code="play",
        outcome_label="21 Очко", coefficient=2.0,
        stake_minor=500, action_id="bj1",
    )
    assert dup is None and bonus == 0 and real == 500

    win_roll = RollResult(game_code="blackjack", values=[21, 20],
                          outcome_code="win", outcome_label="Победа")
    result = await settlement.finish_round(
        session, user_id=304, round_id=round_id, game_code="blackjack",
        outcome_code="play", outcome_label="21 Очко", coefficient=2.0,
        stake_minor=500, bonus_spent=0, roll=win_roll, action_id="bj1",
    )
    assert result.won is True and result.payout_minor == 1000  # ставка ×2
    await session.refresh(wallet)
    assert wallet.real_balance == 1000 - 500 + 1000

    # ничья: полная возврат ставки
    round_id2, _, _, _ = await settlement.start_round(
        session, user_id=304, game_code="blackjack", outcome_code="play",
        outcome_label="21 Очко", coefficient=2.0,
        stake_minor=500, action_id="bj2",
    )
    push_roll = RollResult(game_code="blackjack", values=[20, 20],
                           outcome_code="push", outcome_label="Ничья")
    result2 = await settlement.finish_round(
        session, user_id=304, round_id=round_id2, game_code="blackjack",
        outcome_code="play", outcome_label="21 Очко", coefficient=2.0,
        stake_minor=500, bonus_spent=0, roll=push_roll, action_id="bj2",
    )
    assert result2.won is None
    await session.refresh(wallet)
    assert wallet.real_balance == 1500 - 500 + 500


# ----------------------- списание ставок и расчёт --------------------------

async def test_bet_round_win_loss_and_stats(session, make_user):
    from app.models import Wallet
    from app.services import settlement

    user = await make_user(301)
    wallet = await session.get(Wallet, 301)
    wallet.real_balance = 10000  # 100 ★

    validation = settlement.validate_bet(
        stake_minor=500, outcome_code="red", game_code="darts")
    assert validation.ok

    # проигрыш: ставка списана
    round_id, bonus, real, dup = await settlement.start_round(
        session, user_id=301, game_code="darts", outcome_code="red",
        outcome_label="Красное (×1.8)", coefficient=1.8,
        stake_minor=500, action_id="act1",
    )
    assert dup is None and bonus == 0 and real == 500
    await session.refresh(wallet)
    assert wallet.real_balance == 9500

    loss_roll = RollResult(game_code="darts", values=[2], outcome_code="white")
    result = await settlement.finish_round(
        session, user_id=301, round_id=round_id, game_code="darts",
        outcome_code="red", outcome_label="Красное (×1.8)", coefficient=1.8,
        stake_minor=500, bonus_spent=0, roll=loss_roll, action_id="act1",
    )
    assert result.won is False and result.payout_minor == 0
    await session.refresh(wallet)
    assert wallet.real_balance == 9500
    assert wallet.turnover == 500 and wallet.games_played == 1

    # выигрыш: начисление ставка × коэффициент
    round_id2, _, _, _ = await settlement.start_round(
        session, user_id=301, game_code="darts", outcome_code="center",
        outcome_label="В центр (×5.4)", coefficient=5.4,
        stake_minor=1000, action_id="act2",
    )
    win_roll = RollResult(game_code="darts", values=[4], outcome_code="center")
    result2 = await settlement.finish_round(
        session, user_id=301, round_id=round_id2, game_code="darts",
        outcome_code="center", outcome_label="В центр (×5.4)", coefficient=5.4,
        stake_minor=1000, bonus_spent=0, roll=win_roll, action_id="act2",
    )
    assert result2.won is True
    assert result2.payout_minor == 5400   # 10 ★ × 5.4 = 54 ★
    await session.refresh(wallet)
    assert wallet.real_balance == 9500 - 1000 + 5400


async def test_duplicate_action_does_not_double_spend(session, make_user):
    from app.models import Wallet
    from app.services import settlement

    await make_user(302)
    wallet = await session.get(Wallet, 302)
    wallet.real_balance = 1000  # 10 ★

    _, _, _, _ = await settlement.start_round(
        session, user_id=302, game_code="darts", outcome_code="red",
        outcome_label="Красное", coefficient=1.8,
        stake_minor=500, action_id="same-action",
    )
    _, _, _, duplicate = await settlement.start_round(
        session, user_id=302, game_code="darts", outcome_code="red",
        outcome_label="Красное", coefficient=1.8,
        stake_minor=500, action_id="same-action",
    )
    assert duplicate is not None and duplicate.duplicate is True
    await session.refresh(wallet)
    assert wallet.real_balance == 500   # ставка списана один раз


async def test_bet_validation_limits(session):
    from app.services import settlement

    assert not settlement.validate_bet(
        stake_minor=0, outcome_code="red", game_code="darts").ok
    assert not settlement.validate_bet(
        stake_minor=1_000_000_00, outcome_code="red",
        game_code="darts").ok            # больше 5000 ★
    assert not settlement.validate_bet(
        stake_minor=500, outcome_code="nope", game_code="darts").ok


async def test_insufficient_funds(session, make_user):
    from app.finance import InsufficientFunds
    from app.services import settlement

    await make_user(303)
    with pytest.raises(InsufficientFunds):
        await settlement.start_round(
            session, user_id=303, game_code="darts", outcome_code="red",
            outcome_label="Красное", coefficient=1.8,
            stake_minor=500, action_id="broke",
        )

"""Общая конфигурация pytest: SQLite-база в памяти для каждого теста."""

from __future__ import annotations

import asyncio
import os
import sys

import pytest
import pytest_asyncio

# настройки окружения ДО импорта моделей приложения
os.environ.setdefault("BOT_TOKEN", "0:TEST-TOKEN")
os.environ.setdefault("BOT_USERNAME", "test_bot")
os.environ.setdefault("ENV", "dev")
os.environ.setdefault("ADMIN_IDS", "1")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///:memory:")
os.environ.setdefault("USE_REDIS", "false")
os.environ.setdefault("AUTO_CREATE_TABLES", "false")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest_asyncio.fixture
async def engine():
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from app.database.base import Base
    import app.models  # noqa: F401

    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def session(engine):
    from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

    factory = async_sessionmaker(engine, class_=AsyncSession,
                                 expire_on_commit=False, autoflush=False)
    async with factory() as session:
        yield session
        await session.rollback()


@pytest.fixture
def make_user(session):
    """Фабрика пользователей с кошельком для тестов."""

    async def _factory(user_id: int, **kwargs):
        from app.models import User, UserSettings, Wallet

        user = User(
            id=user_id,
            username=kwargs.get("username", f"user{user_id}"),
            first_name=kwargs.get("first_name", "Test"),
            referral_token=kwargs.get("token", f"token{user_id}"),
            **{k: v for k, v in kwargs.items()
               if k in {"referred_by_id", "privacy_mode", "is_blocked"}},
        )
        session.add(user)
        session.add(UserSettings(user_id=user_id))
        session.add(Wallet(user_id=user_id))
        await session.flush()
        return user

    return _factory

"""Тесты: главное меню, навигация и клавиатуры всех разделов."""

from __future__ import annotations

from app.config import texts
from app.keyboards.inline import (
    build_cashback_keyboard,
    build_checks_keyboard,
    build_deposit_keyboard,
    build_game_panel,
    build_menu_keyboard,
    build_modes_keyboard,
    build_privacy_keyboard,
    build_profile_keyboard,
    build_referral_keyboard,
    build_top_keyboard,
    build_withdraw_keyboard,
)
from app.keyboards.reply import main_keyboard


def test_main_reply_keyboard_layout():
    """Клавиатура: Играть / Профиль+Баланс / Меню — как на референсе."""
    keyboard = main_keyboard()
    rows = [[button.text for button in row] for row in keyboard.keyboard]
    assert rows[0] == [texts.KB_PLAY]
    assert rows[1] == [texts.KB_PROFILE, texts.KB_BALANCE]
    assert rows[2] == [texts.KB_MENU]


def test_menu_section_buttons():
    data = [btn.callback_data for row in build_menu_keyboard().inline_keyboard
            for btn in row]
    assert "nav:referral" in data
    assert "nav:daily" in data
    assert "nav:checks" in data
    assert "top:all" in data
    assert "nav:info" in data


def test_profile_buttons():
    data = [btn.callback_data for row in build_profile_keyboard().inline_keyboard
            for btn in row]
    assert data[:2] == ["nav:deposit", "nav:withdraw"]
    assert "nav:cashback" in data and "nav:privacy" in data


def test_game_panel_has_all_tabs_and_outcomes():
    markup = build_game_panel(game_code="dice", bet_major="1",
                              balance_major="10", dice_count=1)
    data = [btn.callback_data for row in markup.inline_keyboard for btn in row]
    for code in ("dice", "football", "basketball", "darts", "bowling",
                 "slots", "blackjack", "crash"):
        assert f"game:tab:{code}" in data
    assert "game:count:1" in data and "game:count:3" in data
    assert "game:sub:total" in data and "game:sub:range" in data
    assert "game:bet:even" in data and "game:bet:odd" in data
    assert "game:bet:number_6" in data
    assert "game:edit" in data and "nav:modes" in data
    assert "nav:custom" not in data   # кнопка «Авторские» убрана


def test_game_panel_crash_has_launch_button():
    """Вкладка Crash: кнопка запуска вместо кнопок исходов."""
    markup = build_game_panel(game_code="crash", bet_major="1",
                              balance_major="10")
    data = [btn.callback_data for row in markup.inline_keyboard for btn in row]
    assert "game:crash:start" in data
    assert not any(d.startswith("game:bet") for d in data)  # без кнопок исходов
    assert "game:edit" in data              # ставку можно изменить
    assert "game:tab:crash" in data         # вкладка доступна


def test_crash_keyboards():
    from app.keyboards.inline import (
        build_crash_keyboard,
        build_crash_result_keyboard,
    )

    take = [btn.callback_data for row in build_crash_keyboard(7).inline_keyboard
            for btn in row]
    assert take == ["crash:take:7"]

    result = [btn.callback_data
              for row in build_crash_result_keyboard().inline_keyboard
              for btn in row]
    assert "game:crash:start" in result and "game:panel" in result


def test_game_panel_blackjack_has_deal_button():
    """Вкладка 21 Очко: кнопка раздачи вместо кнопок исходов."""
    markup = build_game_panel(game_code="blackjack", bet_major="1",
                              balance_major="10")
    data = [btn.callback_data for row in markup.inline_keyboard for btn in row]
    assert "game:bj:start" in data
    assert not any(d.startswith("game:bet") for d in data)  # без кнопок исходов
    assert "game:tab:dice" in data          # вкладки соседних игр доступны
    assert "game:edit" in data              # ставку можно изменить


def test_game_panel_football_outcomes():
    markup = build_game_panel(game_code="football", bet_major="1",
                              balance_major="10")
    labels = [btn.text for row in markup.inline_keyboard for btn in row]
    for expected in ("Гол", "Промах", "Гол в центр", "Гол от штанги",
                     "Гол в угол", "Штанга"):
        assert any(expected in label for label in labels), expected


def test_deposit_and_withdraw_menus():
    dep = [btn.callback_data for row in build_deposit_keyboard().inline_keyboard
           for btn in row]
    assert dep[0] == "pay:dep:stars"
    assert "pay:dep:cryptobot" in dep and "pay:dep:xrocket" in dep
    assert "pay:dep:crypto" in dep and "pay:dep:gifts" in dep
    assert dep[-1] == "nav:profile"

    wd = [btn.callback_data for row in build_withdraw_keyboard().inline_keyboard
          for btn in row]
    assert "pay:wd:stars" in wd
    assert "pay:wd:gifts" not in wd   # подарки нельзя вывести


def test_top_periods_and_back():
    markup = build_top_keyboard("week")
    data = [btn.callback_data for row in markup.inline_keyboard for btn in row]
    for period in ("all", "today", "yesterday", "week", "month"):
        assert f"top:{period}" in data
    assert "nav:menu" in data


def test_checks_referral_cashback_modes():
    checks = [btn.callback_data for row in build_checks_keyboard().inline_keyboard
              for btn in row]
    assert "check:types" in checks and "check:list" in checks

    ref = [btn.text for row in build_referral_keyboard("https://t.me/x?start=y").inline_keyboard
           for btn in row]
    assert texts.REF_SEND in ref and texts.REF_COPY in ref

    cash = [btn.callback_data for row in build_cashback_keyboard(available=True).inline_keyboard
            for btn in row]
    assert "cb:claim" in cash and "cb:details" in cash

    modes = [btn.callback_data for row in build_modes_keyboard("dice").inline_keyboard
             for btn in row]
    assert "modes:history" in modes
    for code in ("dice", "football", "basketball", "darts", "bowling",
                 "slots", "blackjack"):
        assert f"game:select:{code}" in modes


def test_privacy_buttons_and_back():
    # пустой режим: все кнопки без выделения
    markup = build_privacy_keyboard("")
    labels = [btn.text for row in markup.inline_keyboard for btn in row]
    assert texts.BTN_ANONYMITY in labels
    assert texts.BTN_NAME_TG in labels
    assert texts.BTN_NICKNAME in labels
    assert texts.BTN_CHANGE_NICKNAME in labels
    assert texts.KB_BACK in labels

    # выбранный режим подсвечен скобками
    selected = build_privacy_keyboard("tg_name")
    selected_labels = [btn.text for row in selected.inline_keyboard for btn in row]
    assert f"[{texts.BTN_NAME_TG}]" in selected_labels


def test_navigation_targets_are_known():
    from app.handlers.menu import SECTIONS

    # каждая кнопка «Назад» должна вести в существующий раздел
    targets = {
        "menu", "profile", "deposit", "withdraw", "checks",
        "check:types", "referral", "cashback", "info", "game",
    }
    assert targets <= set(SECTIONS)

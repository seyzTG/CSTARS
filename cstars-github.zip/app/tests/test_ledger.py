"""Тесты: атомарность журнала, двойное списание, идемпотентность платежей."""

from __future__ import annotations

import pytest

from app.finance import InsufficientFunds, credit, debit, debit_split, get_balances
from app.models import Transaction, WebhookEvent
from app.models.enums import TransactionType, WalletKind


async def test_credit_and_debit(session, make_user):
    await make_user(401)
    await credit(session, user_id=401, amount_minor=10000,
                 kind=TransactionType.DEPOSIT, key="dep1")
    real, bonus = await get_balances(session, 401)
    assert real == 10000 and bonus == 0

    await debit(session, user_id=401, amount_minor=2500,
                kind=TransactionType.BET, key="bet1")
    real, _ = await get_balances(session, 401)
    assert real == 7500

    # журнал содержит обе операции с суммами и балансом после операции
    rows = (await session.execute(
        __import__("sqlalchemy").select(Transaction)
        .where(Transaction.user_id == 401).order_by(Transaction.created_at)
    )).scalars().all()
    assert len(rows) == 2
    assert rows[0].amount == 10000 and rows[0].balance_after == 10000
    assert rows[1].amount == -2500 and rows[1].balance_after == 7500


async def test_no_negative_balance(session, make_user):
    await make_user(402)
    await credit(session, user_id=402, amount_minor=500,
                 kind=TransactionType.DEPOSIT, key="small")
    with pytest.raises(InsufficientFunds):
        await debit(session, user_id=402, amount_minor=1000,
                    kind=TransactionType.BET, key="toobig")
    real, _ = await get_balances(session, 402)
    assert real == 500   # баланс не изменился


async def test_idempotent_credit(session, make_user):
    """Повторное уведомление провайдера не зачисляет деньги дважды."""
    await make_user(403)
    first = await credit(session, user_id=403, amount_minor=5000,
                         kind=TransactionType.DEPOSIT, key="same-payment")
    second = await credit(session, user_id=403, amount_minor=5000,
                          kind=TransactionType.DEPOSIT, key="same-payment")
    assert first.applied is True
    assert second.applied is False
    real, _ = await get_balances(session, 403)
    assert real == 5000
    count = (await session.execute(
        __import__("sqlalchemy").select(Transaction)
        .where(Transaction.idempotency_key == "same-payment")
    )).scalars().all()
    assert len(count) == 1


async def test_debit_split_prefers_bonus(session, make_user):
    await make_user(404)
    await credit(session, user_id=404, amount_minor=300,
                 kind=TransactionType.BONUS, wallet_kind=WalletKind.BONUS,
                 key="b1")
    await credit(session, user_id=404, amount_minor=1000,
                 kind=TransactionType.DEPOSIT, key="r1")

    result = await debit_split(session, user_id=404, amount_minor=500,
                               kind=TransactionType.BET, key="stake1")
    assert result.bonus_spent == 300
    assert result.real_spent == 200
    real, bonus = await get_balances(session, 404)
    assert bonus == 0 and real == 800

    # повтор не списывает снова
    again = await debit_split(session, user_id=404, amount_minor=500,
                              kind=TransactionType.BET, key="stake1")
    assert again.applied is False
    real, bonus = await get_balances(session, 404)
    assert bonus == 0 and real == 800


async def test_concurrent_debits_do_not_overdraw(tmp_path):
    """Параллельные списания не уводят баланс в минус (условие в UPDATE).

    Для настоящей гонки используется отдельный ФАЙЛОВЫЙ SQLite с NullPool:
    у каждой сессии своё соединение, блокировки идут на уровне БД,
    как в PostgreSQL.
    """
    import asyncio

    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
    from sqlalchemy.pool import NullPool

    from app.database.base import Base
    import app.models  # noqa: F401
    from app.models import User, UserSettings, Wallet

    db_path = tmp_path / "concurrent.db"
    engine = create_async_engine(
        f"sqlite+aiosqlite:///{db_path}", poolclass=NullPool
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    factory = async_sessionmaker(engine, expire_on_commit=False, autoflush=False)

    try:
        async with factory() as setup:
            setup.add(User(id=405, username="c", first_name="C",
                           referral_token="c405"))
            setup.add(UserSettings(user_id=405))
            setup.add(Wallet(user_id=405, real_balance=1000))
            await setup.commit()

        async def spend(index: int) -> bool:
            async with factory() as s:
                try:
                    await debit(s, user_id=405, amount_minor=400,
                                kind=TransactionType.BET, key=f"c{index}")
                    await s.commit()
                    return True
                except InsufficientFunds:
                    await s.rollback()
                    return False
                except Exception:  # noqa: BLE001 — блокировки SQLite
                    await s.rollback()
                    return False

        results = await asyncio.gather(*[spend(i) for i in range(6)])
        assert sum(results) == 2   # лишь два списания по 400 из 1000

        async with factory() as check:
            real, _ = await get_balances(check, 405)
            assert real == 200
    finally:
        await engine.dispose()


async def test_duplicate_payment_webhook(session, make_user):
    """Повторная доставка события провайдера обрабатывается один раз."""
    await make_user(406)
    event = WebhookEvent(provider="cryptobot", external_id="inv42",
                         event_type="invoice_paid", status="processed")
    session.add(event)
    await session.flush()

    duplicate = WebhookEvent(provider="cryptobot", external_id="inv42",
                             event_type="invoice_paid", status="processed")
    session.add(duplicate)
    with pytest.raises(Exception):
        await session.flush()
    await session.rollback()

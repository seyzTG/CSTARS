"""Тесты: Crash — модель полёта, расчёт выигрыша/проигрыша, восстановление."""

from __future__ import annotations

import time
from decimal import Decimal

from app.config.crash import CrashConfig, get_crash_config
from app.games.crash import format_multiplier, next_tick, plan_crash
from app.games.engine import RollResult
from app.models import GameRound, User, Wallet
from app.models.enums import RoundStatus
from app.services import settlement
from app.utils.money import apply_multiplier, to_minor


def _config(**overrides) -> CrashConfig:
    base = dict(
        min_multiplier=1.15,
        max_multiplier=500.0,
        house_edge=0.03,
        flight_min_seconds=8.0,
        flight_max_seconds=40.0,
        tick_min_seconds=1.5,
        tick_max_seconds=2.0,
    )
    base.update(overrides)
    return CrashConfig(**base)


# ------------------------------ модель полёта -------------------------------

def test_crash_plan_bounds():
    config = get_crash_config()
    for _ in range(200):
        plan = plan_crash(config)
        assert plan.start_multiplier >= 1
        assert plan.crash_multiplier >= plan.start_multiplier
        assert plan.crash_multiplier <= Decimal(str(config.max_multiplier))
        assert plan.flight_seconds >= config.flight_min_seconds
        assert plan.flight_seconds <= config.flight_max_seconds


def test_crash_multiplier_growth_and_cap():
    config = _config(min_multiplier=1.15, max_multiplier=10.0,
                     flight_min_seconds=10.0, flight_max_seconds=10.0)
    plan = plan_crash(config)

    previous = plan.multiplier_at(0)
    assert previous == plan.start_multiplier
    for step in range(1, 21):
        current = plan.multiplier_at(step * 0.5)
        assert current >= previous
        assert current <= plan.crash_multiplier
        previous = current

    # в момент полёта множитель достигает точки взрыва и не превышает её
    assert plan.multiplier_at(plan.flight_seconds) == plan.crash_multiplier
    assert plan.is_crash(plan.crash_multiplier)


def test_crash_tick_interval():
    config = _config(tick_min_seconds=1.5, tick_max_seconds=2.0)
    for _ in range(100):
        assert 1.5 <= next_tick(config) <= 2.0


def test_crash_format_multiplier():
    assert format_multiplier(Decimal("1.15")) == "1.15"
    assert format_multiplier(Decimal("2.10")) == "2.10"
    assert format_multiplier(Decimal("10")) == "10.00"


# ------------------------------ расчёты ставки ------------------------------

async def test_crash_cashout_payout(session, make_user):
    """«Забрать»: выигрыш = ставка × показанный множитель."""
    await make_user(601)
    wallet = await session.get(Wallet, 601)
    wallet.real_balance = to_minor(100)

    round_id, bonus, real, duplicate = await settlement.start_round(
        session, user_id=601, game_code="crash", outcome_code="cashout",
        outcome_label="Crash", coefficient=None, stake_minor=to_minor(10),
        action_id="crash-win-1",
    )
    assert duplicate is None and bonus == 0 and real == to_minor(10)

    roll = RollResult(game_code="crash", outcome_code="cashout",
                      outcome_label="Забрать")
    result = await settlement.finish_round(
        session, user_id=601, round_id=round_id, game_code="crash",
        outcome_code="cashout", outcome_label="Crash", coefficient=1.35,
        stake_minor=to_minor(10), bonus_spent=0, roll=roll,
        action_id="crash-win-1",
    )
    assert result.won is True
    assert result.payout_minor == apply_multiplier(to_minor(10), 1.35)

    await session.refresh(wallet)
    assert wallet.real_balance == to_minor(100) - to_minor(10) + result.payout_minor

    round_ = await session.get(GameRound, round_id)
    assert round_.status == RoundStatus.WON.value
    assert round_.multiplier == 1.35


async def test_crash_explosion_burns_stake(session, make_user):
    """Взрыв: ставка сгорает, выплаты нет."""
    await make_user(602)
    wallet = await session.get(Wallet, 602)
    wallet.real_balance = to_minor(100)

    round_id, _, _, _ = await settlement.start_round(
        session, user_id=602, game_code="crash", outcome_code="cashout",
        outcome_label="Crash", coefficient=None, stake_minor=to_minor(10),
        action_id="crash-loss-1",
    )

    roll = RollResult(game_code="crash", outcome_code="crash",
                      outcome_label="Взрыв")
    result = await settlement.finish_round(
        session, user_id=602, round_id=round_id, game_code="crash",
        outcome_code="cashout", outcome_label="Crash", coefficient=1.65,
        stake_minor=to_minor(10), bonus_spent=0, roll=roll,
        action_id="crash-loss-1",
    )
    assert result.won is False and result.payout_minor == 0

    await session.refresh(wallet)
    assert wallet.real_balance == to_minor(90)

    round_ = await session.get(GameRound, round_id)
    assert round_.status == RoundStatus.LOST.value
    assert round_.multiplier == 1.65


async def test_recover_pending_crash_round(session, make_user, monkeypatch):
    """После перезапуска бота зависший полёт закрывается возвратом ставки."""
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

    import app.handlers.crash as crash_module

    engine = session.bind
    factory = async_sessionmaker(engine, class_=AsyncSession,
                                 expire_on_commit=False, autoflush=False)
    monkeypatch.setattr(crash_module, "get_session_factory", lambda: factory)

    await make_user(603)
    wallet = await session.get(Wallet, 603)
    wallet.real_balance = to_minor(50)

    round_id, bonus, real, _ = await settlement.start_round(
        session, user_id=603, game_code="crash", outcome_code="cashout",
        outcome_label="Crash", coefficient=None, stake_minor=to_minor(7),
        action_id="crash-pending-1",
    )
    assert real == to_minor(7)
    await session.commit()

    recovered = await crash_module.recover_pending_rounds()
    assert recovered >= 1

    await session.refresh(wallet)
    assert wallet.real_balance == to_minor(50)   # ставка вернулась

    round_ = await session.get(GameRound, round_id)
    assert round_.status == RoundStatus.VOID.value


# --------------------------- фоновый полёт и «Забрать» ------------------------

class _FakeBot:
    """Минимальная заглушка Bot: редактирует сообщения полёта."""

    def __init__(self) -> None:
        self.edits: list[str] = []

    async def edit_message_text(self, text, *, chat_id=None, message_id=None,
                                entities=None, reply_markup=None):
        self.edits.append(text)
        return None


class _FakeQuery:
    def __init__(self, data: str, user_id: int, bot) -> None:
        self.data = data
        self.bot = bot
        self.from_user = type("U", (), {"id": user_id})()
        self.answers: list[tuple[str | None, bool]] = []

    async def answer(self, text=None, *, alert: bool = False,
                     show_alert: bool = False) -> None:
        self.answers.append((text, show_alert))


async def test_crash_flight_explodes_and_burns(session, make_user, monkeypatch):
    """Фоновый таск доводит полёт до взрыва и списывает ставку."""
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

    import app.handlers.crash as crash_module

    engine = session.bind
    factory = async_sessionmaker(engine, class_=AsyncSession,
                                 expire_on_commit=False, autoflush=False)
    monkeypatch.setattr(crash_module, "get_session_factory", lambda: factory)
    monkeypatch.setattr(crash_module, "get_crash_config", lambda: _config(
        tick_min_seconds=0.05, tick_max_seconds=0.05,
        flight_min_seconds=1.0, flight_max_seconds=1.0))

    await make_user(604)
    wallet = await session.get(Wallet, 604)
    wallet.real_balance = to_minor(100)

    round_id, _, _, _ = await settlement.start_round(
        session, user_id=604, game_code="crash", outcome_code="cashout",
        outcome_label="Crash", coefficient=None, stake_minor=to_minor(10),
        action_id="crash-flight-1",
    )
    await session.commit()

    plan = crash_module.CrashPlan(
        crash_multiplier=Decimal("1.15"), flight_seconds=1.0,
        start_multiplier=Decimal("1.15"),
    )
    run = crash_module.CrashRun(
        user_id=604, chat_id=1, round_id=round_id, stake_minor=to_minor(10),
        bonus_spent=0, action_id="crash-flight-1", plan=plan,
        started_at=time.monotonic(), message_id=1,
        displayed_multiplier=Decimal("1.15"),
        displayed_amount_minor=apply_multiplier(to_minor(10), 1.15),
    )

    bot = _FakeBot()
    await crash_module._flight(run, bot)

    assert run.finished is True and run.cashed_out is False
    assert any("взорвалась" in text for text in bot.edits)

    await session.refresh(wallet)
    assert wallet.real_balance == to_minor(90)
    round_ = await session.get(GameRound, round_id)
    assert round_.status == RoundStatus.LOST.value


async def test_crash_take_cashes_out_displayed_multiplier(
    session, make_user, monkeypatch
):
    """«Забрать» начисляет ставку × последний показанный множитель."""
    import app.handlers.crash as crash_module

    await make_user(605)
    wallet = await session.get(Wallet, 605)
    wallet.real_balance = to_minor(100)

    round_id, _, _, _ = await settlement.start_round(
        session, user_id=605, game_code="crash", outcome_code="cashout",
        outcome_label="Crash", coefficient=None, stake_minor=to_minor(10),
        action_id="crash-take-1",
    )

    plan = crash_module.CrashPlan(
        crash_multiplier=Decimal("3.00"), flight_seconds=30.0,
        start_multiplier=Decimal("1.15"),
    )
    run = crash_module.CrashRun(
        user_id=605, chat_id=1, round_id=round_id, stake_minor=to_minor(10),
        bonus_spent=0, action_id="crash-take-1", plan=plan,
        started_at=time.monotonic(), message_id=1,
        displayed_multiplier=Decimal("1.35"),
        displayed_amount_minor=apply_multiplier(to_minor(10), 1.35),
    )
    crash_module.RUNS[round_id] = run

    bot = _FakeBot()
    query = _FakeQuery(f"crash:take:{round_id}", 605, bot)
    user = await session.get(User, 605)

    await crash_module.on_crash_take(query, session, user)
    await session.commit()

    assert run.finished is True and run.cashed_out is True
    assert any("Вы забрали" in text for text in bot.edits)
    assert query.answers and query.answers[-1][0] is None

    await session.refresh(wallet)
    assert wallet.real_balance == to_minor(100) - to_minor(10) + to_minor(13.5)
    round_ = await session.get(GameRound, round_id)
    assert round_.status == RoundStatus.WON.value
    assert round_.multiplier == 1.35

    crash_module.RUNS.pop(round_id, None)


async def test_crash_start_launches_flight(session, make_user, monkeypatch):
    """Запуск списывает ставку и поднимает фоновый полёт до взрыва."""
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

    import app.handlers.crash as crash_module

    engine = session.bind
    factory = async_sessionmaker(engine, class_=AsyncSession,
                                 expire_on_commit=False, autoflush=False)
    monkeypatch.setattr(crash_module, "get_session_factory", lambda: factory)
    monkeypatch.setattr(crash_module, "get_crash_config", lambda: _config(
        tick_min_seconds=0.05, tick_max_seconds=0.05,
        flight_min_seconds=0.2, flight_max_seconds=0.2))

    await make_user(606)
    wallet = await session.get(Wallet, 606)
    wallet.real_balance = to_minor(100)

    bot = _FakeBot()
    message = type("M", (), {})()
    message.chat = type("C", (), {"id": 1})()
    message.bot = bot
    message.sent: list = []

    async def _answer(text, entities=None, reply_markup=None):
        message.sent.append(text)
        return type("Sent", (), {"message_id": 1})()

    message.answer = _answer
    query = _FakeQuery("game:crash:start", 606, bot)
    query.message = message
    state = type("S", (), {"data": {"bet_minor": to_minor(5)}})()

    async def _get_data():
        return dict(state.data)

    async def _update_data(**kwargs):
        state.data.update(kwargs)

    state.get_data = _get_data
    state.update_data = _update_data

    user = await session.get(User, 606)
    await crash_module.on_crash_start(query, session, user, state)
    await session.commit()   # в бою это делает middleware после обработчика

    run = next(iter(crash_module.RUNS.values()))
    await run.task

    assert run.finished is True
    assert message.sent, "сообщение полёта должно отправиться"
    assert any("взорвалась" in text for text in bot.edits)

    await session.refresh(wallet)
    assert wallet.real_balance == to_minor(95)   # ставка 5 ★ сгорела

    crash_module.RUNS.pop(run.round_id, None)

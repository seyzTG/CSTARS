"""Тесты: вывод средств, платежи (идемпотентность) и права администратора."""

from __future__ import annotations

import pytest

from app.finance import credit, get_balances
from app.models import Transaction, Wallet, Withdrawal
from app.models.enums import TransactionType, WithdrawalStatus
from app.services import admin as admin_service
from app.services import withdrawals as wd_service
from app.utils.money import to_minor


# -------------------------------- вывод ------------------------------------

async def test_withdraw_request_and_status(session, make_user):
    await make_user(601)
    await credit(session, user_id=601, amount_minor=to_minor(100),
                 kind=TransactionType.DEPOSIT, key="dep")

    result = await wd_service.request_withdrawal(
        session, user_id=601, amount_minor=to_minor(40),
        method="stars")
    assert result.ok
    item = result.withdrawal
    assert item.status == WithdrawalStatus.PENDING.value
    assert item.commission_minor == 0
    assert item.payout_minor == to_minor(40)

    # сумма зарезервирована и не выводится повторно
    real, _ = await get_balances(session, 601)
    assert real == to_minor(60)

    again = await wd_service.request_withdrawal(
        session, user_id=601, amount_minor=to_minor(100), method="stars")
    assert not again.ok and again.error_key == "WD_NO_FUNDS"


async def test_withdraw_limits(session, make_user):
    await make_user(602)
    await credit(session, user_id=602, amount_minor=to_minor(1000),
                 kind=TransactionType.DEPOSIT, key="dep2")

    small = await wd_service.request_withdrawal(
        session, user_id=602, amount_minor=to_minor(0.5), method="stars")
    assert not small.ok

    big = await wd_service.request_withdrawal(
        session, user_id=602, amount_minor=to_minor(100_001), method="stars")
    assert not big.ok

    bad_method = await wd_service.request_withdrawal(
        session, user_id=602, amount_minor=to_minor(10), method="gifts")
    assert not bad_method.ok


async def test_withdraw_approve_and_reject(session, make_user):
    await make_user(603)
    await credit(session, user_id=603, amount_minor=to_minor(80),
                 kind=TransactionType.DEPOSIT, key="dep3")

    created = await wd_service.request_withdrawal(
        session, user_id=603, amount_minor=to_minor(50), method="stars")
    wid = created.withdrawal.id

    # подтверждение: статус «Выполнено» только после реальной выплаты
    approved = await wd_service.approve(session, wid=wid, admin_id=1)
    assert approved.ok
    assert approved.withdrawal.status == WithdrawalStatus.PAID.value
    wallet = await session.get(Wallet, 603)
    assert wallet.withdrawn_total == to_minor(50)

    # повторное решение невозможно
    twice = await wd_service.approve(session, wid=wid, admin_id=1)
    assert not twice.ok

    # отклонение возвращает средства
    created2 = await wd_service.request_withdrawal(
        session, user_id=603, amount_minor=to_minor(10), method="stars")
    rejected = await wd_service.reject(
        session, wid=created2.withdrawal.id, admin_id=1, comment="тест")
    assert rejected.ok
    assert rejected.withdrawal.status == WithdrawalStatus.REJECTED.value
    real, _ = await get_balances(session, 603)
    # 80 внесено, 50 выплачено по подтверждённой заявке,
    # 10 по отклонённой — списаны и возвращены (в итоге не меняют баланс)
    assert real == to_minor(80) - to_minor(50)


# ------------------------------- платежи -----------------------------------

async def test_stars_provider_not_fake(session, make_user):
    """Адаптер Stars подтверждает платёж только через charge_id."""
    from app.payments import get_provider
    from app.payments.base import PaymentRequest

    provider = get_provider("stars")
    assert provider is not None and provider.configured

    invoice = await provider.create_invoice(
        PaymentRequest(user_id=1, amount_minor=to_minor(10), payload="p"))
    assert invoice.ok
    assert invoice.telegram_invoice["currency"] == "XTR"
    assert invoice.telegram_invoice["prices"][0]["amount"] == 10

    ok = await provider.verify("p", "charge-1")
    assert ok.ok and ok.external_id == "charge-1"
    missing = await provider.verify("p", "")
    assert missing.ok is False


def test_unconfigured_providers_report_not_configured():
    """Без API-ключей CryptoBot/xRocket/крипта/подарки → not_configured."""
    from app.payments import get_provider
    from app.payments.base import PaymentRequest

    for code in ("cryptobot", "xrocket", "crypto", "gifts"):
        provider = get_provider(code)
        assert provider is not None
        if not provider.configured:
            import asyncio

            invoice = asyncio.run(provider.create_invoice(
                PaymentRequest(user_id=1, amount_minor=100, payload="x")))
            assert invoice.ok is False
            assert invoice.not_configured is True


async def test_successful_payment_credits_once(session, make_user):
    """Зачисление по charge идемпотентно (ключ = charge_id)."""
    await make_user(604)
    await credit(session, user_id=604, amount_minor=to_minor(25),
                 kind=TransactionType.DEPOSIT, key="stars:CHARGE1")
    await credit(session, user_id=604, amount_minor=to_minor(25),
                 kind=TransactionType.DEPOSIT, key="stars:CHARGE1")
    real, _ = await get_balances(session, 604)
    assert real == to_minor(25)


# ---------------------------- права администратора -------------------------

async def test_admin_permissions(session, make_user):
    from app.config.settings import settings
    from app.middlewares.admin import is_admin

    admin = await make_user(701)
    player = await make_user(702)

    # права проверяются на сервере по Telegram ID из конфигурации
    settings.admin_ids  # noqa: B018 — убедимся, что атрибут существует
    if 701 in settings.admin_ids or admin.is_admin:
        assert is_admin(admin, 701)
    else:
        # эмулируем включение админа в конфиг
        admin.is_admin = True
        await session.flush()
        assert is_admin(admin, 701)

    assert is_admin(player, 702) is False
    # даже без записи в БД, но с ID в ADMIN_IDS — доступ есть
    original = list(settings.admin_ids)
    try:
        settings.admin_ids.append(702)
        assert is_admin(player, 702)
    finally:
        settings.admin_ids[:] = original


async def test_admin_block_and_bonus_with_audit(session, make_user):
    await make_user(703)
    assert await admin_service.set_blocked(
        session, admin_id=1, user_id=703, blocked=True)
    user = (await session.get(__import__("app.models", fromlist=["User"]).User, 703))
    assert user.is_blocked is True

    assert await admin_service.grant_bonus(
        session, admin_id=1, user_id=703, amount_minor=to_minor(5))
    real, bonus = await get_balances(session, 703)
    assert bonus == to_minor(5)

    # финансовые действия админа попадают в аудит-лог
    actions = await admin_service.recent_actions(session, limit=10)
    codes = [a.action for a in actions]
    assert "block_user" in codes
    assert "grant_bonus" in codes


async def test_admin_coefficient_override(session, make_user):
    """Изменение коэффициента сохраняется и применяется при расчёте."""
    await make_user(704)
    ok = await admin_service.set_outcome_coef(
        session, admin_id=1, game_code="darts",
        outcome_code="red", value=2.0)
    assert ok

    coef = await admin_service.effective_coef(session, "darts", "red", 1.8)
    assert coef == 2.0
    # неизменённый исход остаётся с исходным значением
    other = await admin_service.effective_coef(session, "darts", "white", 2.7)
    assert other == 2.7

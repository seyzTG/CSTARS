"""Тесты: чеки, ежедневный бонус, кешбэк, партнёрская программа."""

from __future__ import annotations

import pytest

from app.finance import credit, get_balances
from app.models import Check, Wallet
from app.models.enums import CheckStatus, TransactionType, WalletKind
from app.services import bonuses as bonuses_service
from app.services import checks as checks_service
from app.services import referral as ref_service
from app.utils.money import to_minor


# -------------------------------- чеки -------------------------------------

async def test_create_and_redeem_check(session, make_user):
    await make_user(501)   # создатель
    await make_user(502)   # получатель
    await credit(session, user_id=501, amount_minor=to_minor(50),
                 kind=TransactionType.DEPOSIT, key="d1")

    outcome = await checks_service.create_check(
        session, creator_id=501, amount_minor=to_minor(10),
        bot_username="test_bot",
    )
    assert outcome.ok and outcome.url and "start=check_" in outcome.url
    token = outcome.check.token   # запоминаем до expire_all в сервисе

    creator_real, _ = await get_balances(session, 501)
    assert creator_real == to_minor(40)   # средства зарезервированы

    activated = await checks_service.activate_check(
        session, user_id=502, token=token)
    assert activated.ok
    receiver_real, _ = await get_balances(session, 502)
    assert receiver_real == to_minor(10)

    # одноразовое погашение
    again = await checks_service.activate_check(
        session, user_id=501, token=token)
    assert not again.ok and again.error_key == "CHECK_ALREADY"


async def test_check_limits_and_bonus_restriction(session, make_user):
    await make_user(503)
    # бонусные средства нельзя отправить чеком
    await credit(session, user_id=503, amount_minor=to_minor(10),
                 kind=TransactionType.BONUS, wallet_kind=WalletKind.BONUS,
                 key="bonus1")
    outcome = await checks_service.create_check(
        session, creator_id=503, amount_minor=to_minor(5))
    assert not outcome.ok and outcome.error_key == "CHECK_BONUS_ONLY"

    # лимиты суммы
    too_big = await checks_service.create_check(
        session, creator_id=503, amount_minor=to_minor(100_001))
    assert not too_big.ok


async def test_check_target_restriction(session, make_user):
    await make_user(504)
    await make_user(505)
    await make_user(506)
    await credit(session, user_id=504, amount_minor=to_minor(20),
                 kind=TransactionType.DEPOSIT, key="d2")

    outcome = await checks_service.create_check(
        session, creator_id=504, amount_minor=to_minor(5), target_user_id=505)
    assert outcome.ok
    token = outcome.check.token

    wrong = await checks_service.activate_check(
        session, user_id=506, token=token)
    assert not wrong.ok and wrong.error_key == "CHECK_WRONG_TARGET"

    self_activate = await checks_service.activate_check(
        session, user_id=504, token=token)
    assert not self_activate.ok and self_activate.error_key == "CHECK_SELF"

    right = await checks_service.activate_check(
        session, user_id=505, token=token)
    assert right.ok


async def test_check_cancel_returns_funds(session, make_user):
    await make_user(507)
    await credit(session, user_id=507, amount_minor=to_minor(10),
                 kind=TransactionType.DEPOSIT, key="d3")
    created = await checks_service.create_check(
        session, creator_id=507, amount_minor=to_minor(4))
    assert created.ok

    cancelled = await checks_service.cancel_check(
        session, creator_id=507, check_id=created.check.id)
    assert cancelled.ok
    real, _ = await get_balances(session, 507)
    assert real == to_minor(10)

    # повторная отмена невозможна
    check_id = created.check.id
    twice = await checks_service.cancel_check(
        session, creator_id=507, check_id=check_id)
    assert not twice.ok


async def test_concurrent_redeem_single_winner(session, make_user):
    """Два одновременных погашения — победитель ровно один."""
    await make_user(508)
    await make_user(509)
    await make_user(510)
    await credit(session, user_id=508, amount_minor=to_minor(30),
                 kind=TransactionType.DEPOSIT, key="d4")
    created = await checks_service.create_check(
        session, creator_id=508, amount_minor=to_minor(7))
    token = created.check.token

    first = await checks_service.activate_check(session, user_id=509, token=token)
    second = await checks_service.activate_check(session, user_id=510, token=token)
    assert first.ok != second.ok
    real, _ = await get_balances(session, 509)
    other, _ = await get_balances(session, 510)
    assert real + other == to_minor(7)


# --------------------------- ежедневный бонус ------------------------------

async def test_daily_bonus_requires_low_balance(session, make_user):
    await make_user(511)
    await credit(session, user_id=511, amount_minor=to_minor(50),
                 kind=TransactionType.DEPOSIT, key="d5")

    state = await bonuses_service.daily_state(session, 511)
    assert state.eligible is False
    assert "баланс должен быть меньше" in state.reason

    wallet = await session.get(Wallet, 511)
    wallet.real_balance = 0
    await session.flush()

    state2 = await bonuses_service.daily_state(session, 511)
    assert state2.eligible is True
    assert state2.amount_minor > 0


async def test_daily_bonus_once_per_day(session, make_user):
    await make_user(512)
    first = await bonuses_service.claim_daily(session, 512)
    assert first.ok and first.amount_minor > 0

    second = await bonuses_service.claim_daily(session, 512)
    assert second.ok is False   # защита от повторного получения

    real, bonus = await get_balances(session, 512)
    assert bonus == first.amount_minor   # бонусные звёзды
    assert real == 0


async def test_bonus_formula_configurable():
    from app.config import bonuses as cfg

    inputs = cfg.BonusInputs(deposits=1000, games_played=20, balance=0)
    amount = cfg.compute_amount(inputs)
    assert cfg.MIN_BONUS <= amount <= cfg.MAX_BONUS
    # формула зависит от пополнений и активности за 14 дней
    richer = cfg.BonusInputs(deposits=10000, games_played=20, balance=0)
    assert cfg.compute_amount(richer) >= amount


# -------------------------------- кешбэк -----------------------------------

async def test_cashback_period_and_duplicate_claim(session, make_user):
    await make_user(513)

    state = await bonuses_service.cashback_state(session, 513)
    assert state.eta                  # обратный отсчёт до начисления
    assert state.percent              # процент из конфигурации

    claim1 = await bonuses_service.claim_cashback(session, 513)
    claim2 = await bonuses_service.claim_cashback(session, 513)
    # без игрового результата кешбэк не начисляется, повторов не бывает
    assert claim1.ok is False
    assert claim2.ok is False


async def test_cashback_formula(session, make_user):
    from app.config import cashback as cfg

    value = cfg.compute(cfg.CashbackInputs(turnover=1000, net_loss=100,
                                           already_paid=0))
    assert value == int(100 * cfg.PERCENT_OF_LOSS / 100)
    # лимит
    capped = cfg.compute(cfg.CashbackInputs(turnover=10_000_000,
                                            net_loss=100_000_000,
                                            already_paid=0))
    assert capped == cfg.MAX_PAYOUT
    # нулевой оборот → 0
    assert cfg.compute(cfg.CashbackInputs(0, 100, 0)) == 0


# -------------------------- партнёрская программа --------------------------

async def test_referral_stats_and_claim(session, make_user):
    await make_user(514)
    await make_user(515)
    from app.repositories import social_repo

    referral = await social_repo.create_referral(
        session, inviter_id=514, invitee_id=515)
    assert referral is not None
    # повторная привязка невозможна
    assert await social_repo.create_referral(
        session, inviter_id=514, invitee_id=515) is None

    await social_repo.add_reward(session, inviter_id=514, invitee_id=515,
                                 amount_minor=to_minor(5))
    stats = await ref_service.stats(session, 514)
    assert stats.invited == 1
    assert stats.earned_minor == to_minor(5)
    assert stats.pending_minor == to_minor(5)

    claim = await ref_service.claim(session, 514)
    assert claim.ok and claim.amount_minor == to_minor(5)
    real, _ = await get_balances(session, 514)
    assert real == to_minor(5)

    # повторная выплата невозможна
    again = await ref_service.claim(session, 514)
    assert again.ok is False


def test_referral_reward_from_profit_not_from_stake():
    """Начисление — доля от прибыли проекта, не от суммы ставки."""
    from app.config.referral import RoundProfit, reward_for

    profit = RoundProfit(stake=to_minor(1000), payout=to_minor(900),
                         bonus_spent=0)
    reward = reward_for(profit, 35)
    # вознаграждение — доля от прибыли (с погрешностью округления),
    # а не процент от суммы ставки
    assert abs(reward - profit.net * 0.35) < 1
    assert reward < to_minor(1000)   # не процент от всей ставки

    # убыток проекта даёт отрицательную корректировку (не обнуляется молча)
    loss = RoundProfit(stake=to_minor(100), payout=to_minor(200), bonus_spent=0)
    assert reward_for(loss, 35) < 0

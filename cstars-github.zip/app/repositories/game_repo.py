"""Репозиторий игровых данных: раунды, ставки, авторские режимы."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Bet, CustomGameMode, GameRound
from app.models.enums import RoundStatus


async def create_round(
    session: AsyncSession,
    *,
    user_id: int,
    game_code: str,
    stake: int,
    action_id: str,
    dice_values: list[int] | None = None,
) -> GameRound | None:
    """Создать раунд. None → такой action_id уже обработан (повтор)."""
    existing = await session.scalar(
        select(GameRound).where(GameRound.action_id == action_id)
    )
    if existing is not None:
        return None
    round_ = GameRound(
        user_id=user_id,
        game_code=game_code,
        stake=stake,
        dice_values=dice_values,
        action_id=action_id,
    )
    session.add(round_)
    await session.flush()
    return round_


async def finish_round(
    session: AsyncSession,
    round_: GameRound,
    *,
    outcome_code: str | None,
    outcome_label: str | None,
    multiplier: float | None,
    payout: int,
    bonus_spent: int,
    status: RoundStatus,
    dice_values: list[int] | None = None,
) -> None:
    round_.outcome_code = outcome_code
    round_.outcome_label = outcome_label
    round_.multiplier = multiplier
    round_.payout = payout
    round_.bonus_spent = bonus_spent
    round_.status = status.value
    if dice_values is not None:
        round_.dice_values = dice_values
    round_.finished_at = datetime.now(timezone.utc)
    await session.flush()


async def create_bet(
    session: AsyncSession,
    *,
    round_id: int,
    user_id: int,
    game_code: str,
    outcome_code: str,
    outcome_label: str,
    amount: int,
    multiplier: float,
    potential_payout: int,
    is_custom: bool = False,
) -> Bet:
    bet = Bet(
        round_id=round_id,
        user_id=user_id,
        game_code=game_code,
        outcome_code=outcome_code,
        outcome_label=outcome_label,
        amount=amount,
        multiplier=multiplier,
        potential_payout=potential_payout,
        is_custom=is_custom,
    )
    session.add(bet)
    await session.flush()
    return bet


async def mark_bet_result(session: AsyncSession, bet: Bet, won: bool) -> None:
    bet.won = won
    await session.flush()


async def user_rounds(
    session: AsyncSession, user_id: int, limit: int = 10
) -> list[GameRound]:
    query = (
        select(GameRound)
        .where(GameRound.user_id == user_id)
        .order_by(GameRound.id.desc())
        .limit(limit)
    )
    return list((await session.scalars(query)).all())


async def user_bets(session: AsyncSession, user_id: int, limit: int = 10) -> list[Bet]:
    query = (
        select(Bet)
        .where(Bet.user_id == user_id)
        .order_by(Bet.id.desc())
        .limit(limit)
    )
    return list((await session.scalars(query)).all())


async def all_bets(
    session: AsyncSession, user_id: int | None = None, limit: int = 20
) -> list[Bet]:
    query = select(Bet).order_by(Bet.id.desc()).limit(limit)
    if user_id is not None:
        query = query.where(Bet.user_id == user_id)
    return list((await session.scalars(query)).all())


# ---------------------------- авторские режимы -----------------------------

async def list_custom_modes(
    session: AsyncSession, enabled_only: bool = True
) -> list[CustomGameMode]:
    query = select(CustomGameMode).order_by(CustomGameMode.id)
    if enabled_only:
        query = query.where(CustomGameMode.enabled.is_(True))
    return list((await session.scalars(query)).all())


async def get_custom_mode(
    session: AsyncSession, code: str
) -> CustomGameMode | None:
    return await session.scalar(
        select(CustomGameMode).where(CustomGameMode.code == code)
    )


async def create_custom_mode(
    session: AsyncSession,
    *,
    code: str,
    title: str,
    description: str | None,
    outcomes: list[dict],
    created_by: int,
) -> CustomGameMode:
    mode = CustomGameMode(
        code=code,
        title=title,
        description=description,
        outcomes=outcomes,
        created_by=created_by,
    )
    session.add(mode)
    await session.flush()
    return mode

"""Репозиторий пользователей, настроек и балансов."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import User, UserSettings, Wallet
from app.models.enums import PrivacyMode
from app.utils.ids import referral_token


async def get_user(session: AsyncSession, user_id: int) -> User | None:
    return await session.get(User, user_id)


async def get_or_create_user(
    session: AsyncSession,
    *,
    user_id: int,
    username: str | None,
    first_name: str | None,
    last_name: str | None,
    referrer_id: int | None = None,
) -> tuple[User, bool]:
    """Вернуть пользователя, создав при необходимости (один раз на /start)."""
    user = await session.get(User, user_id)
    if user is not None:
        # обновляем актуальные данные профиля, если изменились
        changed = False
        if username is not None and user.username != username:
            user.username = username
            changed = True
        if first_name is not None and user.first_name != first_name:
            user.first_name = first_name
            changed = True
        if last_name is not None and user.last_name != last_name:
            user.last_name = last_name
            changed = True
        if changed:
            await session.flush()
        return user, False

    token = await _unique_token(session)
    user = User(
        id=user_id,
        username=username,
        first_name=first_name,
        last_name=last_name,
        referral_token=token,
        referred_by_id=referrer_id,
    )
    session.add(user)
    await session.flush()
    session.add(UserSettings(user_id=user_id))
    session.add(Wallet(user_id=user_id))
    await session.flush()
    return user, True


async def _unique_token(session: AsyncSession) -> str:
    for _ in range(20):
        token = referral_token()
        exists = await session.scalar(
            select(User.id).where(User.referral_token == token)
        )
        if exists is None:
            return token
    raise RuntimeError("unable to allocate referral token")


async def set_privacy(session: AsyncSession, user_id: int, mode: PrivacyMode) -> None:
    await session.execute(
        update(User).where(User.id == user_id).values(privacy_mode=mode.value)
    )
    session.expire_all()


async def set_nickname(session: AsyncSession, user_id: int, nickname: str) -> None:
    await session.execute(
        update(User).where(User.id == user_id).values(nickname=nickname)
    )
    session.expire_all()


async def set_hide_from_top(session: AsyncSession, user_id: int, hide: bool) -> None:
    settings = await session.get(UserSettings, user_id)
    if settings is None:
        settings = UserSettings(user_id=user_id)
        session.add(settings)
    settings.hide_from_top = hide
    await session.flush()


async def set_blocked(session: AsyncSession, user_id: int, blocked: bool) -> None:
    await session.execute(
        update(User).where(User.id == user_id).values(is_blocked=blocked)
    )
    session.expire_all()


async def count_users(session: AsyncSession) -> int:
    return int(await session.scalar(select(func.count(User.id))) or 0)


async def count_active_today(session: AsyncSession) -> int:
    since = datetime.now(timezone.utc) - timedelta(days=1)
    query = (
        select(func.count(User.id))
        .join(Wallet, Wallet.user_id == User.id)
        .where(User.updated_at >= since)
    )
    return int(await session.scalar(query) or 0)


async def find_user_by_username(
    session: AsyncSession, username: str
) -> User | None:
    return await session.scalar(
        select(User).where(User.username == username.lstrip("@"))
    )

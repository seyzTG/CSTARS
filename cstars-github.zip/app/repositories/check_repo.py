"""Репозиторий чеков."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Check
from app.models.enums import CheckStatus


async def create_check(
    session: AsyncSession,
    *,
    check_id: str,
    token: str,
    creator_id: int,
    amount_minor: int,
    target_user_id: int | None,
    expires_at: datetime,
    parent_id: str | None = None,
) -> Check:
    item = Check(
        id=check_id,
        token=token,
        creator_id=creator_id,
        amount_minor=amount_minor,
        target_user_id=target_user_id,
        expires_at=expires_at,
        parent_id=parent_id,
    )
    session.add(item)
    await session.flush()
    return item


async def get_by_token(session: AsyncSession, token: str) -> Check | None:
    return await session.scalar(select(Check).where(Check.token == token))


async def get_by_id(session: AsyncSession, check_id: str) -> Check | None:
    return await session.get(Check, check_id)


async def active_checks(
    session: AsyncSession, creator_id: int
) -> list[Check]:
    query = (
        select(Check)
        .where(
            Check.creator_id == creator_id,
            Check.status == CheckStatus.ACTIVE.value,
        )
        .order_by(Check.created_at.desc())
    )
    return list((await session.scalars(query)).all())


async def mark_redeemed(
    session: AsyncSession, item: Check, user_id: int
) -> None:
    item.status = CheckStatus.REDEEMED.value
    item.redeemed_by = user_id
    item.redeemed_at = datetime.now(timezone.utc)
    await session.flush()


async def mark_cancelled(session: AsyncSession, item: Check) -> None:
    item.status = CheckStatus.CANCELLED.value
    item.cancelled_at = datetime.now(timezone.utc)
    await session.flush()


async def mark_expired(session: AsyncSession, item: Check) -> None:
    item.status = CheckStatus.EXPIRED.value
    await session.flush()

"""Репозиторий финансовых записей: журнал, платежи, выплаты."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Payment, Transaction, Withdrawal
from app.models.enums import (
    PaymentStatus,
    TransactionStatus,
    TransactionType,
    WithdrawalStatus,
)


# ------------------------------- транзакции -------------------------------

async def user_transactions(
    session: AsyncSession,
    user_id: int,
    types: list[TransactionType] | None = None,
    limit: int = 15,
) -> list[Transaction]:
    query = (
        select(Transaction)
        .where(Transaction.user_id == user_id)
        .order_by(Transaction.created_at.desc())
        .limit(limit)
    )
    if types:
        query = query.where(
            Transaction.type.in_([t.value for t in types])
        )
    return list((await session.scalars(query)).all())


async def total_of_types(
    session: AsyncSession,
    user_id: int,
    types: list[TransactionType],
    statuses: list[TransactionStatus] | None = None,
) -> int:
    statuses = statuses or [TransactionStatus.COMPLETED]
    query = select(func.coalesce(func.sum(Transaction.amount), 0)).where(
        Transaction.user_id == user_id,
        Transaction.type.in_([t.value for t in types]),
        Transaction.status.in_([s.value for s in statuses]),
    )
    return int(await session.scalar(query) or 0)


async def project_totals(session: AsyncSession) -> dict[str, int]:
    """Суммы по проекту для админ-статистики."""

    async def total(types: list[TransactionType]) -> int:
        query = select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.type.in_([t.value for t in types]),
            Transaction.status == TransactionStatus.COMPLETED.value,
        )
        return int(await session.scalar(query) or 0)

    deposited = await total([TransactionType.DEPOSIT])
    withdrawn = await total([TransactionType.WITHDRAW])
    bets = -await total([TransactionType.BET])
    payouts = -await total([TransactionType.PAYOUT])
    bonuses = -await total(
        [TransactionType.BONUS, TransactionType.CASHBACK, TransactionType.REFERRAL]
    )
    return {
        "deposited": deposited,
        "withdrawn": abs(withdrawn),
        "turnover": bets,
        "profit": bets - payouts + bonuses,
    }


# -------------------------------- платежи ---------------------------------

async def create_payment(
    session: AsyncSession,
    *,
    user_id: int,
    provider: str,
    amount_minor: int,
    provider_amount: float | None,
    provider_currency: str | None,
    payload: str | None,
) -> Payment:
    payment = Payment(
        user_id=user_id,
        provider=provider,
        amount_minor=amount_minor,
        provider_amount=provider_amount,
        provider_currency=provider_currency,
        payload=payload,
    )
    session.add(payment)
    await session.flush()
    return payment


async def get_payment(session: AsyncSession, payment_id: int) -> Payment | None:
    return await session.get(Payment, payment_id)


async def get_payment_by_external(
    session: AsyncSession, provider: str, external_id: str
) -> Payment | None:
    return await session.scalar(
        select(Payment).where(
            Payment.provider == provider, Payment.external_id == external_id
        )
    )


async def user_payments(
    session: AsyncSession, user_id: int, limit: int = 15
) -> list[Payment]:
    query = (
        select(Payment)
        .where(Payment.user_id == user_id)
        .order_by(Payment.created_at.desc())
        .limit(limit)
    )
    return list((await session.scalars(query)).all())


# -------------------------------- выводы ----------------------------------

async def create_withdrawal(
    session: AsyncSession,
    *,
    wid: str,
    user_id: int,
    amount_minor: int,
    commission_minor: int,
    payout_minor: int,
    method: str,
    destination: str | None,
) -> Withdrawal:
    item = Withdrawal(
        id=wid,
        user_id=user_id,
        amount_minor=amount_minor,
        commission_minor=commission_minor,
        payout_minor=payout_minor,
        method=method,
        destination=destination,
    )
    session.add(item)
    await session.flush()
    return item


async def get_withdrawal(session: AsyncSession, wid: str) -> Withdrawal | None:
    return await session.get(Withdrawal, wid)


async def user_withdrawals(
    session: AsyncSession, user_id: int, limit: int = 10
) -> list[Withdrawal]:
    query = (
        select(Withdrawal)
        .where(Withdrawal.user_id == user_id)
        .order_by(Withdrawal.created_at.desc())
        .limit(limit)
    )
    return list((await session.scalars(query)).all())


async def pending_withdrawals(
    session: AsyncSession, limit: int = 20
) -> list[Withdrawal]:
    query = (
        select(Withdrawal)
        .where(Withdrawal.status == WithdrawalStatus.PENDING.value)
        .order_by(Withdrawal.created_at)
        .limit(limit)
    )
    return list((await session.scalars(query)).all())


async def decide_withdrawal(
    session: AsyncSession,
    item: Withdrawal,
    *,
    status: WithdrawalStatus,
    admin_id: int,
    comment: str | None = None,
) -> None:
    item.status = status.value
    item.decided_by = admin_id
    item.decided_at = datetime.now(timezone.utc)
    item.admin_comment = comment
    item.user_notified = False
    await session.flush()

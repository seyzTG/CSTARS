"""Слой доступа к данным (репозитории)."""

from app.repositories import check_repo, finance_repo, game_repo, social_repo, user_repo

__all__ = ["check_repo", "finance_repo", "game_repo", "social_repo", "user_repo"]

"""Репозиторий рефералов, бонусов, кешбэка и рейтинга."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    Bet,
    Bonus,
    Cashback,
    GameRound,
    Referral,
    ReferralReward,
    User,
    UserSettings,
    Wallet,
)
from app.models.enums import (
    BonusStatus,
    BonusType,
    ReferralStatus,
    RewardStatus,
    RoundStatus,
)


# ------------------------------- рефералы ---------------------------------

async def create_referral(
    session: AsyncSession, *, inviter_id: int, invitee_id: int
) -> Referral | None:
    """Создать связь. None → уже существует (повторное начисление невозможно)."""
    existing = await session.scalar(
        select(Referral).where(Referral.invitee_id == invitee_id)
    )
    if existing is not None:
        return None
    if inviter_id == invitee_id:
        return None
    item = Referral(inviter_id=inviter_id, invitee_id=invitee_id)
    session.add(item)
    await session.flush()
    return item


async def get_referral_of(session: AsyncSession, invitee_id: int) -> Referral | None:
    return await session.scalar(
        select(Referral).where(Referral.invitee_id == invitee_id)
    )


async def invitees(session: AsyncSession, inviter_id: int) -> list[Referral]:
    query = select(Referral).where(
        Referral.inviter_id == inviter_id,
        Referral.status == ReferralStatus.ACTIVE.value,
    )
    return list((await session.scalars(query)).all())


async def add_reward(
    session: AsyncSession,
    *,
    inviter_id: int,
    invitee_id: int,
    amount_minor: int,
    round_id: int | None = None,
) -> ReferralReward:
    item = ReferralReward(
        inviter_id=inviter_id,
        invitee_id=invitee_id,
        amount_minor=amount_minor,
        round_id=round_id,
        status=(
            RewardStatus.PENDING.value
            if amount_minor >= 0
            else RewardStatus.ADJUSTED.value
        ),
    )
    session.add(item)
    await session.flush()
    return item


async def earned_total(session: AsyncSession, inviter_id: int) -> int:
    query = select(func.coalesce(func.sum(ReferralReward.amount_minor), 0)).where(
        ReferralReward.inviter_id == inviter_id
    )
    return int(await session.scalar(query) or 0)


async def pending_balance(session: AsyncSession, inviter_id: int) -> int:
    """Накоплено и ещё не выведено на баланс (положительные начисления)."""
    query = select(func.coalesce(func.sum(ReferralReward.amount_minor), 0)).where(
        ReferralReward.inviter_id == inviter_id,
        ReferralReward.status == RewardStatus.PENDING.value,
    )
    return int(await session.scalar(query) or 0)


async def pending_rewards(
    session: AsyncSession, inviter_id: int
) -> list[ReferralReward]:
    query = select(ReferralReward).where(
        ReferralReward.inviter_id == inviter_id,
        ReferralReward.status == RewardStatus.PENDING.value,
    )
    return list((await session.scalars(query)).all())


async def pay_reward(session: AsyncSession, reward: ReferralReward) -> None:
    reward.status = RewardStatus.PAID.value
    reward.paid_at = datetime.now(timezone.utc)
    await session.flush()


# -------------------------------- бонусы ----------------------------------

async def last_bonus(
    session: AsyncSession, user_id: int, kind: BonusType
) -> Bonus | None:
    query = (
        select(Bonus)
        .where(Bonus.user_id == user_id, Bonus.kind == kind.value)
        .order_by(Bonus.created_at.desc())
        .limit(1)
    )
    return await session.scalar(query)


async def bonus_taken_today(
    session: AsyncSession, user_id: int, kind: BonusType, day: date
) -> Bonus | None:
    query = select(Bonus).where(
        Bonus.user_id == user_id,
        Bonus.kind == kind.value,
        Bonus.period_date == day,
        Bonus.status == BonusStatus.PAID.value,
    )
    return await session.scalar(query)


async def grant_bonus(
    session: AsyncSession,
    *,
    user_id: int,
    kind: BonusType,
    amount_minor: int,
    period_date: date | None,
    reason: str | None = None,
) -> Bonus | None:
    """Выдать бонус. None → уже выдан за этот период (уникальный ключ)."""
    if period_date is not None:
        existing = await bonus_taken_today(session, user_id, kind, period_date)
        if existing is not None:
            return None
    item = Bonus(
        user_id=user_id,
        kind=kind.value,
        amount_minor=amount_minor,
        period_date=period_date,
        reason=reason,
        status=BonusStatus.PAID.value,
        claimed_at=datetime.now(timezone.utc),
    )
    try:
        async with session.begin_nested():
            session.add(item)
            await session.flush()
    except Exception:
        # уникальный ключ (user, kind, period) — бонус уже выдан
        session.expire_all()
        return None
    return item


async def activity_window(
    session: AsyncSession, user_id: int, days: int
) -> tuple[int, int]:
    """(сумма пополнений, число игр) за последние N дней."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    deposits = await session.scalar(
        select(func.coalesce(func.sum(Wallet.deposited_total), 0)).where(
            Wallet.user_id == user_id
        )
    )
    # пополнения за окно считаем по раундам игр и платежам через журнал
    from app.models import Transaction
    from app.models.enums import TransactionType

    deposit_sum = await session.scalar(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user_id,
            Transaction.type == TransactionType.DEPOSIT.value,
            Transaction.created_at >= since,
        )
    )
    games = await session.scalar(
        select(func.count(GameRound.id)).where(
            GameRound.user_id == user_id,
            GameRound.created_at >= since,
            GameRound.status != RoundStatus.PENDING.value,
        )
    )
    return int(deposit_sum or 0), int(games or 0)


# -------------------------------- кешбэк ----------------------------------

async def current_cashback(
    session: AsyncSession, user_id: int, period_start: date
) -> Cashback | None:
    return await session.scalar(
        select(Cashback).where(
            Cashback.user_id == user_id, Cashback.period_start == period_start
        )
    )


async def total_cashback(session: AsyncSession, user_id: int) -> int:
    query = select(func.coalesce(func.sum(Cashback.amount_minor), 0)).where(
        Cashback.user_id == user_id,
        Cashback.status == BonusStatus.PAID.value,
    )
    return int(await session.scalar(query) or 0)


async def ensure_cashback(
    session: AsyncSession,
    *,
    user_id: int,
    period_start: date,
    period_end: date,
    turnover_minor: int,
    loss_minor: int,
    percent: float,
    amount_minor: int,
) -> Cashback:
    item = await current_cashback(session, user_id, period_start)
    if item is None:
        item = Cashback(
            user_id=user_id,
            period_start=period_start,
            period_end=period_end,
            turnover_minor=turnover_minor,
            loss_minor=loss_minor,
            percent=percent,
            amount_minor=amount_minor,
        )
        session.add(item)
        await session.flush()
    return item


async def claim_cashback(session: AsyncSession, item: Cashback) -> bool:
    if item.status == BonusStatus.PAID.value or item.amount_minor <= 0:
        return False
    item.status = BonusStatus.PAID.value
    item.claimed_at = datetime.now(timezone.utc)
    await session.flush()
    return True


async def period_stats(
    session: AsyncSession, user_id: int, start: datetime, end: datetime
) -> tuple[int, int]:
    """(оборот, проигрыш) за период по завершённым раундам."""
    query = select(GameRound).where(
        GameRound.user_id == user_id,
        GameRound.created_at >= start,
        GameRound.created_at < end,
        GameRound.status.in_([RoundStatus.WON.value, RoundStatus.LOST.value]),
    )
    rounds = list((await session.scalars(query)).all())
    turnover = sum(r.stake for r in rounds)
    loss = sum(r.stake - r.payout for r in rounds if r.stake > r.payout)
    return turnover, max(0, loss)


# -------------------------------- рейтинг --------------------------------

TOP_PERIODS: dict[str, int] = {
    "all": 0,
    "today": 1,
    "yesterday": 2,
    "week": 7,
    "month": 30,
}


async def leaderboard(
    session: AsyncSession, period: str, limit: int = 10
) -> list[tuple[int, str, int]]:
    """[(user_id, public_name, value)] для топа. Скрытие приватностью."""
    days = TOP_PERIODS.get(period, 0)
    query = (
        select(
            Wallet.user_id,
            User.privacy_mode,
            User.nickname,
            User.username,
            User.first_name,
            User.last_name,
            UserSettings.hide_from_top,
            func.sum(GameRound.stake - GameRound.payout).label("net"),
        )
        .join(GameRound, GameRound.user_id == Wallet.user_id)
        .join(User, User.id == Wallet.user_id)
        .outerjoin(UserSettings, UserSettings.user_id == Wallet.user_id)
        .where(GameRound.status.in_([RoundStatus.WON.value, RoundStatus.LOST.value]))
        .group_by(
            Wallet.user_id,
            User.privacy_mode,
            User.nickname,
            User.username,
            User.first_name,
            User.last_name,
            UserSettings.hide_from_top,
        )
    )
    if days:
        since = datetime.now(timezone.utc) - timedelta(days=days)
        query = query.where(GameRound.created_at >= since)
    query = query.having(func.sum(GameRound.stake - GameRound.payout) > 0)
    query = query.order_by(func.sum(GameRound.stake - GameRound.payout).desc())
    query = query.limit(limit * 3)  # запас на скрытых приватностью

    rows = (await session.execute(query)).all()
    result: list[tuple[int, str, int]] = []
    from app.models.enums import PrivacyMode

    for row in rows:
        if row.hide_from_top:
            continue
        if row.privacy_mode == PrivacyMode.ANONYMOUS.value:
            name = "Аноним"
        elif row.privacy_mode == PrivacyMode.NICKNAME.value and row.nickname:
            name = row.nickname
        elif row.username:
            name = f"@{row.username}"
        elif row.first_name:
            name = row.first_name
        else:
            name = str(row.user_id)
        result.append((row.user_id, name, int(row.net or 0)))
        if len(result) >= limit:
            break
    return result


async def user_top_value(
    session: AsyncSession, user_id: int, period: str
) -> int:
    days = TOP_PERIODS.get(period, 0)
    query = select(
        func.coalesce(
            func.sum(GameRound.stake - GameRound.payout), 0
        )
    ).where(
        GameRound.user_id == user_id,
        GameRound.status.in_([RoundStatus.WON.value, RoundStatus.LOST.value]),
    )
    if days:
        since = datetime.now(timezone.utc) - timedelta(days=days)
        query = query.where(GameRound.created_at >= since)
    return int(await session.scalar(query) or 0)

"""Разделы, зависящие от aiogram (FSM-контексты и общие константы)."""

from aiogram.fsm.state import State, StatesGroup


class MenuStates(StatesGroup):
    """Текущий раздел — для корректной кнопки «Назад»."""

    main = State()


class BetStates(StatesGroup):
    """Ввод суммы ставки."""

    entering = State()


class CheckStates(StatesGroup):
    """Создание чека: сумма → получатель."""

    amount = State()
    target = State()


class WithdrawStates(StatesGroup):
    """Ввод суммы вывода."""

    amount = State()


class NicknameStates(StatesGroup):
    """Ввод никнейма."""

    entering = State()


class CustomBetStates(StatesGroup):
    """Ставка в авторском режиме."""

    entering = State()

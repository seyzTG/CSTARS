"""Обработчик /start: регистрация, реферальная ссылка, активация чеков."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.settings import settings
from app.handlers.states import MenuStates
from app.keyboards import main_keyboard
from app.models import User
from app.services import checks as checks_service
from app.services import users as users_service
from app.utils.ids import uuid_hex
from app.utils.money import format_amount
from app.utils.tg import send

router = Router(name="start")


@router.message(Command("start"))
async def cmd_start(
    message: Message,
    command: CommandObject,
    session: AsyncSession,
    db_user: User,
    state: FSMContext,
) -> None:
    payload = (command.args or "").strip() if command else ""

    if payload.startswith("check_"):
        await _activate_check(message, session, db_user, payload[6:])
    elif payload:
        await _handle_referral(message, session, db_user, payload)

    await send(message, texts.WELCOME, name=db_user.display_label(),
               reply_markup=None)
    # приветствие + главная клавиатура (как на референсе)
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())
    await state.set_state(MenuStates.main)


async def _handle_referral(
    message: Message, session: AsyncSession, db_user: User, token: str
) -> None:
    """Связать пригласившего и уведомить его о новом игроке."""
    from sqlalchemy import select

    from app.models import User as UserModel

    inviter_id = await session.scalar(
        select(UserModel.id).where(UserModel.referral_token == token)
    )
    if inviter_id is None or inviter_id == db_user.id:
        return  # неизвестный токен или самоприглашение

    referral = await app_social_create(session, inviter_id, db_user.id)
    if referral is None:
        return

    # уведомление пригласившему
    try:
        await message.bot.send_message(
            inviter_id,
            f"🆕 Новый игрок запустил бота по вашей ссылке: "
            f"{db_user.display_label()}",
        )
    except Exception:  # noqa: BLE001 — пользователь мог заблокировать бота
        pass


async def app_social_create(session, inviter_id: int, invitee_id: int):
    from app.repositories import social_repo

    return await social_repo.create_referral(
        session, inviter_id=inviter_id, invitee_id=invitee_id
    )


async def _activate_check(
    message: Message, session: AsyncSession, db_user: User, token: str
) -> None:
    outcome = await checks_service.activate_check(
        session, user_id=db_user.id, token=token
    )
    if not outcome.ok:
        template = getattr(texts, outcome.error_key or "CHECK_NOT_FOUND")
        await send(message, template)
        return

    item = outcome.check
    await send(
        message,
        texts.CHECK_ACTIVATED,
        amount=format_amount(item.amount_minor) if item else "0",
        balance=format_amount(await _balance(session, db_user.id)),
    )


async def _balance(session: AsyncSession, user_id: int) -> int:
    from app.finance import get_balances

    real, bonus = await get_balances(session, user_id)
    return real + bonus


@router.callback_query(F.data == "nav:start")
async def nav_start(query: CallbackQuery, db_user: User) -> None:
    """Возврат к главному приветствию."""
    await query.answer()
    await send(query.message, texts.WELCOME, name=db_user.display_label())

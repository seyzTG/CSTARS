"""Баланс, пополнение (Stars/CryptoBot/xRocket/крипта/подарки) и вывод.

Ключевые правила:
  * Telegram Stars — официальные платежи Bot API (pre_checkout_query +
    successful_payment), зачисление только после подтверждения Telegram;
  * каждый провайдер — отдельный адаптер, без ключей состояние not_configured;
  * повторное уведомление провайдера не зачисляет деньги дважды
    (уникальный charge_id в webhook_events + идемпотентный журнал);
  * внутренние единицы и реальные Stars разделяются явным курсом
    settings.units_per_star.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    CallbackQuery,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.settings import settings
from app.finance import credit, get_balances
from app.handlers.states import WithdrawStates
from app.keyboards.inline import (
    build_deposit_keyboard,
    build_profile_keyboard,
    build_stars_amount_keyboard,
    build_withdraw_keyboard,
)
from app.keyboards.reply import main_keyboard, simple_cancel_keyboard
from app.models import Payment, User, Wallet, WebhookEvent
from app.models.enums import PaymentStatus, TransactionType, WalletKind
from app.payments import get_provider, stars_invoice_payload
from app.repositories import finance_repo
from app.services import withdrawals as wd_service
from app.utils.logging import get_logger
from app.utils.money import format_amount, parse_amount, to_minor
from app.utils.tg import answer, edit_or_send, send

log = get_logger(__name__)
router = Router(name="balance")

# методы, доступные для ВЫВОДА (без подарков — их нельзя вывести)
WITHDRAW_METHODS = {"stars", "cryptobot", "xrocket", "crypto"}


# ------------------------------- экраны ------------------------------------

async def render_balance(message: Message, session: AsyncSession, user: User) -> None:
    real, bonus = await get_balances(session, user.id)
    await edit_or_send(message, texts.BALANCE_SCREEN,
                       reply_markup=build_profile_keyboard(),
                       balance=format_amount(real + bonus))


async def render_deposit_menu(message: Message) -> None:
    await edit_or_send(message, texts.DEPOSIT_TITLE,
                       reply_markup=build_deposit_keyboard())


async def render_withdraw_menu(message: Message) -> None:
    await edit_or_send(message, texts.WITHDRAW_TITLE,
                       reply_markup=build_withdraw_keyboard())


# ----------------------------- пополнение ----------------------------------

@router.callback_query(F.data.startswith("pay:dep:"))
async def on_deposit_method(query: CallbackQuery, state: FSMContext) -> None:
    method = query.data.split(":")[2]
    provider = get_provider(method)
    if provider is None or not provider.configured:
        await answer(query, texts.PAY_NOT_CONFIGURED, alert=True)
        return

    if method == "stars":
        await answer(query)
        await state.update_data(dep_method="stars")
        from app.utils.format import render

        plain, entities = render(texts.STARS_CHOOSE_AMOUNT)
        try:
            await query.message.edit_text(
                plain, entities=entities,
                reply_markup=build_stars_amount_keyboard())
        except Exception:  # noqa: BLE001
            await query.message.answer(
                plain, entities=entities,
                reply_markup=build_stars_amount_keyboard())
        return

    # CryptoBot / xRocket: сразу создаём платёж и отдаём ссылку
    await answer(query)
    await _create_external_invoice(query, method)


async def _create_external_invoice(query: CallbackQuery, method: str) -> None:
    """Создать платёж у внешнего провайдера и показать ссылку."""
    from app.database.session import get_session_factory

    user_id = query.from_user.id
    amount_minor = to_minor(10)  # базовая сумма; уточняется при расширении метода
    provider = get_provider(method)
    if provider is None:
        await send(query.message, texts.PAY_PROVIDER_ERROR)
        return

    async with get_session_factory()() as session:
        payment = await finance_repo.create_payment(
            session, user_id=user_id, provider=method,
            amount_minor=amount_minor, provider_amount=None,
            provider_currency=None, payload=None,
        )
        payload = f"{method}:{payment.id}:{user_id}:{amount_minor}"
        payment.payload = payload
        await session.commit()
        payment_id = payment.id

    from app.payments.base import PaymentRequest

    invoice = await provider.create_invoice(
        PaymentRequest(user_id=user_id, amount_minor=amount_minor,
                       payload=payload)
    )
    if not invoice.ok:
        await send(query.message,
                   texts.PAY_NOT_CONFIGURED if invoice.not_configured
                   else texts.PAY_PROVIDER_ERROR)
        return

    async with get_session_factory()() as session:
        stored = await finance_repo.get_payment(session, payment_id)
        if stored is not None:
            stored.external_id = invoice.external_id
            stored.invoice_url = invoice.invoice_url
            stored.provider_amount = invoice.provider_amount
            stored.provider_currency = invoice.provider_currency
            await session.commit()

    await query.message.answer(
        f"💳 Оплатите по ссылке: {invoice.invoice_url}\n"
        f"Зачисление произойдёт после подтверждения платежа."
    )


@router.callback_query(F.data.startswith("pay:stars:"))
async def on_stars_amount(query: CallbackQuery, session: AsyncSession,
                          db_user: User) -> None:
    try:
        stars = int(query.data.split(":")[2])
    except (IndexError, ValueError):
        await answer(query)
        return

    provider = get_provider("stars")
    if provider is None or not provider.configured:
        await answer(query, texts.PAY_NOT_CONFIGURED, alert=True)
        return

    amount_minor = to_minor(round(stars * settings.units_per_star))
    payment = await finance_repo.create_payment(
        session, user_id=db_user.id, provider="stars",
        amount_minor=amount_minor, provider_amount=float(stars),
        provider_currency="XTR", payload=None,
    )
    payload = stars_invoice_payload(payment.id, db_user.id, amount_minor)
    payment.payload = payload
    await session.flush()

    from app.payments.base import PaymentRequest

    invoice = await provider.create_invoice(
        PaymentRequest(
            user_id=db_user.id, amount_minor=amount_minor, payload=payload
        )
    )
    if not invoice.ok or not invoice.telegram_invoice:
        await answer(query, texts.STARS_INVOICE_ERROR, alert=True)
        return

    await answer(query)
    data = invoice.telegram_invoice
    try:
        await query.message.answer_invoice(
            title=data["title"],
            description=data["description"],
            payload=data["payload"],
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice(label="Пополнение", amount=stars)],
            start_parameter=f"dep{payment.id}",
        )
    except Exception as exc:  # noqa: BLE001
        log.warning("invoice failed: %s", type(exc).__name__)
        await send(query.message, texts.STARS_INVOICE_ERROR)


# --------------------- pre_checkout / successful_payment -------------------

@router.pre_checkout_query()
async def on_pre_checkout(query: PreCheckoutQuery, session: AsyncSession) -> None:
    """Серверная проверка payload перед подтверждением платежа."""
    payload = query.invoice_payload or ""
    currency = (query.currency or "").upper()
    if currency != "XTR":
        await query.answer(ok=False, error_message="Некорректная валюта платежа.")
        return

    parts = payload.split(":")
    if len(parts) != 4 or parts[0] != "stars":
        await query.answer(ok=False, error_message="Некорректный payload платежа.")
        return

    payment_id = int(parts[1])
    payment = await finance_repo.get_payment(session, payment_id)
    if payment is None or payment.status == PaymentStatus.PAID.value:
        await query.answer(ok=False, error_message="Платёж уже обработан.")
        return
    if payment.user_id != query.from_user.id:
        await query.answer(ok=False, error_message="Платёж принадлежит другому пользователю.")
        return
    # сверяем сумму: инвойс выставлен в Stars (XTR)
    expected_stars = int(payment.provider_amount or 0)
    if expected_stars and (query.total_amount or 0) != expected_stars:
        await query.answer(ok=False, error_message="Сумма платежа не совпадает.")
        return

    await query.answer(ok=True)


@router.message(F.successful_payment)
async def on_successful_payment(message: Message, session: AsyncSession,
                                db_user: User) -> None:
    payment_info = message.successful_payment
    charge_id = payment_info.telegram_payment_charge_id
    payload = payment_info.invoice_payload or ""

    # идемпотентность: повторное уведомление не зачисляет деньги повторно
    duplicate = await _register_charge(session, charge_id, payload)
    if duplicate:
        return

    parts = payload.split(":")
    if len(parts) != 4:
        return
    payment_id = int(parts[1])
    payment = await finance_repo.get_payment(session, payment_id)
    if payment is None or payment.status == PaymentStatus.PAID.value:
        return

    payment.status = PaymentStatus.PAID.value
    payment.external_id = charge_id
    from app.utils.timeutil import utcnow

    payment.confirmed_at = utcnow()
    await session.flush()

    applied = await credit(
        session, user_id=db_user.id, amount_minor=payment.amount_minor,
        kind=TransactionType.DEPOSIT, key=f"stars:{charge_id}",
        description=f"Пополнение Telegram Stars ({payment.provider_amount} ★)",
        external_id=charge_id, payment_id=payment.id,
    )
    wallet = await session.get(Wallet, db_user.id)
    if wallet is not None and applied.applied:
        wallet.deposited_total += payment.amount_minor
        await session.flush()

    real, bonus = await get_balances(session, db_user.id)
    await send(
        message, texts.PAY_SUCCESS,
        amount=format_amount(payment.amount_minor),
        balance=format_amount(real + bonus),
    )


async def _register_charge(session: AsyncSession, charge_id: str,
                           payload: str) -> bool:
    """Зафиксировать charge в отдельной точке. True → уже обрабатывался.

    Вставка идёт в savepoint: конфликт уникального ключа НЕ откатывает
    внешнюю транзакцию сессии.
    """
    event = WebhookEvent(
        provider="stars", external_id=charge_id,
        event_type="successful_payment", payload=payload[:500],
        status="processed",
    )
    try:
        async with session.begin_nested():
            session.add(event)
            await session.flush()
        return False
    except IntegrityError:
        session.expire_all()
        return True


# -------------------------------- вывод ------------------------------------

@router.callback_query(F.data.startswith("pay:wd:"))
async def on_withdraw_method(query: CallbackQuery, state: FSMContext) -> None:
    method = query.data.split(":")[2]
    if method not in WITHDRAW_METHODS:
        await answer(query, texts.PAY_NOT_CONFIGURED, alert=True)
        return
    provider = get_provider(method)
    if provider is None or not provider.configured:
        await answer(query, texts.PAY_NOT_CONFIGURED, alert=True)
        return

    await state.update_data(wd_method=method)
    await answer(query)
    await send(
        query.message, texts.WD_CHOOSE_AMOUNT,
        reply_markup=simple_cancel_keyboard(),
        min=settings.withdraw_min, max=settings.withdraw_max,
    )
    await state.set_state(WithdrawStates.amount)


@router.message(WithdrawStates.amount, F.text == texts.KB_CANCEL)
async def on_withdraw_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(WithdrawStates.amount, F.text)
async def on_withdraw_amount(message: Message, session: AsyncSession,
                             db_user: User, state: FSMContext) -> None:
    minor = parse_amount(message.text or "")
    if minor is None:
        await send(message, texts.WD_INVALID_AMOUNT)
        return

    data = await state.get_data()
    method = data.get("wd_method", "stars")

    result = await wd_service.request_withdrawal(
        session, user_id=db_user.id, amount_minor=minor,
        method=method, destination=None,
    )
    await state.clear()

    if not result.ok:
        template = getattr(texts, result.error_key or "WD_INVALID_AMOUNT")
        await send(
            message, template,
            reply_markup=main_keyboard(),
            **(result.context or {}),
        )
        return

    item = result.withdrawal
    await send(
        message, texts.WD_CREATED,
        reply_markup=main_keyboard(),
        wid=item.id[:8],
        amount=format_amount(item.amount_minor),
        commission=format_amount(item.commission_minor),
        total=format_amount(item.payout_minor),
        status="Ожидает подтверждения",
    )
    await _notify_admins(message, item)


async def _notify_admins(message: Message, item) -> None:
    """Уведомить администраторов о новой заявке на вывод."""
    from app.config.settings import settings as cfg
    from app.keyboards.inline import build_admin_withdrawal_keyboard

    for admin_id in cfg.admin_ids:
        try:
            await message.bot.send_message(
                admin_id,
                f"🆕 Заявка на вывод {format_amount(item.amount_minor)} ★ "
                f"({item.method}) от {item.user_id}\nID: {item.id[:8]}",
                reply_markup=build_admin_withdrawal_keyboard(item.id),
            )
        except Exception:  # noqa: BLE001
            pass


@router.message(F.text == texts.BTN_WITHDRAW)
async def on_withdraw_history(message: Message, session: AsyncSession,
                              db_user: User) -> None:
    """История выводов (кнопка из профиля)."""
    items = await finance_repo.user_withdrawals(session, db_user.id, limit=10)
    if not items:
        await send(message, texts.WD_HISTORY_EMPTY)
        return
    status_names = {
        "pending": "Ожидает", "approved": "Подтверждена",
        "rejected": "Отклонена", "paid": "Выполнена",
    }
    lines = [
        f"• {format_amount(i.amount_minor)} ★ — "
        f"{status_names.get(i.status, i.status)} ({i.method})"
        for i in items
    ]
    await send(message, texts.WD_HISTORY, items="\n".join(lines))

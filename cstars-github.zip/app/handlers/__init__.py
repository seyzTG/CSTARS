"""Сборка всех роутеров обработчиков в порядке приоритета."""

from __future__ import annotations

from aiogram import Router

from app.handlers import (
    admin,
    balance,
    blackjack,
    bonuses,
    checks,
    crash,
    errors,
    games,
    info,
    menu,
    profile,
    referral,
    start,
    top,
)


def build_root_router() -> Router:
    """Главный роутер: ошибки → старт → админка → бизнес-разделы."""
    root = Router(name="root")

    root.include_router(errors.router)      # ошибки — первыми
    root.include_router(start.router)       # /start (deep-links)
    root.include_router(admin.router)       # админ-команды
    root.include_router(games.router)       # игры и ставки
    root.include_router(blackjack.router)   # 21 Очко (раздача против дилера)
    root.include_router(crash.router)       # Crash (полёт ракеты)
    root.include_router(checks.router)      # чеки
    root.include_router(balance.router)     # платежи и вывод
    root.include_router(profile.router)     # профиль и приватность
    root.include_router(bonuses.router)     # бонусы и кешбэк
    root.include_router(referral.router)    # партнёрка
    root.include_router(top.router)         # рейтинг
    root.include_router(info.router)        # информация
    root.include_router(menu.router)        # меню и навигация — последним
    return root


__all__ = ["build_root_router"]

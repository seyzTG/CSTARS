"""Crash: запуск ракеты, рост множителя и кнопка «Забрать».

Ставка списывается при запуске (settlement.start_round). Точка взрыва
определяется сервером заранее (games/crash.py), сообщение полёта
обновляется каждые 1.5–2 секунды. Пока полёт активен, повторный запуск
заблокирован. Выигрыш начисляется по последнему ПОКАЗАННОМУ множителю —
именно его игрок видит под сообщением в момент нажатия «Забрать».
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup
from sqlalchemy import delete as sa_delete
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.crash import get_crash_config
from app.database.session import get_session_factory
from app.finance import InsufficientFunds
from app.games.crash import (
    CrashPlan,
    format_multiplier,
    next_tick,
    plan_crash,
)
from app.games.engine import RollResult
from app.keyboards.inline import build_crash_keyboard, build_crash_result_keyboard
from app.models import User
from app.services import settlement
from app.utils.format import render
from app.utils.ids import action_id as make_action_id
from app.utils.logging import get_logger
from app.utils.money import apply_multiplier, format_amount
from app.utils.tg import answer, send

log = get_logger(__name__)
router = Router(name="crash")

# сколько завершённые полёты хранятся в памяти (защита от повторных кликов)
RUN_TTL_SECONDS = 600


@dataclass
class CrashRun:
    """Активный полёт ракеты (данные в памяти процесса)."""

    user_id: int
    chat_id: int
    round_id: int
    stake_minor: int
    bonus_spent: int
    action_id: str
    plan: CrashPlan
    started_at: float
    message_id: int | None = None
    displayed_multiplier: Decimal = Decimal("1.15")
    displayed_amount_minor: int = 0
    cashed_out: bool = False
    finished: bool = False
    task: asyncio.Task | None = None
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


RUNS: dict[int, CrashRun] = {}


def _active_run(user_id: int) -> CrashRun | None:
    """Незавершённый полёт пользователя (для блокировки повторного запуска)."""
    for run in RUNS.values():
        if run.user_id == user_id and not run.finished:
            return run
    return None


def _prune_runs() -> None:
    now = time.monotonic()
    stale = [
        key for key, run in RUNS.items()
        if run.finished and now - run.started_at > RUN_TTL_SECONDS
    ]
    for key in stale:
        RUNS.pop(key, None)


async def _discard_round(session: AsyncSession, action_id: str) -> None:
    """Удалить раунд, если списание ставки не удалось (без возврата средств!).

    ``settlement.start_round`` сначала создаёт раунд и ставку, а уже потом
    списывает средства. При недостатке средств остаётся «пустой» PENDING-
    раунд — удаляем его, чтобы восстановление после рестарта не вернуло
    деньги, которых не списывали.
    """
    from app.models import Bet, GameRound

    round_ = await session.scalar(
        select(GameRound).where(GameRound.action_id == action_id)
    )
    if round_ is None:
        return
    await session.execute(sa_delete(Bet).where(Bet.round_id == round_.id))
    await session.delete(round_)
    await session.flush()


# ------------------------------- запуск ракеты -------------------------------

@router.callback_query(F.data == "game:crash:start")
async def on_crash_start(query: CallbackQuery, session: AsyncSession,
                         db_user: User, state: FSMContext) -> None:
    _prune_runs()
    active = _active_run(db_user.id)
    if active is not None:
        await answer(query, texts.CRASH_ALREADY, alert=True)
        return

    data = await state.get_data()
    bet_minor = int(data.get("bet_minor", 0) or 0)
    if bet_minor <= 0:
        from app.config.settings import settings
        from app.utils.money import to_minor

        bet_minor = to_minor(settings.bet_min)

    validation = settlement.validate_bet(
        stake_minor=bet_minor, outcome_code="cashout", game_code="crash")
    if not validation.ok:
        template = getattr(texts, validation.error or "ERR_GENERIC")
        await answer(query, template.format(**(validation.context or {})),
                     alert=True)
        return

    uid = make_action_id(
        db_user.id, "crash", bet_minor,
        datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f"),
    )
    try:
        round_id, bonus_spent, _real, duplicate = await settlement.start_round(
            session,
            user_id=db_user.id,
            game_code="crash",
            outcome_code="cashout",
            outcome_label="Crash",
            coefficient=None,
            stake_minor=bet_minor,
            action_id=uid,
        )
    except InsufficientFunds:
        # раунд уже создан, но списания не было — удаляем его БЕЗ возврата
        await _discard_round(session, uid)
        await answer(query, texts.BET_NO_FUNDS, alert=True)
        return
    if duplicate is not None:
        await answer(query, texts.BET_LOCKED, alert=True)
        return

    config = get_crash_config()
    plan = plan_crash(config)
    start_mult = plan.start_multiplier
    start_amount = apply_multiplier(bet_minor, float(start_mult))

    sent = await send(
        query.message, texts.CRASH_LAUNCH,
        reply_markup=build_crash_keyboard(round_id),
        mult=format_multiplier(start_mult),
        amount=format_amount(start_amount),
        bet=format_amount(bet_minor),
    )
    if sent is None:
        # сообщение не отправлено — возвращаем ставку, полёт не начинаем
        await settlement.void_round(
            session, user_id=db_user.id, round_id=round_id,
            stake_minor=bet_minor, bonus_spent=bonus_spent, action_id=uid,
        )
        await answer(query, texts.ERR_GENERIC, alert=True)
        return

    run = CrashRun(
        user_id=db_user.id,
        chat_id=query.message.chat.id,
        round_id=round_id,
        stake_minor=bet_minor,
        bonus_spent=bonus_spent,
        action_id=uid,
        plan=plan,
        started_at=time.monotonic(),
        message_id=sent.message_id,
        displayed_multiplier=start_mult,
        displayed_amount_minor=start_amount,
    )
    RUNS[round_id] = run
    await state.update_data(
        game_code="crash", crash_round_id=round_id, crash_action_id=uid,
    )
    await answer(query)

    task = asyncio.create_task(_flight(run, query.bot), name=f"crash-{round_id}")
    run.task = task


# ---------------------------------- полёт -----------------------------------

async def _flight(run: CrashRun, bot) -> None:
    """Фоновый цикл: обновляет множитель и взрывает ракету в свою точку."""
    config = get_crash_config()
    try:
        while True:
            await asyncio.sleep(next_tick(config))
            elapsed = time.monotonic() - run.started_at
            candidate = run.plan.multiplier_at(elapsed)

            if run.plan.is_crash(candidate):
                async with run.lock:
                    if run.cashed_out:
                        return
                    run.finished = True
                    await _settle_loss(run, bot)
                return

            if await _render_flight(bot, run, candidate):
                run.displayed_multiplier = candidate
                run.displayed_amount_minor = apply_multiplier(
                    run.stake_minor, float(candidate)
                )
    except asyncio.CancelledError:
        raise
    except Exception:  # noqa: BLE001 — не роняем фоновый таск молча
        log.exception("Crash flight crashed: round=%s user=%s",
                      run.round_id, run.user_id)
        async with run.lock:
            if not run.finished and not run.cashed_out:
                run.finished = True
                await _settle_void(run, bot)


async def _render_flight(bot, run: CrashRun, multiplier: Decimal) -> bool:
    """Обновить сообщение полёта. True — показано (или уже совпадает)."""
    if run.message_id is None:
        return False
    text, entities = render(
        texts.CRASH_LAUNCH,
        mult=format_multiplier(multiplier),
        amount=format_amount(apply_multiplier(run.stake_minor, float(multiplier))),
        bet=format_amount(run.stake_minor),
    )
    try:
        await bot.edit_message_text(
            text, chat_id=run.chat_id, message_id=run.message_id,
            entities=entities, reply_markup=build_crash_keyboard(run.round_id),
        )
        return True
    except TelegramBadRequest as exc:
        if "not modified" in str(exc).lower():
            return True
        log.warning("Crash flight edit failed: %s", str(exc)[:160])
        return False


# ------------------------------- кнопка «Забрать» ---------------------------

@router.callback_query(F.data.startswith("crash:take:"))
async def on_crash_take(query: CallbackQuery, session: AsyncSession,
                        db_user: User) -> None:
    try:
        round_id = int(query.data.split(":")[2])
    except (IndexError, ValueError):
        await answer(query, texts.CRASH_NO_RUN, alert=True)
        return

    run = RUNS.get(round_id)
    if run is None or run.finished:
        await answer(query, texts.CRASH_NO_RUN, alert=True)
        return
    if run.user_id != (query.from_user.id if query.from_user else 0):
        await answer(query, texts.ERR_ACCESS_DENIED, alert=True)
        return
    if run.cashed_out:
        await answer(query, texts.CRASH_ALREADY, alert=True)
        return

    # момент, показанный игроку: расчёт идёт по нему, а не по «внутреннему»
    multiplier = run.displayed_multiplier

    async with run.lock:
        if run.finished or run.cashed_out:
            await answer(query, texts.CRASH_NO_RUN, alert=True)
            return
        run.cashed_out = True

        roll = RollResult(
            game_code="crash", values=[],
            outcome_code="cashout", outcome_label="Забрать",
        )
        try:
            result = await settlement.finish_round(
                session,
                user_id=run.user_id,
                round_id=run.round_id,
                game_code="crash",
                outcome_code="cashout",
                outcome_label="Crash",
                coefficient=float(multiplier),
                stake_minor=run.stake_minor,
                bonus_spent=run.bonus_spent,
                roll=roll,
                action_id=run.action_id,
            )
        except Exception:  # noqa: BLE001
            # расчёт не удался — снимаем пометку, чтобы полёт продолжился
            # обычным взрывом (или игрок смог нажать «Забрать» ещё раз)
            log.exception("Crash take failed: round=%s", run.round_id)
            run.cashed_out = False
            await answer(query, texts.ERR_GENERIC, alert=True)
            return
        run.finished = True
        run.displayed_multiplier = multiplier
        run.displayed_amount_minor = result.payout_minor

    await answer(query)

    task = run.task
    if task is not None and not task.done():
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)

    await _render_result(
        query.bot, run, texts.CRASH_TAKEN,
        markup=build_crash_result_keyboard(),
        mult=format_multiplier(multiplier),
        bet=format_amount(run.stake_minor),
        win=format_amount(result.payout_minor),
        balance=format_amount(result.balance_minor),
    )


# --------------------------------- расчёт -----------------------------------

async def _finish_loss(run: CrashRun, session: AsyncSession):
    roll = RollResult(
        game_code="crash", values=[],
        outcome_code="crash", outcome_label="Взрыв",
    )
    return await settlement.finish_round(
        session,
        user_id=run.user_id,
        round_id=run.round_id,
        game_code="crash",
        outcome_code="cashout",
        outcome_label="Crash",
        coefficient=float(run.plan.crash_multiplier),
        stake_minor=run.stake_minor,
        bonus_spent=run.bonus_spent,
        roll=roll,
        action_id=run.action_id,
    )


async def _settle_loss(run: CrashRun, bot) -> None:
    """Взрыв: ставка сгорает, сообщение показывает точку падения."""
    try:
        async with get_session_factory()() as session:
            result = await _finish_loss(run, session)
            await session.commit()
    except Exception:  # noqa: BLE001 — раунд не должен остаться PENDING
        log.exception("Crash loss settlement failed: round=%s", run.round_id)
        await _settle_void(run, bot)
        return
    await _render_result(
        bot, run, texts.CRASH_BOOM,
        markup=build_crash_result_keyboard(),
        mult=format_multiplier(run.plan.crash_multiplier),
        bet=format_amount(run.stake_minor),
        balance=format_amount(result.balance_minor),
    )


async def _settle_void(run: CrashRun, bot) -> None:
    """Аварийный возврат ставки (сбой фонового таска)."""
    try:
        async with get_session_factory()() as session:
            await settlement.void_round(
                session, user_id=run.user_id, round_id=run.round_id,
                stake_minor=run.stake_minor, bonus_spent=run.bonus_spent,
                action_id=run.action_id,
            )
            await session.commit()
        # кнопка «Забрать» исчезает и в аварийном сценарии
        await _render_result(
            bot, run, texts.ERR_SESSION,
            markup=InlineKeyboardMarkup(inline_keyboard=[]),
        )
    except Exception:  # noqa: BLE001
        log.exception("Crash void failed: round=%s", run.round_id)


async def _render_result(bot, run: CrashRun, template: str, *,
                         markup: InlineKeyboardMarkup | None = None,
                         **context: object) -> None:
    """Отредактировать сообщение полёта в итоговое (без кнопки «Забрать»)."""
    if run.message_id is None:
        return
    text, entities = render(template, **context)
    try:
        await bot.edit_message_text(
            text, chat_id=run.chat_id, message_id=run.message_id,
            entities=entities, reply_markup=markup,
        )
    except TelegramBadRequest as exc:
        if "not modified" not in str(exc).lower():
            log.warning("Crash result edit failed: %s", str(exc)[:160])


# --------------------------- восстановление после рестарта -------------------

async def recover_pending_rounds() -> int:
    """Вернуть ставки по «зависшим» полётам Crash после перезапуска бота.

    Фоновые таски живут только в процессе, поэтому незавершённые раунды
    (например, после падения/перезапуска) закрываются возвратом ставки.
    """
    from app.models import GameRound
    from app.models.enums import RoundStatus

    async with get_session_factory()() as session:
        query = select(GameRound).where(
            GameRound.game_code == "crash",
            GameRound.status == RoundStatus.PENDING.value,
            GameRound.finished_at.is_(None),
        )
        rounds = list((await session.scalars(query)).all())
        for round_ in rounds:
            await settlement.void_round(
                session, user_id=round_.user_id, round_id=round_.id,
                stake_minor=round_.stake, bonus_spent=round_.bonus_spent,
                action_id=round_.action_id,
            )
        await session.commit()

    for round_ in rounds:
        RUNS.pop(round_.id, None)
    if rounds:
        log.info("Crash: возвращено ставок по зависшим полётам — %s", len(rounds))
    return len(rounds)


__all__ = ["router", "recover_pending_rounds"]

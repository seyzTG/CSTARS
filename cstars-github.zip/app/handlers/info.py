"""Экраны «Информация» и «Правила»."""

from __future__ import annotations

from aiogram import Router
from aiogram.types import Message

from app.config import texts
from app.config.settings import settings
from app.keyboards.inline import build_info_keyboard
from app.utils.tg import edit_or_send

router = Router(name="info")


async def render_info(message: Message) -> None:
    await edit_or_send(
        message, texts.INFO, reply_markup=build_info_keyboard(),
        bot=texts.BOT_NAME, support=texts.SUPPORT_URL,
        channel=texts.CHANNEL_URL,
    )


async def render_rules(message: Message) -> None:
    await edit_or_send(
        message, texts.INFO_RULES,
        reply_markup=_back_button(),
        min=settings.bet_min, max=settings.bet_max,
    )


def _back_button():
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=texts.KB_BACK, callback_data="nav:info"),
    ]])


@router.callback_query(lambda c: c.data == "info:rules")
async def on_rules(query) -> None:
    await query.answer()
    await render_rules(query.message)

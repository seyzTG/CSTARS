"""Чеки: меню, создание (сумма → получатель), активные, отмена, погашение."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.settings import settings
from app.handlers.states import CheckStates
from app.keyboards.inline import (
    build_active_checks_keyboard,
    build_check_personal_keyboard,
    build_check_types_keyboard,
    build_checks_keyboard,
)
from app.keyboards.reply import main_keyboard, simple_cancel_keyboard
from app.models import User
from app.repositories import check_repo
from app.services import checks as checks_service
from app.utils.money import format_amount, parse_amount
from app.utils.timeutil import format_dt
from app.utils.tg import answer, edit_or_send, send

router = Router(name="checks")


async def render_checks_menu(message: Message) -> None:
    await edit_or_send(message, texts.CHECKS_MENU,
                       reply_markup=build_checks_keyboard())


async def render_check_types(message: Message) -> None:
    await edit_or_send(message, texts.CHECKS_TYPES,
                       reply_markup=build_check_types_keyboard())


# ------------------------------ создание -----------------------------------

@router.callback_query(F.data == "check:personal")
async def on_personal(query: CallbackQuery, state: FSMContext) -> None:
    await answer(query)
    await edit_or_send(query.message, texts.CHECK_PERSONAL,
                       reply_markup=build_check_personal_keyboard())


@router.callback_query(F.data == "check:multi")
async def on_multi(query: CallbackQuery) -> None:
    await answer(query, "Мультичек: разделит сумму на несколько чеков. "
                        "Создайте персональный чек — мультичек появится после "
                        "настройки.", alert=True)


@router.callback_query(F.data == "check:share")
async def on_share(query: CallbackQuery) -> None:
    """Кнопка «Создать из чата» — публикация чека в выбранный чат."""
    await answer(query)
    await query.message.answer(
        "Отправьте бота в нужный чат или поделитесь ссылкой на чек "
        "после создания — активировать его сможет любой участник."
    )


@router.callback_query(F.data == "check:new")
async def on_new_check(query: CallbackQuery, state: FSMContext) -> None:
    await answer(query)
    await send(
        query.message, texts.CHECK_AMOUNT_PROMPT,
        reply_markup=simple_cancel_keyboard(),
        min=settings.check_min,
    )
    await state.set_state(CheckStates.amount)


@router.message(CheckStates.amount, F.text == texts.KB_CANCEL)
async def on_check_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(CheckStates.amount, F.text)
async def on_check_amount(message: Message, state: FSMContext) -> None:
    minor = parse_amount(message.text or "")
    max_minor = settings.check_max * 100
    if minor is None:
        await send(message, texts.CHECK_AMOUNT_INVALID,
                   min=settings.check_min, max=settings.check_max)
        return
    if minor > max_minor:
        await send(message, texts.CHECK_MAX_ERROR, max=settings.check_max)
        return

    await state.update_data(check_amount=minor)
    await state.set_state(CheckStates.target)
    await send(message, texts.CHECK_TARGET_PROMPT,
               reply_markup=simple_cancel_keyboard())


@router.message(CheckStates.target, F.text == texts.KB_CANCEL)
async def on_target_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(CheckStates.target, F.text)
async def on_check_target(message: Message, session: AsyncSession,
                          db_user: User, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    target: int | None = 0
    if raw not in {"0", "-", ""}:
        if not raw.lstrip("-").isdigit():
            await send(message, texts.CHECK_TARGET_INVALID)
            return
        target = int(raw)
        if target == db_user.id:
            await send(message, texts.CHECK_SELF)
            return

    data = await state.get_data()
    amount_minor = int(data.get("check_amount", 0))
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())

    outcome = await checks_service.create_check(
        session, creator_id=db_user.id, amount_minor=amount_minor,
        target_user_id=target or None,
        bot_username=settings.bot_username,
    )
    if not outcome.ok:
        template = getattr(texts, outcome.error_key or "CHECK_NO_FUNDS")
        await send(message, template, **(outcome.context or {}))
        return

    item = outcome.check
    await send(
        message, texts.CHECK_CREATED,
        amount=format_amount(item.amount_minor),
        target=str(item.target_user_id) if item.target_user_id else "все игроки",
        expires=format_dt(item.expires_at),
        url=outcome.url or "—",
    )


# --------------------------- активные чеки/отмена --------------------------

@router.callback_query(F.data == "check:list")
async def on_active_list(query: CallbackQuery, session: AsyncSession,
                         db_user: User) -> None:
    await answer(query)
    checks = await check_repo.active_checks(session, db_user.id)
    if not checks:
        await send(query.message, texts.CHECKS_ACTIVE_EMPTY)
        return
    from app.utils.format import render

    lines = [
        f"• {format_amount(c.amount_minor)} ★ — до {format_dt(c.expires_at)}"
        for c in checks
    ]
    plain, entities = render(texts.CHECKS_ACTIVE, items="\n".join(lines))
    try:
        await query.message.edit_text(
            plain, entities=entities,
            reply_markup=build_active_checks_keyboard(checks))
    except Exception:  # noqa: BLE001
        await query.message.answer(
            plain, entities=entities,
            reply_markup=build_active_checks_keyboard(checks))


@router.callback_query(F.data.startswith("check:cancel:"))
async def on_check_cancel_click(query: CallbackQuery, session: AsyncSession,
                                db_user: User) -> None:
    check_id = query.data.split(":")[2]
    outcome = await checks_service.cancel_check(
        session, creator_id=db_user.id, check_id=check_id
    )
    if not outcome.ok:
        template = getattr(texts, outcome.error_key or "CHECK_NOT_FOUND")
        await answer(query, template, alert=True)
        return
    await answer(query, texts.CHECK_CANCELLED)
    await on_active_list(query, session, db_user)

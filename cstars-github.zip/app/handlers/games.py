"""Игровой обработчик: панель игр, выбор исхода, ставки, броски, история.

Панель — одно сообщение, которое редактируется при смене вкладки/ставки
(как на референсе). Бросок выполняется официальной игрой Telegram; результат
считает сервис settlement, обработчик только рисует итог.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.games import GAMES, GAME_TAB_ORDER
from app.config.settings import settings
from app.finance import InsufficientFunds, get_balances
from app.handlers.states import BetStates, CustomBetStates, MenuStates
from app.games.custom import roll_custom
from app.games.engine import perform_roll
from app.keyboards.inline import (
    build_custom_modes_keyboard,
    build_dice_submenu,
    build_game_panel,
    build_modes_keyboard,
)
from app.keyboards.reply import main_keyboard, simple_cancel_keyboard
from app.models import User, Wallet
from app.repositories import game_repo
from app.services import settlement
from app.utils.ids import action_id as make_action_id
from app.utils.money import format_amount, parse_amount, to_minor
from app.utils.tg import answer, edit, edit_or_send, send

router = Router(name="games")

DEFAULT_BET_MINOR = to_minor(settings.bet_min)


# ------------------------------- панель игр --------------------------------

async def _state_data(state: FSMContext) -> dict:
    data = await state.get_data() if state else {}
    return data or {}


async def render_game_panel(
    message: Message,
    session: AsyncSession,
    user: User,
    state: FSMContext | None = None,
    *,
    edit_existing: bool = False,
) -> None:
    """Показать игровую панель (новое сообщение или редактирование)."""
    data = await _state_data(state)
    game_code = data.get("game_code", "dice")
    dice_count = int(data.get("dice_count", 1))
    bet_minor = int(data.get("bet_minor", DEFAULT_BET_MINOR))

    if data.get("bj"):
        # идёт раздача 21 Очко — любые переходы показывают руку, а не панель
        from app.handlers.blackjack import render_active_hand

        if await render_active_hand(message, session, user, state,
                                    edit_existing=edit_existing):
            return

    wallet = await session.get(Wallet, user.id)
    balance_minor = wallet.total if wallet else 0

    spec = GAMES.get(game_code, GAMES["dice"])
    text = _panel_text(game_code)
    markup = build_game_panel(
        game_code=game_code,
        bet_major=format_amount(bet_minor),
        balance_major=format_amount(balance_minor),
        dice_count=dice_count,
    )

    if edit_existing:
        ok = await edit(
            message, text, reply_markup=markup,
            bet=format_amount(bet_minor), balance=format_amount(balance_minor),
        )
        if ok:
            return
    sent = await send(
        message, text, reply_markup=markup,
        bet=format_amount(bet_minor), balance=format_amount(balance_minor),
    )
    if sent is not None and state is not None:
        # запоминаем панель, чтобы она обновлялась после бросков и ставок
        await state.update_data(panel_message_id=sent.message_id)


def _panel_text(game_code: str) -> str:
    """Текст панели: для 21 Очко и Crash — свой заголовок и подсказка."""
    if game_code == "blackjack":
        title, hint = texts.BJ_PANEL_TITLE, texts.BJ_PANEL_HINT
    elif game_code == "crash":
        title, hint = texts.CRASH_PANEL_TITLE, texts.CRASH_PANEL_HINT
    else:
        title, hint = texts.GAME_PANEL_TITLE, texts.GAME_PANEL_HINT
    return (
        f"{title}\n"
        f"{texts.GAME_PANEL_BET}\n"
        f"{texts.GAME_PANEL_BALANCE}\n"
        f"{hint}"
    )


async def _update_stored_panel(bot, chat_id: int, message_id: int | None,
                               session: AsyncSession, user: User,
                               state: FSMContext) -> None:
    """Обновить закреплённую панель после броска (баланс/ставка)."""
    if not message_id:
        return
    data = await _state_data(state)
    bet_minor = int(data.get("bet_minor", DEFAULT_BET_MINOR))
    game_code = data.get("game_code", "dice")
    dice_count = int(data.get("dice_count", 1))

    if data.get("bj"):
        # идёт раздача 21 Очко — обновляем руку, а не панель
        from app.handlers.blackjack import update_active_panel

        if await update_active_panel(bot, chat_id, message_id, session,
                                     user, state):
            return

    wallet = await session.get(Wallet, user.id)
    balance_minor = wallet.total if wallet else 0
    text = _panel_text(game_code)
    markup = build_game_panel(
        game_code=game_code,
        bet_major=format_amount(bet_minor),
        balance_major=format_amount(balance_minor),
        dice_count=dice_count,
    )
    from aiogram.exceptions import TelegramBadRequest

    from app.utils.format import render

    plain, entities = render(text, bet=format_amount(bet_minor),
                             balance=format_amount(balance_minor))
    try:
        await bot.edit_message_text(
            plain, chat_id=chat_id, message_id=message_id,
            entities=entities, reply_markup=markup,
        )
    except TelegramBadRequest:
        pass


# ---------------------------- выбор вкладки/режима --------------------------

@router.callback_query(F.data.startswith("game:tab:"))
async def on_game_tab(query: CallbackQuery, session: AsyncSession,
                      db_user: User, state: FSMContext) -> None:
    code = query.data.split(":")[2]
    if code not in GAMES:
        await answer(query)
        return
    await state.update_data(game_code=code)
    await answer(query)
    await render_game_panel(query.message, session, db_user, state,
                            edit_existing=True)


@router.callback_query(F.data.startswith("game:select:"))
async def on_game_select(query: CallbackQuery, session: AsyncSession,
                         db_user: User, state: FSMContext) -> None:
    code = query.data.split(":")[2]
    if code not in GAMES:
        await answer(query)
        return
    await state.update_data(game_code=code)
    await answer(query, f"Игра: {GAMES[code].title}")
    await render_game_panel(query.message, session, db_user, state,
                            edit_existing=True)


@router.callback_query(F.data.startswith("game:count:"))
async def on_dice_count(query: CallbackQuery, session: AsyncSession,
                        db_user: User, state: FSMContext) -> None:
    try:
        count = int(query.data.split(":")[2])
    except (IndexError, ValueError):
        count = 1
    count = max(1, min(3, count))
    await state.update_data(dice_count=count)
    await answer(query)
    await render_game_panel(query.message, session, db_user, state,
                            edit_existing=True)


@router.callback_query(F.data == "game:panel")
async def on_panel_back(query: CallbackQuery, session: AsyncSession,
                        db_user: User, state: FSMContext) -> None:
    await answer(query)
    await render_game_panel(query.message, session, db_user, state,
                            edit_existing=True)


@router.callback_query(F.data.startswith("game:sub:"))
async def on_dice_submenu(query: CallbackQuery, session: AsyncSession,
                          db_user: User, state: FSMContext) -> None:
    kind = query.data.split(":")[2]
    if kind not in {"total", "range"}:
        await answer(query)
        return
    data = await _state_data(state)
    dice_count = int(data.get("dice_count", 1))
    title = (
        texts.DICE_TOTAL_SUBMENU if kind == "total" else texts.DICE_RANGE_SUBMENU
    )
    await answer(query)
    markup = build_dice_submenu(kind, dice_count)
    from app.utils.format import render

    plain, entities = render(f"{title}\n{texts.GAME_PANEL_HINT}")
    try:
        await query.message.edit_text(plain, entities=entities,
                                      reply_markup=markup)
    except Exception:  # noqa: BLE001
        pass


# --------------------------------- ставка ----------------------------------

@router.callback_query(F.data == "game:edit")
async def on_edit_bet(query: CallbackQuery, state: FSMContext) -> None:
    await answer(query)
    await send(
        query.message, texts.BET_INPUT_PROMPT,
        reply_markup=simple_cancel_keyboard(),
        min=settings.bet_min, max=settings.bet_max,
    )
    await state.set_state(BetStates.entering)


@router.message(BetStates.entering, F.text == texts.KB_CANCEL)
async def on_bet_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(BetStates.entering, F.text)
async def on_bet_amount(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    minor = parse_amount(message.text or "")
    if minor is None:
        await send(message, texts.BET_INVALID,
                   min=settings.bet_min, max=settings.bet_max)
        return
    if minor < to_minor(settings.bet_min):
        await send(message, texts.BET_MIN_ERROR, min=settings.bet_min)
        return
    if minor > to_minor(settings.bet_max):
        await send(message, texts.BET_MAX_ERROR, max=settings.bet_max)
        return

    await state.update_data(bet_minor=minor)
    await state.set_state(MenuStates.main)
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())
    await _refresh_panel_after_bet(message, state)


async def _refresh_panel_after_bet(message: Message, state: FSMContext) -> None:
    """Перерисовать панель после изменения ставки."""
    from app.database.session import get_session_factory

    data = await state.get_data()
    panel_id = data.get("panel_message_id")
    user_id = message.from_user.id if message.from_user else 0
    async with get_session_factory()() as session:
        from app.repositories import user_repo

        user = await user_repo.get_user(session, user_id)
        if user is None:
            return
        if panel_id:
            await _update_stored_panel(
                message.bot, message.chat.id, panel_id, session, user, state
            )
        else:
            await render_game_panel(message, session, user, state)
        await session.commit()


# -------------------------------- исходы -----------------------------------

@router.callback_query(F.data.startswith("game:bet:"))
async def on_outcome(query: CallbackQuery, session: AsyncSession,
                     db_user: User, state: FSMContext) -> None:
    outcome_code = query.data.split(":", 2)[2]
    data = await _state_data(state)
    game_code = data.get("game_code", "dice")
    dice_count = int(data.get("dice_count", 1))
    bet_minor = int(data.get("bet_minor", DEFAULT_BET_MINOR))

    from app.config.games import outcome_by_code

    outcome = outcome_by_code(game_code, outcome_code, dice_count)
    if outcome is None:
        await answer(query, texts.BET_OUTCOME_UNAVAILABLE, alert=True)
        return

    spec = GAMES.get(game_code)
    if spec is None:
        await answer(query, texts.BET_OUTCOME_UNAVAILABLE, alert=True)
        return

    validation = settlement.validate_bet(
        stake_minor=bet_minor,
        outcome_code=outcome_code,
        game_code=game_code,
        dice_count=dice_count,
    )
    if not validation.ok:
        template = getattr(texts, validation.error or "ERR_GENERIC")
        await answer(query, template.format(**(validation.context or {})),
                     alert=True)
        return

    await answer(query)
    await _play_round(
        query.message, session, db_user, state,
        spec=spec, outcome=outcome, bet_minor=bet_minor,
        dice_count=dice_count, is_custom=False,
    )


async def _play_round(
    message: Message,
    session: AsyncSession,
    user: User,
    state: FSMContext,
    *,
    spec,
    outcome,
    bet_minor: int,
    dice_count: int,
    is_custom: bool,
) -> None:
    """Списание ставки → бросок → расчёт → отрисовка результата."""
    from datetime import datetime, timezone

    data = await _state_data(state)
    panel_id = data.get("panel_message_id")

    uid = make_action_id(
        user.id, spec.code, outcome.code, bet_minor, dice_count,
        datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f"),
    )

    try:
        round_id, bonus_spent, real_spent, duplicate = await settlement.start_round(
            session,
            user_id=user.id,
            game_code=spec.code,
            outcome_code=outcome.code,
            outcome_label=outcome.label,
            coefficient=outcome.coef,
            stake_minor=bet_minor,
            action_id=uid,
            is_custom=is_custom,
        )
    except InsufficientFunds:
        await send(message, texts.BET_NO_FUNDS)
        return

    if duplicate is not None:
        await send(message, texts.BET_LOCKED)
        return

    try:
        if is_custom:
            rolled = _custom_roll(spec, outcome)
        else:
            rolled = await perform_roll(
                message.bot, message.chat.id, spec, dice_count
            )
    except Exception:  # noqa: BLE001 — сбой Telegram API
        await settlement.void_round(
            session, user_id=user.id, round_id=round_id,
            stake_minor=bet_minor, bonus_spent=bonus_spent, action_id=uid,
        )
        await send(message, texts.ERR_GENERIC)
        return

    result = await settlement.finish_round(
        session,
        user_id=user.id,
        round_id=round_id,
        game_code=spec.code,
        outcome_code=outcome.code,
        outcome_label=outcome.label,
        coefficient=outcome.coef,
        stake_minor=bet_minor,
        bonus_spent=bonus_spent,
        roll=rolled,
        action_id=uid,
    )

    if result.won is None:
        template = texts.ROUND_VOID
        await send(
            message, template,
            balance=format_amount(result.balance_minor),
        )
    elif result.won:
        await send(
            message, texts.ROUND_WON,
            outcome=result.outcome_label or outcome.label,
            coef=outcome.coef or 0,
            bet=format_amount(bet_minor),
            win=format_amount(result.payout_minor),
            balance=format_amount(result.balance_minor),
        )
    else:
        await send(
            message, texts.ROUND_LOST,
            outcome=result.outcome_label or outcome.label,
            bet=format_amount(bet_minor),
            balance=format_amount(result.balance_minor),
        )

    await _update_stored_panel(
        message.bot, message.chat.id, panel_id, session, user, state
    )


def _custom_roll(spec, outcome):
    """Результат авторского режима в формате игрового движка."""
    from app.games.engine import RollResult

    raw = [
        {"code": outcome.code, "label": outcome.label,
         "coef": outcome.coef or 2.0, "weight": 1}
    ]
    # фактический исход выбирается сервером по весам всего режима
    from app.models import CustomGameMode

    chosen = roll_custom(getattr(spec, "_raw_outcomes", raw))
    result = RollResult(game_code="custom", values=[])
    if chosen is None:
        result.is_void = True
        return result
    code, label, _coef = chosen
    result.outcome_code = code
    result.outcome_label = label
    return result


# ------------------------------ авторские режимы ---------------------------

@router.callback_query(F.data.startswith("custom:play:"))
async def on_custom_play(query: CallbackQuery, session: AsyncSession,
                         db_user: User, state: FSMContext) -> None:
    code = query.data.split(":")[2]
    mode = await game_repo.get_custom_mode(session, code)
    if mode is None or not mode.enabled:
        await answer(query, texts.CUSTOM_MODE_ERROR, alert=True)
        return
    await state.update_data(game_code=f"custom:{code}", custom_code=code)
    await answer(query)
    await send(
        query.message, texts.BET_INPUT_PROMPT,
        reply_markup=simple_cancel_keyboard(),
        min=settings.bet_min, max=settings.bet_max,
    )
    await state.set_state(CustomBetStates.entering)


@router.message(CustomBetStates.entering, F.text == texts.KB_CANCEL)
async def on_custom_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(CustomBetStates.entering, F.text)
async def on_custom_bet(message: Message, session: AsyncSession,
                        db_user: User, state: FSMContext) -> None:
    minor = parse_amount(message.text or "")
    if minor is None or minor < to_minor(settings.bet_min) \
            or minor > to_minor(settings.bet_max):
        await send(message, texts.BET_INVALID,
                   min=settings.bet_min, max=settings.bet_max)
        return

    data = await state.get_data()
    code = data.get("custom_code")
    mode = await game_repo.get_custom_mode(session, code or "")
    if mode is None:
        await state.clear()
        await send(message, texts.CUSTOM_MODE_ERROR)
        return

    await state.set_state(MenuStates.main)
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())
    await _play_custom_round(message, session, db_user, state, mode, minor)


async def _play_custom_round(
    message: Message, session: AsyncSession, user: User,
    state: FSMContext, mode, bet_minor: int,
) -> None:
    """Раунд авторского режима: серверный CSPRNG, ставка списывается так же."""
    from datetime import datetime, timezone

    from app.games.engine import RollResult

    outcomes = mode.outcomes or []
    if not outcomes:
        await send(message, texts.CUSTOM_MODE_ERROR)
        return

    first = outcomes[0]
    uid = make_action_id(
        user.id, mode.code, bet_minor,
        datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f"),
    )

    class _Spec:
        code = f"custom:{mode.code}"
        _raw_outcomes = outcomes

    class _Outcome:
        code = str(first.get("code", "win"))
        label = str(first.get("label", "Исход"))
        coef = float(first.get("coef", 2.0))

    try:
        round_id, bonus_spent, _real, duplicate = await settlement.start_round(
            session, user_id=user.id, game_code=_Spec.code,
            outcome_code=_Outcome.code, outcome_label=_Outcome.label,
            coefficient=_Outcome.coef, stake_minor=bet_minor, action_id=uid,
            is_custom=True,
        )
    except InsufficientFunds:
        await send(message, texts.BET_NO_FUNDS)
        return
    if duplicate is not None:
        await send(message, texts.BET_LOCKED)
        return

    chosen = roll_custom(outcomes)
    result = RollResult(game_code=_Spec.code, values=[])
    if chosen is None:
        result.is_void = True
    else:
        result.outcome_code, result.outcome_label = chosen[0], chosen[1]

    # проверяем совпадение с поставленным исходом
    won = (not result.is_void) and result.outcome_code == _Outcome.code
    if result.is_void:
        won_value = None
    else:
        won_value = bool(won)

    payout_minor = 0
    if won_value and _Outcome.coef:
        from app.finance import credit
        from app.models.enums import TransactionType

        payout_minor = round(bet_minor * _Outcome.coef)
        await credit(
            session, user_id=user.id, amount_minor=payout_minor,
            kind=TransactionType.PAYOUT,
            key=f"round:{uid}#payout",
            description=f"Выигрыш: {result.outcome_label}",
            game_round_id=round_id,
        )

    from app.models import GameRound
    from app.models.enums import RoundStatus

    round_obj = await session.get(GameRound, round_id)
    status = (RoundStatus.WON if won_value else
              RoundStatus.LOST if won_value is False else RoundStatus.VOID)
    if round_obj is not None:
        await game_repo.finish_round(
            session, round_obj,
            outcome_code=result.outcome_code,
            outcome_label=result.outcome_label,
            multiplier=_Outcome.coef, payout=payout_minor,
            bonus_spent=bonus_spent, status=status,
        )
    from app.services import settlement as settlement_service

    await settlement_service._update_stats(
        session, user_id=user.id, stake_minor=bet_minor
    )
    await settlement_service.referral_service_accrue(
        session, user_id=user.id, round_id=round_id,
        stake_minor=bet_minor, payout_minor=payout_minor,
        bonus_spent=bonus_spent,
    )

    wallet = await session.get(Wallet, user.id)
    balance_minor = wallet.total if wallet else 0

    if won_value is None:
        await send(message, texts.ROUND_VOID,
                   balance=format_amount(balance_minor))
    elif won_value:
        await send(
            message, texts.ROUND_WON,
            outcome=result.outcome_label or _Outcome.label,
            coef=_Outcome.coef, bet=format_amount(bet_minor),
            win=format_amount(payout_minor),
            balance=format_amount(balance_minor),
        )
    else:
        await send(
            message, texts.ROUND_LOST,
            outcome=result.outcome_label or _Outcome.label,
            bet=format_amount(bet_minor),
            balance=format_amount(balance_minor),
        )


# --------------------------- режимы и история ------------------------------

async def render_modes(message: Message, session: AsyncSession, user: User,
                       state: FSMContext | None) -> None:
    data = await _state_data(state)
    active = data.get("game_code", "dice")
    markup = build_modes_keyboard(active)
    await edit_or_send(message, texts.MODES_TITLE, reply_markup=markup)


async def render_custom_modes(message: Message, session: AsyncSession) -> None:
    modes = await game_repo.list_custom_modes(session)
    if not modes:
        await edit_or_send(message, texts.CUSTOM_MODES_EMPTY)
        return
    markup = build_custom_modes_keyboard(modes)
    await edit_or_send(message, texts.MODES_TITLE, reply_markup=markup)


@router.callback_query(F.data == "modes:history")
async def on_history(query: CallbackQuery, session: AsyncSession,
                     db_user: User) -> None:
    rounds = await game_repo.user_rounds(session, db_user.id, limit=10)
    await answer(query)
    if not rounds:
        await send(query.message, texts.MODES_HISTORY_EMPTY)
        return
    from app.models.enums import RoundStatus

    marks = {RoundStatus.WON.value: "✅", RoundStatus.LOST.value: "❌",
             RoundStatus.VOID.value: "↩️"}
    lines: list[str] = []
    for item in rounds:
        mark = marks.get(item.status, "•")
        label = item.outcome_label or item.game_code
        lines.append(
            f"{mark} {label} — {format_amount(item.stake)} ★ "
            f"→ {format_amount(item.payout)} ★"
        )
    await send(query.message, texts.MODES_HISTORY, items="\n".join(lines))

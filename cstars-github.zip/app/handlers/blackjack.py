"""21 Очко: раздача, «взять ещё» / «хватит», расчёт против дилера.

Раунд живёт в FSM-данных под ключом ``bj``: колода, руки, идентификатор
раунда ставки и уже списанные средства. Пока раунд открыт, любая отрисовка
игровой панели показывает руку (см. render_active_hand / update_active_panel),
чтобы игрок не потерял начатую раздачу при переходах по меню.

Ставка списывается один раз при раздаче (settlement.start_round), выигрыш
начисляется при завершении (settlement.finish_round): победа ×2, ничья —
возврат ставки, проигрыш — без начисления.
"""

from __future__ import annotations

from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.games import outcome_by_code
from app.finance import InsufficientFunds
from app.games import blackjack as bj
from app.games.engine import RollResult
from app.keyboards.inline import (
    build_blackjack_keyboard,
    build_blackjack_result_keyboard,
)
from app.models import User, Wallet
from app.services import settlement
from app.utils.format import render
from app.utils.ids import action_id as make_action_id
from app.utils.money import format_amount
from app.utils.tg import answer, edit, send

router = Router(name="blackjack")

# коэффициент победы (задан исходом «play» в config/games.py)
BJ_OUTCOME_CODE = "play"


# --------------------------- отрисовка раздачи ------------------------------

async def _balance(session: AsyncSession, user: User) -> int:
    wallet = await session.get(Wallet, user.id)
    return wallet.total if wallet else 0


def hand_view(hand: dict, balance_minor: int) -> tuple[str, dict, InlineKeyboardMarkup]:
    """Текст, контекст и клавиатура активной раздачи."""
    dealer_visible = f"{bj.format_card(hand['dealer'][0])} + ?"
    ctx = {
        "player": bj.format_hand(hand["player"]),
        "player_value": bj.hand_value(hand["player"]),
        "dealer": dealer_visible,
        "bet": format_amount(int(hand["bet_minor"])),
        "balance": format_amount(balance_minor),
    }
    return texts.BJ_HAND, ctx, build_blackjack_keyboard()


async def render_active_hand(
    message: Message,
    session: AsyncSession,
    user: User,
    state: FSMContext,
    *,
    edit_existing: bool = False,
) -> bool:
    """Показать руку вместо панели, пока раунд не закрыт. True — показано."""
    data = await state.get_data() if state else {}
    hand = (data or {}).get("bj")
    if not hand:
        return False
    text, ctx, markup = hand_view(hand, await _balance(session, user))
    if edit_existing and await edit(message, text, reply_markup=markup, **ctx):
        return True
    sent = await send(message, text, reply_markup=markup, **ctx)
    if sent is not None and state is not None:
        await state.update_data(panel_message_id=sent.message_id)
    return True


async def update_active_panel(
    bot,
    chat_id: int,
    message_id: int | None,
    session: AsyncSession,
    user: User,
    state: FSMContext,
) -> bool:
    """Обновить закреплённую панель, пока раунд открыт. True — обновлено."""
    if not message_id:
        return False
    data = await state.get_data() if state else {}
    hand = (data or {}).get("bj")
    if not hand:
        return False
    text, ctx, markup = hand_view(hand, await _balance(session, user))
    plain, entities = render(text, **ctx)
    from aiogram.exceptions import TelegramBadRequest

    try:
        await bot.edit_message_text(
            plain, chat_id=chat_id, message_id=message_id,
            entities=entities, reply_markup=markup,
        )
    except TelegramBadRequest:
        pass
    return True


# -------------------------------- раздача ----------------------------------

@router.callback_query(F.data == "game:bj:start")
async def on_deal(query: CallbackQuery, session: AsyncSession,
                  db_user: User, state: FSMContext) -> None:
    data = await state.get_data()
    if data.get("bj"):
        await answer(query, texts.BJ_ALREADY, alert=True)
        return

    bet_minor = int(data.get("bet_minor", 0) or 0)
    if not bet_minor:
        from app.config.settings import settings
        from app.utils.money import to_minor

        bet_minor = to_minor(settings.bet_min)

    outcome = outcome_by_code("blackjack", BJ_OUTCOME_CODE)
    if outcome is None:
        await answer(query, texts.BET_OUTCOME_UNAVAILABLE, alert=True)
        return

    validation = settlement.validate_bet(
        stake_minor=bet_minor, outcome_code=outcome.code,
        game_code="blackjack",
    )
    if not validation.ok:
        template = getattr(texts, validation.error or "ERR_GENERIC")
        await answer(query, template.format(**(validation.context or {})),
                     alert=True)
        return

    uid = make_action_id(
        db_user.id, "blackjack", outcome.code, bet_minor,
        datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f"),
    )
    try:
        round_id, bonus_spent, _real, duplicate = await settlement.start_round(
            session,
            user_id=db_user.id,
            game_code="blackjack",
            outcome_code=outcome.code,
            outcome_label=outcome.label,
            coefficient=outcome.coef,
            stake_minor=bet_minor,
            action_id=uid,
        )
    except InsufficientFunds:
        await answer(query, texts.BET_NO_FUNDS, alert=True)
        return
    if duplicate is not None:
        await answer(query, texts.BET_LOCKED, alert=True)
        return

    deck = bj.new_deck()
    player, dealer = bj.initial_hands(deck)
    hand = {
        "deck": deck,
        "player": player,
        "dealer": dealer,
        "round_id": round_id,
        "bonus_spent": bonus_spent,
        "action_id": uid,
        "bet_minor": bet_minor,
    }
    await state.update_data(game_code="blackjack", bj=hand)
    await answer(query)

    # натуральный блэкджек (у кого-то из сторон) — раунд завершается сразу
    if bj.is_blackjack(player) or bj.is_blackjack(dealer):
        await _settle(query, session, db_user, state, hand)
        return
    await _render_hand(query, session, db_user, state, hand)


async def _render_hand(query: CallbackQuery, session: AsyncSession,
                       user: User, state: FSMContext, hand: dict) -> None:
    text, ctx, markup = hand_view(hand, await _balance(session, user))
    if not await edit(query.message, text, reply_markup=markup, **ctx):
        sent = await send(query.message, text, reply_markup=markup, **ctx)
        if sent is not None:
            await state.update_data(panel_message_id=sent.message_id)


# ------------------------------ ход игрока ---------------------------------

@router.callback_query(F.data == "game:bj:hit")
async def on_hit(query: CallbackQuery, session: AsyncSession,
                 db_user: User, state: FSMContext) -> None:
    data = await state.get_data()
    hand = data.get("bj")
    if not hand:
        await answer(query, texts.BJ_NO_GAME, alert=True)
        return

    if not hand["deck"]:
        # колода исчерпана — защитный возврат ставки
        await _settle(query, session, db_user, state, hand, outcome="void")
        return

    hand["player"].append(bj.draw(hand["deck"]))
    value = bj.hand_value(hand["player"])
    await answer(query)

    if value > 21:
        # перебор: дилер не играет
        await _settle(query, session, db_user, state, hand, outcome="lose")
        return
    if value == 21:
        # на 21 дальше брать нельзя — автоматически раскрываем дилера
        await _settle(query, session, db_user, state, hand)
        return

    await state.update_data(bj=hand)
    await _render_hand(query, session, db_user, state, hand)


@router.callback_query(F.data == "game:bj:stand")
async def on_stand(query: CallbackQuery, session: AsyncSession,
                   db_user: User, state: FSMContext) -> None:
    data = await state.get_data()
    hand = data.get("bj")
    if not hand:
        await answer(query, texts.BJ_NO_GAME, alert=True)
        return
    await answer(query)
    await _settle(query, session, db_user, state, hand)


# -------------------------------- расчёт -----------------------------------

async def _settle(
    query: CallbackQuery,
    session: AsyncSession,
    user: User,
    state: FSMContext,
    hand: dict,
    *,
    outcome: str | None = None,
) -> None:
    """Дилер доигрывает (если нужно), раунд считается и закрывается."""
    deck, player, dealer = hand["deck"], hand["player"], hand["dealer"]

    if outcome is None:
        bj.dealer_play(deck, dealer)
        outcome = bj.decide(player, dealer)

    player_value = bj.hand_value(player)
    dealer_value = bj.hand_value(dealer)

    if outcome == "void":
        roll = RollResult(game_code="blackjack", values=[], is_void=True)
    else:
        labels = {"win": "Победа", "push": "Ничья", "lose": "Поражение"}
        roll = RollResult(
            game_code="blackjack",
            values=[player_value, dealer_value],
            outcome_code=outcome,
            outcome_label=labels.get(outcome),
        )

    outcome_cfg = outcome_by_code("blackjack", BJ_OUTCOME_CODE)
    result = await settlement.finish_round(
        session,
        user_id=user.id,
        round_id=hand["round_id"],
        game_code="blackjack",
        outcome_code=BJ_OUTCOME_CODE,
        outcome_label=outcome_cfg.label if outcome_cfg else "21 Очко",
        coefficient=outcome_cfg.coef if outcome_cfg else 2.0,
        stake_minor=int(hand["bet_minor"]),
        bonus_spent=int(hand["bonus_spent"]),
        roll=roll,
        action_id=hand["action_id"],
    )
    # раунд закрыт: панель снова доступна
    await state.update_data(bj=None)

    if outcome == "push":
        template = texts.BJ_PUSH
    elif outcome == "win":
        template = texts.BJ_WIN
    elif outcome == "lose" and player_value > 21:
        template = texts.BJ_BUST
    else:
        template = texts.BJ_LOSE

    ctx = {
        "player": bj.format_hand(player),
        "player_value": player_value,
        "dealer": bj.format_hand(dealer),
        "dealer_value": dealer_value,
        "bet": format_amount(int(hand["bet_minor"])),
        "win": format_amount(result.payout_minor),
        "balance": format_amount(result.balance_minor),
    }
    markup = build_blackjack_result_keyboard()
    if not await edit(query.message, template, reply_markup=markup, **ctx):
        await send(query.message, template, reply_markup=markup, **ctx)


__all__ = ["router", "render_active_hand", "update_active_panel"]

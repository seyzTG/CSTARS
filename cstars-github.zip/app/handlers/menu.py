"""Главное меню и единый диспетчер разделов (кнопка «Назад»)."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.handlers.states import MenuStates
from app.keyboards import build_menu_keyboard, main_keyboard
from app.models import User
from app.utils.tg import edit_or_send, send

router = Router(name="menu")

# разделы, которые умеет рисовать диспетчер
SECTIONS = {
    "menu": "menu",
    "profile": "profile",
    "balance": "balance",
    "deposit": "deposit",
    "withdraw": "withdraw",
    "checks": "checks",
    "check:types": "check_types",
    "referral": "referral",
    "referral:details": "referral_details",
    "daily": "daily",
    "cashback": "cashback",
    "cashback:details": "cashback_details",
    "privacy": "privacy",
    "info": "info",
    "rules": "rules",
    "modes": "modes",
    "custom": "custom_modes",
    "game": "game",
}


async def render_section(
    message: Message,
    target: str,
    session: AsyncSession,
    user: User,
    state: FSMContext | None = None,
) -> None:
    """Отрисовать раздел по имени. «Назад» ведёт ровно туда, откуда пришли."""
    key = SECTIONS.get(target)

    if key == "menu":
        await edit_or_send(
            message, texts.MENU, bot=texts.BOT_NAME, channel=texts.CHANNEL_URL,
            reply_markup=build_menu_keyboard(),
        )
    elif key == "profile":
        from app.handlers.profile import render_profile

        await render_profile(message, session, user)
    elif key == "balance":
        from app.handlers.balance import render_balance

        await render_balance(message, session, user)
    elif key == "deposit":
        from app.handlers.balance import render_deposit_menu

        await render_deposit_menu(message)
    elif key == "withdraw":
        from app.handlers.balance import render_withdraw_menu

        await render_withdraw_menu(message)
    elif key == "checks":
        from app.handlers.checks import render_checks_menu

        await render_checks_menu(message)
    elif key == "check_types":
        from app.handlers.checks import render_check_types

        await render_check_types(message)
    elif key == "referral":
        from app.handlers.referral import render_referral

        await render_referral(message, session, user)
    elif key == "referral_details":
        from app.handlers.referral import render_referral_details

        await render_referral_details(message, session, user)
    elif key == "daily":
        from app.handlers.bonuses import render_daily

        await render_daily(message, session, user)
    elif key == "cashback":
        from app.handlers.bonuses import render_cashback

        await render_cashback(message, session, user)
    elif key == "cashback_details":
        from app.handlers.bonuses import render_cashback_details

        await render_cashback_details(message)
    elif key == "privacy":
        from app.handlers.profile import render_privacy

        await render_privacy(message, session, user)
    elif key == "info":
        from app.handlers.info import render_info

        await render_info(message)
    elif key == "rules":
        from app.handlers.info import render_rules

        await render_rules(message)
    elif key == "modes":
        from app.handlers.games import render_modes

        await render_modes(message, session, user, state)
    elif key == "custom_modes":
        from app.handlers.games import render_custom_modes

        await render_custom_modes(message, session)
    elif key == "game":
        from app.handlers.games import render_game_panel

        await render_game_panel(message, session, user, state)
    else:
        await edit_or_send(message, texts.MENU, bot=texts.BOT_NAME,
                           channel=texts.CHANNEL_URL,
                           reply_markup=build_menu_keyboard())

    if state is not None:
        await state.update_data(section=target or "menu")


# ------------------------- reply-кнопки главного меню -----------------------

@router.message(F.text == texts.KB_MENU)
async def on_menu_button(
    message: Message, session: AsyncSession, db_user: User, state: FSMContext
) -> None:
    await render_section(message, "menu", session, db_user, state)
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(F.text == texts.KB_PROFILE)
async def on_profile_button(
    message: Message, session: AsyncSession, db_user: User, state: FSMContext
) -> None:
    from app.handlers.profile import render_profile

    await render_profile(message, session, db_user)
    await state.update_data(section="profile")


@router.message(F.text == texts.KB_BALANCE)
async def on_balance_button(
    message: Message, session: AsyncSession, db_user: User, state: FSMContext
) -> None:
    from app.handlers.balance import render_balance

    await render_balance(message, session, db_user)
    await state.update_data(section="balance")


@router.message(F.text == texts.KB_PLAY)
async def on_play_button(
    message: Message, session: AsyncSession, db_user: User, state: FSMContext
) -> None:
    from app.handlers.games import render_game_panel

    await render_game_panel(message, session, db_user, state)
    await state.update_data(section="game")


# --------------------------- навигация «Назад» -----------------------------

@router.callback_query(F.data.startswith("nav:"))
async def on_nav(query: CallbackQuery, session: AsyncSession, db_user: User,
                 state: FSMContext) -> None:
    target = query.data.split(":", 1)[1] if ":" in query.data else "menu"
    await query.answer()
    await render_section(query.message, target, session, db_user, state)

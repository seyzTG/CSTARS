"""Партнёрская программа: ссылка, статистика, детали, выплата вознаграждений."""

from __future__ import annotations

from urllib.parse import quote

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.settings import settings
from app.keyboards.inline import (
    build_referral_details_keyboard,
    build_referral_keyboard,
)
from app.models import User
from app.services import referral as ref_service
from app.utils.money import format_amount
from app.utils.tg import answer, edit_or_send, send

router = Router(name="referral")


async def render_referral(
    message: Message, session: AsyncSession, user: User
) -> None:
    stats = await ref_service.stats(session, user.id)
    link = ref_service.invite_link(settings.bot_username, user.referral_token)
    markup = build_referral_keyboard(link)
    await edit_or_send(
        message, texts.REF_MAIN, reply_markup=markup,
        percent=settings.referral_percent, link=link,
        invited=stats.invited,
        earned=format_amount(stats.earned_minor),
        pending=format_amount(stats.pending_minor),
    )


async def render_referral_details(
    message: Message, session: AsyncSession, user: User
) -> None:
    percent = settings.referral_percent
    daily, monthly = ref_service.scale_example(5000, percent)
    daily10, monthly10 = ref_service.scale_example(10 * 2000, percent)
    await edit_or_send(
        message, texts.REF_DETAILS,
        reply_markup=build_referral_details_keyboard(),
        percent=percent, formula=ref_service.formula_text(),
        daily=daily, monthly=monthly,
        daily10=daily10, monthly10=monthly10,
    )


@router.callback_query(F.data == "ref:details")
async def on_details(query: CallbackQuery, session: AsyncSession,
                     db_user: User) -> None:
    await answer(query)
    await render_referral_details(query.message, session, db_user)


@router.callback_query(F.data == "ref:claim")
async def on_claim(query: CallbackQuery, session: AsyncSession,
                   db_user: User) -> None:
    outcome = await ref_service.claim(session, db_user.id)
    if not outcome.ok:
        await answer(query, texts.REF_CLAIM_NOTHING, alert=True)
        return
    await answer(query, texts.REF_CLAIMED.format(
        amount=format_amount(outcome.amount_minor)))
    await render_referral(query.message, session, db_user)


@router.message(F.text == texts.BTN_PARTNER)
async def on_partner_button(message: Message, session: AsyncSession,
                            db_user: User) -> None:
    await render_referral(message, session, db_user)

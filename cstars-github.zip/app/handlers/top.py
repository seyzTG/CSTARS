"""Топ игроков: периоды, медали, пагинация, учёт приватности."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.keyboards.inline import build_top_keyboard
from app.models import User
from app.repositories import social_repo
from app.utils.money import format_amount
from app.utils.tg import answer, edit_or_send, send

router = Router(name="top")

PERIOD_TITLES = {
    "all": "За всё время",
    "today": "За сегодня",
    "yesterday": "Вчера",
    "week": "Неделя",
    "month": "Месяц",
}
MEDALS = ("🥇", "🥈", "🥉")


async def render_top(message: Message, session: AsyncSession,
                     user: User, period: str = "all") -> None:
    entries = await social_repo.leaderboard(session, period, limit=10)
    lines: list[str] = []
    for index, (_uid, name, value) in enumerate(entries, start=1):
        rank = MEDALS[index - 1] if index <= 3 else f"{index}."
        lines.append(texts.TOP_LINE.format(
            rank=rank, name=name, value=format_amount(value)))

    if not lines:
        body = texts.TOP_EMPTY
    else:
        body = f"{texts.TOP_TITLE}\n\n" + "\n".join(lines)

    # своё место в рейтинге
    my_value = await social_repo.user_top_value(session, user.id, period)
    if my_value > 0:
        place = await _my_place(session, user.id, period, my_value)
        body += "\n\n" + texts.TOP_ME.format(
            place=place, value=format_amount(my_value))

    markup = build_top_keyboard(period)
    await edit_or_send(message, body, reply_markup=markup)


async def _my_place(session: AsyncSession, user_id: int, period: str,
                    my_value: int) -> int:
    """Место пользователя с учётом одинаковых результатов (одинаковое значение = одно место)."""
    better = await social_repo.leaderboard(session, period, limit=100)
    place = 1
    for uid, _name, value in better:
        if uid == user_id:
            continue
        if value > my_value:
            place += 1
    return place


@router.callback_query(F.data.startswith("top:"))
async def on_top_period(query: CallbackQuery, session: AsyncSession,
                        db_user: User) -> None:
    period = query.data.split(":")[1]
    if period not in PERIOD_TITLES:
        period = "all"
    await answer(query, PERIOD_TITLES[period])
    await render_top(query.message, session, db_user, period)

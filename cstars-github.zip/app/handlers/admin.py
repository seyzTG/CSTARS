"""Админ-панель: команды и кнопки управления.

Права проверяются сервером (AdminAccessMiddleware → ADMIN_IDS / is_admin),
а не наличием кнопки. Каждое финансовое действие пишется в audit-лог.
"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.config.games import GAMES
from app.handlers.states import MenuStates
from app.keyboards.inline import build_admin_withdrawal_keyboard
from app.middlewares.admin import is_admin
from app.models import User, Withdrawal
from app.models.enums import AdminActionType, WithdrawalStatus
from app.repositories import finance_repo, game_repo, user_repo
from app.services import admin as admin_service
from app.services import withdrawals as wd_service
from app.utils.money import format_amount, to_minor
from app.utils.tg import answer, send

router = Router(name="admin")


@router.message(Command("admin"))
async def cmd_admin(message: Message, session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        await send(message, texts.ERR_ACCESS_DENIED)
        return
    stats = await admin_service.stats(session)
    await send(
        message, texts.ADMIN_STATS,
        users=stats["users"], active=stats["active"],
        deposited=format_amount(stats["deposited"]),
        withdrawn=format_amount(stats["withdrawn"]),
        turnover=format_amount(stats["turnover"]),
        profit=format_amount(stats["profit"]),
        pending_wd=stats["pending_wd"],
    )
    await message.answer(
        "Команды: /wd — заявки, /user <id>, /block <id>, /unblock <id>, "
        "/bonus <id> <сумма>, /coef <игра> <исход> <коэф>, /coeflist, "
        "/modes, /audit, /errors, /stats"
    )


@router.message(Command("stats"))
async def cmd_stats(message: Message, session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    stats = await admin_service.stats(session)
    await send(
        message, texts.ADMIN_STATS,
        users=stats["users"], active=stats["active"],
        deposited=format_amount(stats["deposited"]),
        withdrawn=format_amount(stats["withdrawn"]),
        turnover=format_amount(stats["turnover"]),
        profit=format_amount(stats["profit"]),
        pending_wd=stats["pending_wd"],
    )


@router.message(Command("wd"))
async def cmd_withdrawals(message: Message, session: AsyncSession,
                          db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    items = await finance_repo.pending_withdrawals(session, limit=20)
    if not items:
        await send(message, "Очередь заявок пуста.")
        return
    for item in items:
        await message.answer(
            f"Заявка {item.id[:8]} — {format_amount(item.amount_minor)} ★ "
            f"({item.method}), пользователь {item.user_id}, "
            f"комиссия {format_amount(item.commission_minor)} ★",
            reply_markup=build_admin_withdrawal_keyboard(item.id),
        )


@router.callback_query(F.data.startswith("adm:wd:"))
async def on_withdraw_decision(query: CallbackQuery, session: AsyncSession,
                               db_user: User) -> None:
    if not is_admin(db_user, query.from_user.id):
        await answer(query, texts.ERR_ACCESS_DENIED, alert=True)
        return
    _, _, action, wid = query.data.split(":", 3)

    if action == "pay":
        result = await wd_service.approve(
            session, wid=wid, admin_id=query.from_user.id
        )
        if not result.ok:
            await answer(query, "Заявка уже обработана.", alert=True)
            return
        await admin_service.audit(
            session, admin_id=query.from_user.id,
            action=AdminActionType.APPROVE_WITHDRAWAL,
            target_user_id=result.withdrawal.user_id,
            payload={"wid": wid, "amount": result.withdrawal.amount_minor},
        )
        await answer(query, texts.ADMIN_WITHDRAW_APPROVED.format(wid=wid[:8]))
        await _notify_user(query, result.withdrawal, "✅ Заявка подтверждена, средства отправлены.")
    elif action == "reject":
        result = await wd_service.reject(
            session, wid=wid, admin_id=query.from_user.id,
            comment="Отклонено администратором",
        )
        if not result.ok:
            await answer(query, "Заявка уже обработана.", alert=True)
            return
        await admin_service.audit(
            session, admin_id=query.from_user.id,
            action=AdminActionType.REJECT_WITHDRAWAL,
            target_user_id=result.withdrawal.user_id,
            payload={"wid": wid, "amount": result.withdrawal.amount_minor},
        )
        await answer(query, texts.ADMIN_WITHDRAW_REJECTED.format(wid=wid[:8]))
        await _notify_user(query, result.withdrawal,
                           "❌ Заявка отклонена, средства возвращены на баланс.")


async def _notify_user(query: CallbackQuery, item: Withdrawal, text: str) -> None:
    try:
        await query.message.bot.send_message(
            item.user_id, f"{text}\nID заявки: {item.id[:8]}"
        )
    except Exception:  # noqa: BLE001
        pass
    item.user_notified = True


@router.message(Command("user"))
async def cmd_user(message: Message, command: CommandObject,
                   session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    args = (command.args or "").split()
    if not args or not args[0].lstrip("-").isdigit():
        await send(message, "Использование: /user <telegram_id>")
        return
    user = await user_repo.get_user(session, int(args[0]))
    if user is None:
        await send(message, "Пользователь не найден.")
        return
    from app.services import users as users_service

    profile = await users_service.load_profile(session, user)
    await send(
        message, texts.ADMIN_USER,
        name=profile.name, user_id=profile.user_id,
        balance=format_amount(profile.balance_minor - profile.bonus_minor),
        bonus=format_amount(profile.bonus_minor),
        deposited=format_amount(profile.deposited_minor),
        withdrawn=format_amount(profile.withdrawn_minor),
        turnover=format_amount(profile.turnover_minor),
        games=profile.games_played,
        status=("заблокирован" if user.is_blocked else "активен"),
    )


@router.message(Command("block"))
async def cmd_block(message: Message, command: CommandObject,
                    session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    args = (command.args or "").split()
    if not args or not args[0].lstrip("-").isdigit():
        await send(message, "Использование: /block <telegram_id>")
        return
    ok = await admin_service.set_blocked(
        session, admin_id=message.from_user.id,
        user_id=int(args[0]), blocked=True,
    )
    await send(message, "Игрок заблокирован." if ok else "Игрок не найден.")


@router.message(Command("unblock"))
async def cmd_unblock(message: Message, command: CommandObject,
                      session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    args = (command.args or "").split()
    if not args or not args[0].lstrip("-").isdigit():
        await send(message, "Использование: /unblock <telegram_id>")
        return
    ok = await admin_service.set_blocked(
        session, admin_id=message.from_user.id,
        user_id=int(args[0]), blocked=False,
    )
    await send(message, "Игрок разблокирован." if ok else "Игрок не найден.")


@router.message(Command("bonus"))
async def cmd_bonus(message: Message, command: CommandObject,
                    session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    args = (command.args or "").split()
    if len(args) < 2 or not args[0].isdigit():
        await send(message, "Использование: /bonus <telegram_id> <сумма>")
        return
    ok = await admin_service.grant_bonus(
        session, admin_id=message.from_user.id,
        user_id=int(args[0]), amount_minor=to_minor(float(args[1])),
    )
    await send(message, "Бонус начислен." if ok else "Не удалось начислить.")


@router.message(Command("coef"))
async def cmd_coef(message: Message, command: CommandObject,
                   session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    args = (command.args or "").split()
    if len(args) < 3:
        await send(message, "Использование: /coef <game> <outcome> <value>\n"
                            "Игры: " + ", ".join(GAMES))
        return
    game_code, outcome_code, value = args[0], args[1], args[2]
    try:
        number = float(value)
    except ValueError:
        await send(message, "Коэффициент должен быть числом.")
        return
    ok = await admin_service.set_outcome_coef(
        session, admin_id=message.from_user.id, game_code=game_code,
        outcome_code=outcome_code, value=number,
    )
    await send(message, f"Коэффициент обновлён: {game_code}.{outcome_code} ×{number:g}"
               if ok else "Не удалось обновить коэффициент.")


@router.message(Command("coeflist"))
async def cmd_coeflist(message: Message, session: AsyncSession,
                       db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    overrides = await admin_service.coefficient_overrides(session)
    if not overrides:
        await send(message, "Переопределений коэффициентов нет.")
        return
    lines = []
    for game, values in overrides.items():
        for outcome, coef in values.items():
            lines.append(f"• {game}.{outcome} — ×{coef:g}")
    await send(message, "<b>Коэффициенты (переопределения)</b>\n" + "\n".join(lines))


@router.message(Command("modes"))
async def cmd_modes(message: Message, session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    modes = await game_repo.list_custom_modes(session, enabled_only=False)
    if not modes:
        await send(message, "Авторских режимов нет.\n"
                            "Добавление: /addmode <code> | <название> | "
                            '[{"code":"a","label":"A","coef":2,"weight":1}, ...]')
        return
    lines = [f"• {m.code} — {m.title} ({'вкл' if m.enabled else 'выкл'}, "
             f"исходов: {len(m.outcomes or [])})" for m in modes]
    await send(message, "<b>Авторские режимы</b>\n" + "\n".join(lines))


@router.message(Command("addmode"))
async def cmd_addmode(message: Message, command: CommandObject,
                      session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    raw = (command.args or "")
    if "|" not in raw:
        await send(message,
                   'Использование: /addmode <code> | <название> | '
                   '[{"code":"a","label":"Вариант А","coef":2,"weight":1}]')
        return
    code, title, payload = [p.strip() for p in raw.split("|", 2)]
    import json

    try:
        outcomes = json.loads(payload)
        assert isinstance(outcomes, list) and outcomes
    except Exception:  # noqa: BLE001
        await send(message, "Некорректный JSON исходов.")
        return
    existing = await game_repo.get_custom_mode(session, code)
    if existing is not None:
        await send(message, "Режим с таким кодом уже есть.")
        return
    await game_repo.create_custom_mode(
        session, code=code, title=title[:64], description=None,
        outcomes=outcomes, created_by=message.from_user.id,
    )
    await admin_service.audit(
        session, admin_id=message.from_user.id,
        action=AdminActionType.CUSTOM_MODE, payload={"code": code},
    )
    await send(message, f"Режим «{title}» создан и доступен в разделе «Авторские».")


@router.message(Command("audit"))
async def cmd_audit(message: Message, session: AsyncSession, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    items = await admin_service.recent_actions(session, limit=15)
    if not items:
        await send(message, "Аудит-лог пуст.")
        return
    lines = [
        f"• {i.created_at:%d.%m %H:%M} — {i.action} "
        f"(админ {i.admin_id}, цель {i.target_user_id or '—'})"
        for i in items
    ]
    await send(message, "<b>Аудит-лог</b>\n" + "\n".join(lines))


@router.message(Command("errors"))
async def cmd_errors(message: Message, db_user: User) -> None:
    if not is_admin(db_user, message.from_user.id if message.from_user else None):
        return
    items = admin_service.recent_errors()
    if not items:
        await send(message, "Ошибок не зафиксировано.")
        return
    lines = [f"• {i['at']} — {i['message']}" for i in items[-15:]]
    await send(message, "<b>Последние ошибки</b>\n" + "\n".join(lines))

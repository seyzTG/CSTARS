"""Профиль и настройки приватности."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import texts
from app.handlers.states import NicknameStates
from app.keyboards.inline import build_privacy_keyboard, build_profile_keyboard
from app.keyboards.reply import main_keyboard, simple_cancel_keyboard
from app.models import User
from app.models.enums import PrivacyMode
from app.services import users as users_service
from app.utils.timeutil import format_date
from app.utils.tg import answer, edit_or_send, send

router = Router(name="profile")


async def render_profile(
    message: Message, session: AsyncSession, user: User
) -> None:
    profile = await users_service.load_profile(session, user)
    await edit_or_send(
        message,
        texts.PROFILE,
        reply_markup=build_profile_keyboard(),
        name=profile.name,
        user_id=profile.user_id,
        balance=format_amount(profile.balance_minor),
        deposited=format_amount(profile.deposited_minor),
        withdrawn=format_amount(profile.withdrawn_minor),
        turnover=format_amount(profile.turnover_minor),
        games=profile.games_played,
        registered=format_date(profile.registered_at),
    )


from app.utils.money import format_amount  # noqa: E402  (используется выше)


# ------------------------------ приватность --------------------------------

async def render_privacy(
    message: Message, session: AsyncSession, user: User
) -> None:
    profile = await users_service.load_profile(session, user)
    markup = build_privacy_keyboard(profile.privacy_mode.value)
    await edit_or_send(
        message,
        texts.PRIVACY_TEXT,
        reply_markup=markup,
        display=profile.public_name,
    )


@router.callback_query(F.data.startswith("privacy:mode:"))
async def on_privacy_mode(query: CallbackQuery, session: AsyncSession,
                          db_user: User, state: FSMContext) -> None:
    mode = query.data.split(":")[2]
    try:
        parsed = PrivacyMode(mode)
    except ValueError:
        await answer(query)
        return
    await users_service.set_privacy(session, db_user.id, parsed)
    await session.refresh(db_user)
    await answer(query, texts.PRIVACY_SAVED)
    await render_privacy(query.message, session, db_user)
    await state.update_data(section="privacy")


@router.callback_query(F.data == "privacy:nickname")
async def on_nickname_request(query: CallbackQuery, state: FSMContext) -> None:
    await answer(query)
    await send(query.message, texts.NICKNAME_PROMPT,
               reply_markup=simple_cancel_keyboard())
    await state.set_state(NicknameStates.entering)


@router.message(NicknameStates.entering, F.text == texts.KB_CANCEL)
async def on_nickname_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(texts.KB_MENU, reply_markup=main_keyboard())


@router.message(NicknameStates.entering, F.text)
async def on_nickname_enter(message: Message, session: AsyncSession,
                            db_user: User, state: FSMContext) -> None:
    value = (message.text or "").strip()
    if not users_service.nickname_valid(value):
        await send(message, texts.NICKNAME_INVALID)
        return
    await users_service.set_nickname(session, db_user.id, value)
    await session.refresh(db_user)
    await state.set_state(None)
    await send(message, texts.PRIVACY_SAVED, reply_markup=main_keyboard())
    await render_privacy(message, session, db_user)

"""Централизованная обработка исключений и алертов."""

from __future__ import annotations

import traceback

from aiogram import Router
from aiogram.types import ErrorEvent, TelegramObject

from app.config import texts
from app.config.settings import settings
from app.services import admin as admin_service
from app.utils.logging import get_logger, sanitize

log = get_logger(__name__)
router = Router(name="errors")


@router.error()
async def on_error(event: ErrorEvent, bot=None) -> bool:
    """Единая точка перехвата ошибок: лог + запись в /errors + уведомление."""
    error = event.exception
    message = sanitize(f"{type(error).__name__}: {error}")
    log.error("Unhandled error: %s\n%s", message,
              sanitize(traceback.format_exc(limit=8)))
    admin_service.record_error(message)

    # уведомляем администраторов (кроме спам-ошибок Telegram)
    if bot is not None and settings.admin_ids and _is_interesting(error):
        for admin_id in settings.admin_ids[:3]:
            try:
                await bot.send_message(
                    admin_id,
                    f"⚠ Ошибка в боте:\n{message[:400]}",
                )
            except Exception:  # noqa: BLE001
                pass
    return True


def _is_interesting(error: Exception) -> bool:
    name = type(error).__name__
    if name in {"TelegramRetryAfter", "TelegramBadRequest",
                "TelegramForbiddenError"}:
        return False
    return True

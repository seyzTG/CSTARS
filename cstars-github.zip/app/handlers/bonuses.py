"""Ежедневный бонус и кешбэк (экраны, получение, детали)."""

from __future__ import annotations

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import bonuses as bonus_cfg
from app.config import cashback as cashback_cfg
from app.config import texts
from app.keyboards.inline import build_cashback_keyboard
from app.models import User
from app.services import bonuses as bonuses_service
from app.utils.money import format_amount
from app.utils.tg import answer, edit_or_send, send

router = Router(name="bonuses")


# --------------------------- ежедневный бонус ------------------------------

async def render_daily(message: Message, session: AsyncSession, user: User) -> None:
    state = await bonuses_service.daily_state(session, user.id)
    if state.eligible:
        status = texts.DAILY_BONUS_OK.format(
            amount=format_amount(state.amount_minor))
        button = _daily_button(True)
    else:
        status = state.reason
        button = _daily_button(False)

    await edit_or_send(
        message, texts.DAILY_BONUS, reply_markup=button,
        description=bonus_cfg.describe(), status_line=status,
    )


def _daily_button(available: bool):
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    label = texts.BTN_TAKE_BONUS if available else texts.BTN_BONUS_UNAVAILABLE
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text=label,
            callback_data="daily:claim" if available else "daily:info"),
    ], [
        InlineKeyboardButton(text=texts.KB_BACK, callback_data="nav:menu"),
    ]])


@router.callback_query(F.data == "daily:info")
async def on_daily_unavailable(query: CallbackQuery, session: AsyncSession,
                               db_user: User) -> None:
    """Причина отказа — всплывающим окном (как на референсе)."""
    state = await bonuses_service.daily_state(session, db_user.id)
    await answer(query, state.reason, alert=True)


@router.callback_query(F.data == "daily:claim")
async def on_daily_claim(query: CallbackQuery, session: AsyncSession,
                         db_user: User) -> None:
    result = await bonuses_service.claim_daily(session, db_user.id)
    if not result.ok:
        await answer(query, result.context.get("detail") if result.context else "Недоступно",
                     alert=True)
        return
    await answer(
        query,
        texts.DAILY_BONUS_GIVEN.format(
            amount=format_amount(result.amount_minor)),
    )
    await render_daily(query.message, session, db_user)


# -------------------------------- кешбэк -----------------------------------

async def render_cashback(message: Message, session: AsyncSession,
                          user: User) -> None:
    state = await bonuses_service.cashback_state(session, user.id)
    markup = build_cashback_keyboard(available=state.available_minor > 0)
    await edit_or_send(
        message, texts.CASHBACK_SCREEN, reply_markup=markup,
        available=format_amount(state.available_minor),
        total=format_amount(state.total_minor),
        eta=state.eta,
    )


async def render_cashback_details(message: Message) -> None:
    await edit_or_send(
        message, texts.CASHBACK_DETAILS,
        reply_markup=_back_button(),
        percent=cashback_cfg.percent_label(),
        max=cashback_cfg.MAX_PAYOUT,
        min_turnover=cashback_cfg.MIN_TURNOVER,
    )


def _back_button():
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=texts.KB_BACK, callback_data="nav:cashback"),
    ]])


@router.callback_query(F.data == "cb:info")
async def on_cashback_info(query: CallbackQuery) -> None:
    await answer(query, "Кешбэк будет доступен после игровой активности за период.",
                 alert=True)


@router.callback_query(F.data == "cb:details")
async def on_cashback_details(query: CallbackQuery) -> None:
    await answer(query)
    await render_cashback_details(query.message)


@router.callback_query(F.data == "cb:claim")
async def on_cashback_claim(query: CallbackQuery, session: AsyncSession,
                            db_user: User) -> None:
    result = await bonuses_service.claim_cashback(session, db_user.id)
    if not result.ok:
        await answer(query, texts.CASHBACK_NOTHING, alert=True)
        return
    await answer(query, texts.CASHBACK_TAKEN.format(
        amount=format_amount(result.amount_minor)))
    await render_cashback(query.message, session, db_user)

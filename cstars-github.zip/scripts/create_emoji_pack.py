"""Создание стикер-пака Telegram Premium Custom Emoji для CSTARS.

Что делает:
  1. Рисует 100x100 PNG для каждого уникального глифа из EMOJI_FALLBACK
     (Pillow + Segoe UI Emoji, цветной рендер).
  2. Заливает их через uploadStickerFile.
  3. Создаёт набор custom_emoji через createNewStickerSet.
  4. Считывает реальные custom_emoji_id через getStickerSet.
  5. Пишет маппинг role -> custom_emoji_id в custom_emoji_ids.json.

Запуск (из корня проекта, при активном .env):
    python scripts/create_emoji_pack.py

Владелец набора — первый ADMIN_IDS (должен нажать /start боту).
"""

from __future__ import annotations

import asyncio
import io
import json
import sys
from pathlib import Path

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import FSInputFile, InputSticker

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config.custom_emojis import EMOJI_FALLBACK  # noqa: E402
from app.config.settings import settings  # noqa: E402

FONT_PATH = Path(r"C:\Windows\Fonts\seguiemj.ttf")
SIZE = 100
OUT_DIR = Path(__file__).resolve().parent / "_emoji_png"
SET_NAME = f"cstars_emoji_by_{settings.bot_username}"
SET_TITLE = "CSTARS Premium Emoji"
RESULT_PATH = Path(__file__).resolve().parents[1] / "custom_emoji_ids.json"

# Глифы, которые Telegram НЕ принимает в emoji_list InputSticker
# (не являются Unicode emoji). Картинка остаётся прежней — заменяется
# только поисковый кодпойнт.
SAFE_EMOJI = {
    "☰": "📋",   # меню
    "➤": "➡️",   # стрелка
}


def render_png(glyph: str, dest: Path) -> None:
    """Цветной глиф по центру прозрачного квадрата 100x100."""
    from PIL import Image, ImageDraw, ImageFont

    canvas = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype(str(FONT_PATH), 80, index=0)

    bbox = draw.textbbox((0, 0), glyph, font=font, embedded_color=True)
    width = bbox[2] - bbox[0]
    height = bbox[3] - bbox[1]
    x = (SIZE - width) / 2 - bbox[0]
    y = (SIZE - height) / 2 - bbox[1]
    draw.text((x, y), glyph, font=font, fill=(255, 255, 255, 255),
              embedded_color=True)
    canvas.save(dest, "PNG")


async def main() -> int:
    if not FONT_PATH.exists():
        print(f"ERROR: шрифт не найден: {FONT_PATH}")
        return 1

    owner_id = settings.admin_ids[0] if settings.admin_ids else None
    if owner_id is None:
        print("ERROR: пустой ADMIN_IDS — нечего назначать владельцу набора")
        return 1

    bot = Bot(
        settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    # Уникальные глифы (роль -> глиф, дубли схлопываем)
    glyphs: dict[str, str] = {}  # glyph -> первый role
    for role, glyph in EMOJI_FALLBACK.items():
        glyphs.setdefault(glyph, role)

    print(f"Глифов к созданию: {len(glyphs)}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    file_ids: dict[str, str] = {}  # glyph -> file_id
    for glyph, role in glyphs.items():
        path = OUT_DIR / f"e_{ord(glyph[0]):x}.png"
        try:
            render_png(glyph, path)
        except Exception as exc:  # noqa: BLE001
            print(f"  пропущен {glyph} ({role}): {exc}")
            continue
        uploaded = await bot.upload_sticker_file(
            user_id=owner_id,
            sticker=FSInputFile(path),
            sticker_format="static",
        )
        file_id = uploaded.file_id
        file_ids[glyph] = file_id
        print(f"  загружен {glyph} ({role}) -> {file_id[:20]}...")

    stickers = [
        InputSticker(sticker=file_id,
                     emoji_list=[SAFE_EMOJI.get(glyph, glyph)],
                     format="static")
        for glyph, file_id in file_ids.items()
    ]

    print(f"\nСоздаю набор {SET_NAME!r} ({len(stickers)} стикеров)...")
    try:
        await bot.create_new_sticker_set(
            user_id=owner_id,
            name=SET_NAME,
            title=SET_TITLE,
            stickers=stickers,
            sticker_format="static",
            sticker_type="custom_emoji",
        )
        print("Набор создан.")
    except Exception as exc:  # noqa: BLE001
        print(f"createNewStickerSet: {exc}")
        print("Пробую добавить в существующий набор...")
        try:
            await bot.add_sticker_to_set(
                user_id=owner_id,
                name=SET_NAME,
                sticker=stickers[0],
            )
        except Exception as exc2:  # noqa: BLE001
            print(f"add_sticker_to_set тоже не вышел: {exc2}")
            await bot.session.close()
            return 1

    info = await bot.get_sticker_set(SET_NAME)
    glyph_to_id: dict[str, str] = {}
    for sticker in info.stickers:
        if sticker.custom_emoji_id and sticker.emoji:
            glyph_to_id[sticker.emoji[0]] = str(sticker.custom_emoji_id)

    role_to_id = {
        role: glyph_to_id[glyph]
        for glyph, role in glyphs.items()
        if glyph in glyph_to_id
    }

    RESULT_PATH.write_text(
        json.dumps(role_to_id, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\nГотово: {len(role_to_id)} ролей -> {RESULT_PATH}")
    print(json.dumps(role_to_id, ensure_ascii=False, indent=2))

    await bot.session.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))

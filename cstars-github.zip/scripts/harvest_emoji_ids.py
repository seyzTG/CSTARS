"""Дозаписать недостающие custom_emoji_id (нормализация VS16) в JSON и .env."""
import asyncio
import json
import re
import sys
from pathlib import Path

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.config.custom_emojis import EMOJI_FALLBACK  # noqa: E402
from app.config.settings import settings  # noqa: E402

SET_NAME = f"cstars_emoji_by_{settings.bot_username}"
RESULT = ROOT / "custom_emoji_ids.json"
ENV = ROOT / ".env"

# глифы, заменённые на валидные emoji при создании набора
SUBST = {"☰": "📋", "➤": "➡️"}


def keys(glyph: str) -> list[str]:
    """Варианты одной и той же пиктограммы (с/без VS16)."""
    base = glyph.replace("\ufe0f", "")
    return [glyph, base, base + "\ufe0f", glyph + "\ufe0f"]


async def main() -> int:
    bot = Bot(settings.bot_token,
              default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    info = await bot.get_sticker_set(SET_NAME)
    await bot.session.close()

    have: dict[str, str] = {}
    for sticker in info.stickers:
        if sticker.custom_emoji_id and sticker.emoji:
            have[sticker.emoji[0]] = str(sticker.custom_emoji_id)

    role_to_id: dict[str, str] = {}
    missing: list[str] = []
    for role, glyph in EMOJI_FALLBACK.items():
        found = None
        for probe in keys(glyph) + keys(SUBST.get(glyph, glyph)):
            if probe in have:
                found = have[probe]
                break
        if found:
            role_to_id[role] = found
        else:
            missing.append(f"{role}({glyph})")

    RESULT.write_text(json.dumps(role_to_id, ensure_ascii=False, indent=2),
                      encoding="utf-8")

    env_text = ENV.read_text(encoding="utf-8")
    payload = json.dumps(role_to_id, ensure_ascii=False, separators=(",", ":"))
    line = f"CUSTOM_EMOJI_IDS_JSON={payload}"
    if re.search(r"^CUSTOM_EMOJI_IDS_JSON=.*$", env_text, flags=re.M):
        env_text = re.sub(r"^CUSTOM_EMOJI_IDS_JSON=.*$", lambda _m: line,
                          env_text, flags=re.M)
    else:
        env_text = env_text.rstrip("\n") + "\n" + line + "\n"
    ENV.write_text(env_text, encoding="utf-8")

    print(f"ролей с ID: {len(role_to_id)}, пропущено: {missing or 'нет'}")
    return 0


raise SystemExit(asyncio.run(main()))

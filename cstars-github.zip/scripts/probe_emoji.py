"""Проба: какие emoji_list принимает Telegram для InputSticker."""
import asyncio
import sys
from pathlib import Path

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import FSInputFile, InputSticker

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.config.settings import settings  # noqa: E402

PNG_DIR = Path(__file__).resolve().parent / "_emoji_png"

CANDIDATES = ["☰", "➤", "ℹ", "ℹ️", "👁", "👁️", "⏱", "⏱️",
              "🛡", "🛡️", "⚙️", "↩️", "✏️", "🆔"]


async def main() -> None:
    bot = Bot(settings.bot_token,
              default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    owner = settings.admin_ids[0]
    for glyph in CANDIDATES:
        png = PNG_DIR / f"e_{ord(glyph[0]):x}.png"
        if not png.exists():
            print(f"{glyph}: png нет")
            continue
        up = await bot.upload_sticker_file(user_id=owner,
                                           sticker=FSInputFile(png),
                                           sticker_format="static")
        try:
            await bot.create_new_sticker_set(
                user_id=owner,
                name=f"probetest_{ord(glyph[0]):x}_by_{settings.bot_username}",
                title="probe",
                stickers=[InputSticker(sticker=up.file_id,
                                       emoji_list=[glyph], format="static")],
                sticker_format="static",
                sticker_type="custom_emoji",
            )
            print(f"{glyph}: OK")
        except Exception as exc:  # noqa: BLE001
            print(f"{glyph}: FAIL {exc}")
    await bot.session.close()


asyncio.run(main())
